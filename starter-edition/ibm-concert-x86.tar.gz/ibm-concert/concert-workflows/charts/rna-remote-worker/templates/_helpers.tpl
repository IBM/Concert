# Supported-Architectures: ppc64le, X86_64
{{- define "existingSecret.data" }}
  {{- $secretName := .name }}
  {{- $key := .key }}
  {{- $secretFullName := printf "%s-%s" .Dot.Release.Name $secretName }}
  {{- $secretObj := (lookup "v1" "Secret" .Dot.Release.Namespace $secretFullName) | default dict }}
  {{- $secretData := (get $secretObj "data") | default dict }}
  {{- $value := get $secretData $key }}
  {{- $value }}
{{- end }}

{{- define "existingConfigMap.data" }}
  {{- $configMapName := .name }}
  {{- $key := .key }}
  {{- $configMapFullName := printf "%s-%s" .Dot.Release.Name $configMapName }}
  {{- $configMapObj := (lookup "v1" "ConfigMap" .Dot.Release.Namespace $configMapFullName) | default dict }}
  {{- $configMapData := (get $configMapObj "data") | default dict }}
  {{- $value := get $configMapData $key }}
  {{- $value }}
{{- end }}

{{/*
Check if the chart should create RBAC objects
Returns "true" unless rbac.create is set to false, empty string otherwise
With rbac.create=false the chart does not install ServiceAccounts, Roles,
RoleBindings, ClusterRoles or ClusterRoleBindings; identically named objects must
be pre-created outside the release (render them with "helm template --show-only")
*/}}
{{- define "pliant.rbac.create" -}}
{{- $create := true -}}
{{- if and (hasKey .Values "rbac") (hasKey .Values.rbac "create") -}}
{{- $create = .Values.rbac.create -}}
{{- end -}}
{{- if $create -}}
true
{{- end -}}
{{- end -}}

{{- define "decodePem" }}
  {{- $certPem := . }}
  {{- if $certPem }}
    {{- if not (hasPrefix "-----" $certPem) }}
      {{- $certPem = $certPem | b64dec }}
      {{- if hasPrefix "illegal" $certPem }}
        {{- fail $certPem }}
      {{- end }}
    {{- end }}
  {{- end }}
  {{- $certPem }}
{{- end }}

{{ define "IBM.annotations" }}
productID: "20a1779444b84225a1659b5c4f292499"
productName: "IBM Rapid Network Automation"
productMetric: "PROCESS"
productChargedContainers: "All"
{{- end}}

{{/* Pod SecurityContext shared by all pods */}}
{{- define "pliant.podSecurityContext" -}}
securityContext:
{{- if not (.Capabilities.APIVersions.Has "security.openshift.io/v1/SecurityContextConstraints") }}
  fsGroup: 1000
  supplementalGroups:
    - 1000
  runAsUser: 1000
  runAsGroup: 1000
{{- end }}
  runAsNonRoot: true
  seccompProfile:
    type: RuntimeDefault
  {{- if .Values.security.apparmor.enabled }}
  appArmorProfile:
    type: RuntimeDefault
  {{- end }}
{{- end }}

{{/* Container SecurityContext shared by all pods */}}
{{- define "pliant.containerSecurityContext" -}}
securityContext:
{{- if not (.Capabilities.APIVersions.Has "security.openshift.io/v1/SecurityContextConstraints") }}
  runAsUser: 1000
  runAsGroup: 1000
{{- end }}
  runAsNonRoot: true
  allowPrivilegeEscalation: false
  privileged: false
  readOnlyRootFilesystem: true
  capabilities:
    drop:
      - ALL
{{- end }}

{{/* IP stack shared by all Services in the chart.
Renders ipFamilyPolicy / ipFamilies from .Values.service; when left empty the
fields are omitted and the cluster defaults apply. */}}
{{- define "pliant.service.ipStack" -}}
{{- with .Values.service }}
{{- with .ipFamilyPolicy }}
ipFamilyPolicy: {{ . }}
{{- end }}
{{- with .ipFamilies }}
ipFamilies:
{{- range . }}
  - {{ . }}
{{- end }}
{{- end }}
{{- end }}
{{- end }}

{{/* NetworkPolicy feature gate for the Remote Worker chart. */}}
{{- define "pliant.networkPolicy.enabled" -}}
{{- if .Values.security.networkPolicy.integratedEgressRestriction.enabled -}}
true
{{- else -}}
false
{{- end -}}
{{- end }}

{{- define "pliant.networkPolicy.dnsEgress" -}}
{{- if .Capabilities.APIVersions.Has "security.openshift.io/v1/SecurityContextConstraints" }}
- to:
    - namespaceSelector:
        matchLabels:
          kubernetes.io/metadata.name: openshift-dns
  ports:
    - protocol: UDP
      port: 53
    - protocol: TCP
      port: 53
    - protocol: UDP
      port: 5353
    - protocol: TCP
      port: 5353
{{- else }}
- to:
    - namespaceSelector:
        matchLabels:
          kubernetes.io/metadata.name: kube-system
  ports:
    - protocol: UDP
      port: 53
    - protocol: TCP
      port: 53
{{- end }}
{{- end }}

{{- define "pliant.networkPolicy.restrictedEgress" -}}
{{ include "pliant.networkPolicy.dnsEgress" . }}
- to:
    - podSelector: {}
{{- end }}
