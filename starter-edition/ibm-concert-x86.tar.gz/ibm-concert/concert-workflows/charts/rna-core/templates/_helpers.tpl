# Supported-Architectures: s390x, ppc64le, X86_64
{{- define "existingSecret.data" }}
  {{- $secretName := .name }}
  {{- $key := .key }}
  {{- $secretFullName := printf "%s-%s" .Dot.Release.Name $secretName }}
  {{- $secretObj := (lookup "v1" "Secret" .Dot.Release.Namespace $secretFullName) | default dict }}
  {{- $secretData := (get $secretObj "data") | default dict }}
  {{- $value := get $secretData $key }}
  {{- $value }}
{{- end }}

{{/*
Check if AI is enabled
Returns "true" if AI should be enabled, empty string otherwise
AI is always enabled for SaaS installations (aws-saas, ibm-saas)
*/}}
{{- define "pliant.ai.enabled" -}}
{{- if or (eq .Values.rna.instance.installation_type "aws-saas") (eq .Values.rna.instance.installation_type "ibm-saas") -}}
true
{{- else if eq .Values.rna.instance.ai.enabled "true" -}}
true
{{- end -}}
{{- end -}}

{{/*
Check if the MCP server is enabled
Returns "true" if the Concert Workflows MCP service should be deployed
(and exposed at /mcp by pliant-proxy), empty string otherwise
*/}}
{{- define "pliant.mcp.enabled" -}}
{{- if eq (dig "mcp" "enabled" "true" .Values.rna.instance | toString) "true" -}}
true
{{- end -}}
{{- end -}}

{{/*
Check if the chart should create RBAC objects
Returns "true" unless rbac.create is set to false, empty string otherwise
With rbac.create=false the chart does not install ServiceAccounts, Roles,
RoleBindings, ClusterRoles or ClusterRoleBindings; identically named objects must
be pre-created outside the release (render them with "helm template --show-only")
*/}}
{{- define "pliant.rbac.create" -}}
{{- $create := true -}}
{{- if and (hasKey .Values "rbac") (hasKey .Values.rbac "create") -}}
{{- $create = .Values.rbac.create -}}
{{- end -}}
{{- if $create -}}
true
{{- end -}}
{{- end -}}

{{/*
Check if the chart should create NetworkPolicy objects
Returns "true" unless security.networkPolicy.create is set to false, empty string otherwise
With security.networkPolicy.create=false the chart does not install any NetworkPolicies;
identically named objects must be pre-created outside the release
(render them with "helm template --show-only")
*/}}
{{- define "pliant.networkPolicy.create" -}}
{{- $create := true -}}
{{- if and (hasKey .Values "security") (hasKey .Values.security "networkPolicy") (hasKey .Values.security.networkPolicy "create") -}}
{{- $create = .Values.security.networkPolicy.create -}}
{{- end -}}
{{- if $create -}}
true
{{- end -}}
{{- end -}}

{{- define "decodePem" }}
  {{- $certPem := . }}
  {{- if $certPem }}
    {{- if not (hasPrefix "-----" $certPem) }}
      {{- $certPem = $certPem | b64dec }}
      {{- if hasPrefix "illegal" $certPem }}
        {{- fail $certPem }}
      {{- end }}
    {{- end }}
  {{- end }}
  {{- $certPem }}
{{- end }}

{{ define "IBM.annotations" }}
productID: "b4cd7f76c9034bdfbc7dcc6421afff65"
productName: "IBM Concert Software Enterprise"
productCode: "5900-BD6, 5900-BBE"
productCodeType: "PID"
ut30: "30A20"
productMetric: "RESOURCE_UNIT"
productChargedContainers: "All"
{{- end}}

{{ define "IBM.annotations.legacy" }}
productID: "20a1779444b84225a1659b5c4f292499"
productName: "IBM Rapid Network Automation"
productMetric: "PROCESS"
productChargedContainers: "All"
{{- end}}

{{/*
Istio Setup
*/}}

{{/*
Check if istio is enabled
*/}}
{{- define "istio.enabled" -}}
{{- if and .Values.rna .Values.rna.instance .Values.rna.instance.istio (eq .Values.rna.instance.istio.enabled true) }}
true
{{- end -}}
{{- end -}}

{{/*
Istio to namespace injection
*/}}
{{- define "istio.ns.injection" -}}
{{- if and .Values.rna .Values.rna.instance .Values.rna.instance.istio (eq .Values.rna.instance.istio.enabled true) }}
istio-injection: enabled
{{- end }}
{{- end }}

{{/*
Istio to pod injection
*/}}
{{- define "istio.app.injection" -}}
{{- if and .Values.rna .Values.rna.instance .Values.rna.instance.istio (eq .Values.rna.instance.istio.enabled true) }}
sidecar.istio.io/inject: "true"
{{- end }}
{{- end }}

{{/*
Wait for proxy before main container starts
*/}}
{{- define "istio.proxy.holdApplication" -}}
{{- if and .Values.rna .Values.rna.instance .Values.rna.instance.istio (eq .Values.rna.instance.istio.enabled true) }}
proxy.istio.io/config: '{ "holdApplicationUntilProxyStarts": true }'
{{- end }}
{{- end }}

{{/*
Send signal to shutdown proxy
*/}}
{{- define "istio.shutdown.command" -}}
echo "Job completed, shutting down proxy..."
curl -X POST http://localhost:15000/quitquitquit || echo "Curl to proxy failed"
sleep 2
{{- end -}}

{{- define "ext.mysql.secretIsComplete" -}}
  {{- $secret := lookup "v1" "Secret" .Release.Namespace "cw-secrets" -}}
  {{- if and $secret $secret.data -}}
    {{- $host := (get $secret.data "MYSQLDB_HOST") | default "" | b64dec | trim -}}
    {{- $port := (get $secret.data "MYSQLDB_PORT") | default "" | b64dec | trim -}}
    {{- $user := (get $secret.data "MYSQLDB_USER") | default "" | b64dec | trim -}}
    {{- $password := (get $secret.data "MYSQLDB_PASSWORD") | default "" | b64dec | trim -}}
    {{- $dbname := (get $secret.data "MYSQLDB_DBNAME") | default "" | b64dec | trim -}}
    {{- if and (ne $host "") (ne $port "") (ne $user "") (ne $password "") (ne $dbname "") -}}
      true
    {{- else -}}
      false
    {{- end -}}
  {{- else -}}
    false
  {{- end -}}
{{- end -}}

{{- define "ext.postgres.secretIsComplete" -}}
  {{- $secret := lookup "v1" "Secret" .Release.Namespace "cw-secrets" -}}
  {{- if and $secret $secret.data -}}
    {{- $host := (get $secret.data "POSTGRESQL_HOST") | default "" | b64dec | trim -}}
    {{- $port := (get $secret.data "POSTGRESQL_PORT") | default "" | b64dec | trim -}}
    {{- $user := (get $secret.data "POSTGRESQL_USER") | default "" | b64dec | trim -}}
    {{- $password := (get $secret.data "POSTGRESQL_PASSWORD") | default "" | b64dec | trim -}}
    {{- $dbname := (get $secret.data "POSTGRESQL_DBNAME") | default "" | b64dec | trim -}}
    {{- if and (ne $host "") (ne $port "") (ne $user "") (ne $password "") (ne $dbname "") -}}
      true
    {{- else -}}
      false
    {{- end -}}
  {{- else -}}
    false
  {{- end -}}
{{- end -}}

{{- define "s3.secretIsComplete" -}}
  {{- $secret := lookup "v1" "Secret" .Release.Namespace "cw-secrets" -}}
  {{- if and $secret $secret.data -}}
    {{- $secret_key := (get $secret.data "CW_SECRET_KEY") | default "" | b64dec | trim -}}
    {{- $access_key := (get $secret.data "CW_ACCESS_KEY") | default "" | b64dec | trim -}}
    {{- $auth_type := (get $secret.data "CW_AUTH_TYPE") | default "" | b64dec | trim -}}
    {{- $bucket := (get $secret.data "CW_BUCKET") | default "" | b64dec | trim -}}
    {{- $host := (get $secret.data "CW_HOST") | default "" | b64dec | trim -}}
    {{- $region := (get $secret.data "CW_REGION") | default "" | b64dec | trim -}}
    {{- $port := (get $secret.data "CW_PORT") | default "" | b64dec | trim -}}
    {{- if and (ne $secret_key "") (ne $access_key "") (ne $auth_type "") (ne $bucket "") (ne $host "") (ne $region "") (ne $port "")  -}}
      true
    {{- else -}}
      false
    {{- end -}}
  {{- else -}}
    false
  {{- end -}}
{{- end -}}

{{- define "ext.rabbitmq.secretIsComplete" -}}
  {{- $secret := lookup "v1" "Secret" .Release.Namespace "cw-secrets" -}}
  {{- if and $secret $secret.data -}}
    {{- $host := (get $secret.data "RABBITMQ_HOST") | default "" | b64dec | trim -}}
    {{- $port := (get $secret.data "RABBITMQ_PORT") | default "" | b64dec | trim -}}
    {{- $user := (get $secret.data "RABBITMQ_USER") | default "" | b64dec | trim -}}
    {{- $password := (get $secret.data "RABBITMQ_PASSWORD") | default "" | b64dec | trim -}}
    {{- if and (ne $host "") (ne $port "")  (ne $user "") (ne $password "")  -}}
      true
    {{- else -}}
      false
    {{- end -}}
  {{- else -}}
    false
  {{- end -}}
{{- end -}}

{{- define "ext.rabbitmq.secretData" -}}
  {{- $secret := lookup "v1" "Secret" .Release.Namespace "cw-secrets" -}}
  {{- $secretData := ($secret | default dict).data | default dict -}}
  {{- $host         := (get $secretData "RABBITMQ_HOST")         | default "" | b64dec | trim -}}
  {{- $port         := (get $secretData "RABBITMQ_PORT")         | default "" | b64dec | trim -}}
  {{- $user         := (get $secretData "RABBITMQ_USER")         | default "" | b64dec | trim -}}
  {{- $password     := (get $secretData "RABBITMQ_PASSWORD")     | default "" | b64dec | trim -}}
  {{- $virtualHost  := (get $secretData "RABBITMQ_VIRTUAL_HOST") | default "" | b64dec | trim -}}
  {{- $protocolRaw  := (get $secretData "RABBITMQ_PROTOCOL")     | default "" | b64dec | trim -}}
  {{- dict "host" $host "port" $port "user" $user "password" $password "virtualHost" $virtualHost "protocolRaw" $protocolRaw | toJson -}}
{{- end -}}

{{- define "ext.rabbitmq.protocol" -}}
  {{- $d := include "ext.rabbitmq.secretData" . | fromJson -}}
  {{- if and $d.protocolRaw (not (or (eq $d.protocolRaw "amqp") (eq $d.protocolRaw "amqps"))) -}}
    {{ fail (printf "RABBITMQ_PROTOCOL must be 'amqp' or 'amqps', got: '%s'" $d.protocolRaw) }}
  {{- end -}}
  {{- if $d.protocolRaw -}}
    {{- $d.protocolRaw -}}
  {{- else if eq $d.port "5672" -}}
    {{- "amqp" -}}
  {{- else -}}
    {{- "amqps" -}}
  {{- end -}}
{{- end -}}

{{- define "ext.rabbitmq.virtualHost" -}}
  {{- $d := include "ext.rabbitmq.secretData" . | fromJson -}}
  {{- $vhost := $d.virtualHost | default "" | trim -}}

  {{- if eq $vhost "" -}}
    {{- "/" -}}
  {{- else if contains "/" $vhost -}}
    {{- if eq $vhost "/" -}}
      {{- "/" -}}
    {{- else -}}
      {{- fail (printf "RABBITMQ_VIRTUAL_HOST value from cw-secrets must be either '/', empty, or a simple vhost name without '/'. Got: '%s'" $vhost) -}}
    {{- end -}}
  {{- else -}}
    {{- $vhost -}}
  {{- end -}}
{{- end -}}

{{- define "ext.rabbitmq.uri" -}}
  {{- $d := include "ext.rabbitmq.secretData" . | fromJson -}}
  {{- $protocol := include "ext.rabbitmq.protocol" . -}}
  {{- $vhost := include "ext.rabbitmq.virtualHost" . -}}
  {{- if not (hasPrefix "/" $vhost) -}}
    {{- $vhost = printf "/%s" $vhost -}}
  {{- end -}}
  {{- printf "%s://%s:%s%s?frameMax=131072" $protocol $d.host $d.port $vhost -}}
{{- end -}}

{{/* Pod SecurityContext shared by all pods */}}
{{- define "pliant.podSecurityContext" -}}
securityContext:
{{- if not (.Capabilities.APIVersions.Has "security.openshift.io/v1/SecurityContextConstraints") }}
  fsGroup: 1000
  fsGroupChangePolicy: {{ .Values.common.security.podSecurityContext.fsGroupChangePolicy | quote }}
  supplementalGroups:
    - 1000
  runAsUser: 1000
  runAsGroup: 1000
{{- end }}
  runAsNonRoot: true
  seccompProfile:
    type: RuntimeDefault
  {{- if .Values.security.apparmor.enabled }}
  appArmorProfile:
    type: RuntimeDefault
  {{- end }}
{{- end }}

{{/* Container SecurityContext shared by all pods */}}
{{- define "pliant.containerSecurityContext" -}}
securityContext:
{{- if not (.Capabilities.APIVersions.Has "security.openshift.io/v1/SecurityContextConstraints") }}
  runAsUser: 1000
  runAsGroup: 1000
{{- end }}
  runAsNonRoot: true
  allowPrivilegeEscalation: false
  privileged: false
  readOnlyRootFilesystem: true
  capabilities:
    drop:
      - ALL
{{- end }}

{{- define "pliant.networkPolicy.dnsEgress" -}}
{{- if .Capabilities.APIVersions.Has "security.openshift.io/v1/SecurityContextConstraints" }}
- to:
    - namespaceSelector:
        matchLabels:
          kubernetes.io/metadata.name: openshift-dns
  ports:
    - protocol: UDP
      port: 53
    - protocol: TCP
      port: 53
    - protocol: UDP
      port: 5353
    - protocol: TCP
      port: 5353
{{- else }}
- to:
    - namespaceSelector:
        matchLabels:
          kubernetes.io/metadata.name: kube-system
  ports:
    - protocol: UDP
      port: 53
    - protocol: TCP
      port: 53
{{- end }}
{{- end }}

{{- define "pliant.networkPolicy.restrictedEgress" -}}
{{- if .Values.rna.instance.enable_istio }}
- to:
    - namespaceSelector:
        matchLabels:
          kubernetes.io/metadata.name: istio-system
{{- end }}
{{ include "pliant.networkPolicy.dnsEgress" . }}
- to:
    - podSelector: {}
{{- end }}

{{/* IP stack shared by all Services in the chart.
Renders ipFamilyPolicy / ipFamilies from .Values.service; when left empty the
fields are omitted and the cluster defaults apply. */}}
{{- define "pliant.service.ipStack" -}}
{{- with .Values.service }}
{{- with .ipFamilyPolicy }}
ipFamilyPolicy: {{ . }}
{{- end }}
{{- with .ipFamilies }}
ipFamilies:
{{- range . }}
  - {{ . }}
{{- end }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Optional egress required by restricted workloads when external backends
are configured. Standard Kubernetes NetworkPolicy does not support FQDN
destinations, therefore the destination is unrestricted IPv4 while access
is limited to the configured backend TCP port.
*/}}
{{- define "pliant.networkPolicy.externalBackendEgress" -}}
{{- $root := .root -}}
{{- $item := .item -}}
{{- $secret := lookup "v1" "Secret" $root.Release.Namespace "cw-secrets" | default dict -}}
{{- $secretData := get $secret "data" | default dict -}}

{{- if and
      (get $item "externalMysql")
      (or
        (not (hasKey $root.Values.rna.instance "disable_external_mysql"))
        (eq $root.Values.rna.instance.disable_external_mysql false)
      )
      (eq (include "ext.mysql.secretIsComplete" $root) "true")
}}
{{- $port := (get $secretData "MYSQLDB_PORT") | default "" | b64dec | trim }}
- to:
    - ipBlock:
        cidr: 0.0.0.0/0
  ports:
    - protocol: TCP
      port: {{ $port }}
{{- end }}

{{- if and
      (get $item "externalRabbitmq")
      (eq (include "ext.rabbitmq.secretIsComplete" $root) "true")
}}
{{- $port := (get $secretData "RABBITMQ_PORT") | default "" | b64dec | trim }}
- to:
    - ipBlock:
        cidr: 0.0.0.0/0
  ports:
    - protocol: TCP
      port: {{ $port }}
{{- end }}

{{- if and
      (get $item "externalS3")
      (or
        (not (hasKey $root.Values.rna.instance "disable_external_s3"))
        (eq $root.Values.rna.instance.disable_external_s3 false)
      )
      (eq (include "s3.secretIsComplete" $root) "true")
}}
{{- $port := (get $secretData "CW_PORT") | default "" | b64dec | trim }}
- to:
    - ipBlock:
        cidr: 0.0.0.0/0
  ports:
    - protocol: TCP
      port: {{ $port }}
{{- end }}
{{- end -}}
