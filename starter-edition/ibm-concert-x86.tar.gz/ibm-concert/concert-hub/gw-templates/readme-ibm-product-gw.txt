This directory includes a collection of yaml templates that deploys a solis gateway in Kubernetes namespace 
and attaches it to the hub and proxy to the product's kube svc.

The deploy-k8s.sh script and the templates include multiple placeholder parameters. Set these as env variable values as appropriate for the product.

SOLIS_PRODUCT: id of the product (aka CONTEXT_NAME), for example "car-rental"

K8s_TEMPLATE_DIR: <this directory>
K8s_STATUS_LBL: selector label that identifies the product's deployment and statefulsets. For example: "component=ibm-${SOLIS_PRODUCT}-gw"
K8s_SCALE: <optional> default is level_1. identifies the scale/size of the gw deployment.

SOLIS_PRODUCT_NS: namespace where the product has been (or will be) deployed, typically the same namespace where the gateway templates are applied. If so, export SOLIS_PRODUCT_NS=${K8s_NAMESPACE}
SOLIS_PRODUCT_DIRECT_SVC: the product kube-svc hostname that the gateway should proxy to in that namsepace
SOLIS_PRODUCT_PORT: the product kube-svc port that the gateway should proxy to in that namsepace

HUB_ACCESS_KEY: generated access key for gw->hub service-to-service auth
HUB_URL: where the hub can be accessed from (include https://) 

IMAGE_REGISTRY: where the solis images are to be pulled from (and the app-sa service account is linked to the pull secret). typically set by the deploy-k8s.sh script itself
IMAGE_TAG: for the solis gw image. typically set by the deploy-k8s.sh script itself

## the following - typically come from a .cfg file and identifies the size/scale of the gw
SOLIS_GW_REPLICAS: number of replicas for the gateway deployment
SOLIS_GW_LIM_C: cpu limit
SOLIS_GW_LIM_ES: ephemeral storage limit
SOLIS_GW_LIM_M: memory limit
SOLIS_GW_REQ_C: cpu request
SOLIS_GW_REQ_ES ephemeral storage request
SOLIS_GW_REQ_M: memory request
