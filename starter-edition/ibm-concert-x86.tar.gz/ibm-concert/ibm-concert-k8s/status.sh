#!/usr/bin/env bash

curr_dir=`dirname $0`
cd $curr_dir
curr_dir=`pwd`

source ${curr_dir}/k8s-utils.sh

pre_process_args()
{
    while [ $# -gt 0 ] ; do
      if [[ "$1" == --namespace=* ]]
      then
         NS=$(echo $1 | cut -d "=" -f 2) ;
      else
         NS=$1
         ### temporary default
      fi
      shift
    done
    if [ -z ${NS} ];
    then
        echo "Usage:  $0 <namespace>"
        exit 1
    fi
    export NS 
}

############### Main  ####################

pre_process_args "$@"

resources=$(kubectl get Deployment,StatefulSet -l ibmsupport/app=roja -n $NS -o name)
if [ "X${resources}X" == "XX" ];
then
    echo "${NS}: Unavailable"
    exit 1
fi

all_success=0
for i in ${resources}
do
    rr=$(kubectl -n $NS get ${i} -o jsonpath='{.status.readyReplicas}')
    if [ X"$rr" == X ]; 
    then
        i_status="Failed"
        all_success=1
    elif [ X"$rr" == 0 ]; 
    then
        i_status="Failed"
        all_success=1
    else
        i_status="Ready"
    fi

    echo "${i}: ${i_status}"
done


exit $all_success

