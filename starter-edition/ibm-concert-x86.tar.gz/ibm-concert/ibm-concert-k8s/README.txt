*DEPLOY AND MANAGE CONCERT ON KUBERNETES*

The deployer is used to deploy Concert on Kubernetes. 


*SOURCE DESCRIPTION*

Leverages kubectl kustomize for supporting the kube yaml organization & to support multiple configuration options.

Utilities:
- install-concert-k8s: main deployment script 

- deploy-k8s.sh: triggers the deployment 
    - uses envsubst to replace environment variables
  
-  templates/:  kube templated yamls. filenames are named to support a specific ordering of kubectl applies.

-  eks-alb-ingress.sh: For EKS only - used to expose an ingress route to Concert using ALB

-  eks-nginx-ingress.sh: For EKS only - used to expose an ingress route to Concert using ingress

- k8s-utils.sh: utility functions

- reset.sh: For reseting the data in concert instance (excluding the user credentials)

-  etc/: environment variables sourced by the scripts, especially image registry and credentials.


*DEPLOYMENT DESCRIPTION*

The script install-concert-k8s provides a way for the user to deploy Concert on their k8s cluster. 

The  script deploy-k8s.sh sets up image registry credentials as a kube secret and binds it to the app-sa service account in the target namespace. 
app-sa is then used by the microservices.

The script also invokes ./scripts/init_internal_certs.sh to create internal tls certificates for the microservices to use. 
It then creates a kube secret (app-cfg-internal-tls) for making these TLS key/cert pair available to pods. 
Deployment templates refer to the app-cfg-internal-tls secret as volume mounts.

The external route/ingress would be associated with an external facing TLS certs.

In the case of EKS, the deployment uses a pass-through route that could be used with ALB or nginx Ingress Controller.  The encrypted traffic is sent straight to the destination.

It takes an optional input of storage class, it will create two Minio S3 and two postgreSQL database instances for Concert on the storage class. 

Users can also bring your own buckets and postgresSQL instances, in that case there is no need for a storage class. More details: https://www.ibm.com/docs/en/concert?topic=drhocpo-setting-up-credentials-postgresql-database-object-storage-bucket

--------------------------------------------------------------------------



*VALIDATE PRE-REQ*

1) Ensure connectivity to Kubernetes 

Ensure kubectl  is available in your PATH

kubectl version

--------------------------------------------------------------------------
***********
* DEPLOY *
***********

After login to your cluster or setting kube config/context appropriately,

   install-concert-k8s --license-acceptance=y --namespace=<concert's namespace> [--registry=registry URL prefix] [--registry_user=<registry user>] [--registry_password=<registry password>][--username=<admin username>][--password=<admin password>]  [--storage_class=<for PVCs>] [--scale_config=<scale config>]  [--preview=/tmp/preview.yaml]

- License_acceptance should be set to y to proceed with the installation

- namespace where Concert is to be installed

- registry from where IBM concert images can be pulled, optionally env IMG_PREFIX can be set, instead of passing to the command

- registry_user User who have the access to download the images from the registry, optionally env REG_USER can be set, instead of passing to the command

- registry_password, password for the registry user, optionally REG_PASS can be set, instead of passing to the command

- username, admin user that would be used for Concert login, optionally ROJA_ADM_USERNAME can be set,  instead of passing to the command. If neither command line or env is set, Concert will generate a user randomly

- password, admin password that would be used for Concert login, optionally ROJA_ADM_PASSWORD can be set,  instead of passing to the command. If neither command line or env is set, Concert will generate a password randomly

-scale_config, [level_0, level_minicpureq, level_1, level_2, level_3 and level_4], select the scale for Concert. level_0 being the smallest(scaled down) and level_4 the largest.

- the preview option is just a dry-run and the preview file will just have the generated yaml & the deployment will not be triggered.

- Storage class is required, if not bringing your own storage. 
  The secrets described in https://www.ibm.com/docs/en/concert?topic=drhocpo-setting-up-credentials-postgresql-database-object-storage-bucket must be generated, if bringing your own object storage buckets and database.   

For example, to deploy with the 'native' configuration -

  ./install-concert-k8s --license_acceptance=y --namespace=concert --registry=cp.icr.io/cp/concert --registry_user=cp --registry_password  --username=admin --password --storage_class=nfs-client  --scale_config=level_2



--------------------------------------------------------------------------

*EXPOSING THE PRIMARY ROUTE*

**OCP
  For exposing the primary route to Concert, in OCP, use `./ocp-route.sh <concert's namespace>`
 use 
 1. oc get route concert -n <concert's namespace> to get the generated route
 2. oc extract -n <concert's namespace> secret/app-cfg-secret --to=- to get the generated username, passwords etc.

**EKS WITH ALB CONTROLLER**

Pre-req: Deploy ALB controller follow: https://kubernetes-sigs.github.io/aws-load-balancer-controller/v2.2/deploy/installation/
 For exposing the primary route to Concert  on EKS and using ALB.  It uses TLS passthrough. 
  You would need the following: 
  a.  An AWS certifcate.   https://aws.amazon.com/certificate-manager/ 
    You would need to  export ANNOTATIONS='alb.ingress.kubernetes.io/certificate-arn: "<Your_certificate>"   

      export ANNOTATIONS='alb.ingress.kubernetes.io/certificate-arn: "arn:aws:acm:us-east-2:999999900000:certificate/41770000-0000-4b2f-aa2a-6ff12222222"'
   
    b. Hostname(optional): You can also provide a hostname using `export HOST_NAME=<your host name>` command. This would use the  custom host. 
    
    You can run ./eks-alb-ingress.sh <concert namespace> to create the Ingress resource named as concert. 
    
  To get the hostname  generated by the Ingress controller,  use kubectl get ingress concert -n <concert namespace> |awk '{print $1 " | " $4 }' to extract the address.

**K8S WITH NGINX CONTROLLER (EKS, IKS)**

Pre-req: Deploy nginx controller follow the steps here https://kubernetes.github.io/ingress-nginx/deploy/

 For exposing the primary route to Concert on k8s like EKS, IKS and using Ingress.  It uses TLS passthrough. 
  You would need the following: 
  a. Generate a secret for your SSL cert and export its value to TLS_SECRET. export TLS_SECRET=<your secret name>
  b. Hostname: Add a hostname using export HOST_NAME=<your host name> command.
  c. nginx class: export your nginx class name, export NGINX_CLASSNAME=<your nginx classname>. Default value is nginx 

  You can run ./eks-nginx-ingress.sh <concert namespace> to create the Ingress resource named as concert. 
    
  To get the hostname  generated by the Ingress controller,  use kubectl get ingress concert -n <concert namespace> |awk '{print $1 " | " $4 }' to extract the address.


*RESET*

After login to k8s or setting kube config/context appropriately  #### TODO add URL to concert doc

  ./reset.sh [-n --namespace] [-U --username] [-P --password] [-r --registry] [-u --registry_user] [-u --registry_user] [-p --registry_password][-c  --storage_class] [-d --cfg] [-e --scale_config] [-w --wipe] [-s --setup] [-h --help] [-v --verbose]

  -n    --namespace         Namespace were concert is deployed.
  -c    --storage_class     Name of the storageclass.
  -U    --username          Username for the concert instance
  -r    --registry          Identifies the registry to pull the IBM Concert images from.
  -u    --registry_user     Registry username
  -p    --registry_password Registry password
  -P    --password          Password for the concert instance
  -d    --cfg               Configuration (sw_ent_native)
  -e    --scale_config      Scale configuration. 
  -w    --wipe              To wipe out the data of the concert.
  -s    --setup             To setup the concert.
  -h    --help              Show this message
  -v    --verbose           Log verbosely

-  --wipe option will helps to scale down the minio, appdb and configdb deployments and also deletes the associated pvc's.
-  --setup will help to rebuild the concert instance.
- supported configurations (sw_ent_native)

For example, to deploy with the 'native' configuration -

  ./reset.sh --namespace=concert --storage_class=nfs-client --username concert --password ***** --registry=cp.icr.io/cp/concert --registry_user=cp --registry_password ****** --cfg=sw_ent_native --wipe --setup

------------------------------------------------------------------------------------------------

* Activate Licensing Usage *

After setting up the licensing service and applying OperandRequest CRD, activate-license-cron.sh script can be used for generating LicenseService  secret and configmap in the Concert namespace. 

./activate-license-cron.sh <concert namespace> 

The script will generate necessary secret and configmap in Concert namepsace. Once executed, the metering cron would start reporting the license usage to the Lincesing service. 
