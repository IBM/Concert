#!/usr/bin/env bash


set -e

curr_dir=`dirname $0`
cd $curr_dir
curr_dir=`pwd`

source ${curr_dir}/k8s-utils.sh

############### Main  ####################

NS=$1
if [ "X$NS" =  "X" ];
then
    echo "Usage:  $0 <namespace>"
    exit 1
fi

export TMPCERTDIR=/tmp/$NS
mkdir -p ${TMPCERTDIR}

oc extract secret/app-cfg-internal-tls --namespace=$NS --keys=tls.crt --to=${TMPCERTDIR} --confirm

export INTERNAL_CA_CERT=`cat ${TMPCERTDIR}/tls.crt `

export INTERNAL_CA_CERT_INDENTED=$(echo "${INTERNAL_CA_CERT}" | sed -e 's/^/       /')

sdir=${curr_dir}/app-in-ocp

update_params_yamls ${sdir}

kubectl kustomize ${sdir} | oc apply ${KC_ARGS} --namespace=$NS -f -

oc get route concert --namespace=$NS -o jsonpath='{.spec.host}{"\n"}'

