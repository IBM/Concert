#!/only/source/this

# Encode new values in base64 for Kubernetes
b64() { echo -n "$1" | base64 -w0; }

# Add secure if BYO is false
if [ "$BYO_DATABASE" == "false" ];
then
    secret_ref=$(kubectl get secret --ignore-not-found dataapps-app-cfg-oob-secret -o name  -n $NS)
    if [ x"$secret_ref" == x"secret/dataapps-app-cfg-oob-secret" ];
    then
        POSTGRES_SECURE="true"
        if [  x"${ROJA_k8s_cfg}" == xsw_ent_cpfs ];
        then
            POSTGRES_SECURE="false"
        fi

        DATABASE_URL=$(kubectl get secret dataapps-app-cfg-oob-secret -n $NS -o jsonpath='{.data.DATABASE_URL}' | base64 --decode)
        if [ "X$DATABASE_URL" != "X" ] && [[ "$DATABASE_URL" =~ ^postgresql://([^:]+):([^@]+)@([^:/]+):([0-9]+)/(.+)$ ]];
        then
            POSTGRES_USER="${BASH_REMATCH[1]}"
            POSTGRES_PASSWORD="${BASH_REMATCH[2]}"
            POSTGRES_HOST="${BASH_REMATCH[3]}"
            POSTGRES_PORT="${BASH_REMATCH[4]}"
            POSTGRES_DBNAME="${BASH_REMATCH[5]}"

            PATCH=$(jq -n \
                --arg host "$(b64 "$POSTGRES_HOST")" \
                --arg port "$(b64 "$POSTGRES_PORT")" \
                --arg user "$(b64 "$POSTGRES_USER")" \
                --arg pass "$(b64 "$POSTGRES_PASSWORD")" \
                --arg db "$(b64 "$POSTGRES_DBNAME")" \
                --arg POSTGRES_SECURE "$POSTGRES_SECURE" \
                '{
                  data: {
                    POSTGRES_HOST: $host,
                    POSTGRES_PORT: $port,
                    POSTGRES_USER: $user,
                    POSTGRES_PASSWORD: $pass,
                    POSTGRES_DBNAME: $db,
                    POSTGRES_SECURE: $POSTGRES_SECURE,
                  }
                }'
              )

          # Remove DATABASE_URL key first (optional, but cleaner)
          kubectl patch secret dataapps-app-cfg-oob-secret -n "$NS" --type=json \
            -p='[{"op": "remove", "path": "/data/DATABASE_URL"}]' || true

          # Patch with new keys
          kubectl patch secret dataapps-app-cfg-oob-secret -n "$NS" --type=merge -p "$PATCH"
        fi
    fi
fi
