#!/only/source/this

source ./config-migrations/001-database-url.sh
