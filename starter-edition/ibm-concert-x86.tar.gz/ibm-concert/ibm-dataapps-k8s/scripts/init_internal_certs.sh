#!/bin/bash 
set -e


genSelfSignedCert()
{

    echo "=== generating self signed cert in ${INT_TLS_DIR} ==="
    rm -fr ${INT_TLS_DIR}
    mkdir -p ${INT_TLS_DIR}


svr_conf=$(cat << EOF
[req]
default_bits=2048
prompt=no
default_md=sha
distinguished_name=dn
req_extensions = v3_req

[dn]
C=YY
ST=XX
L=Home-Town
O=Proto-Samples
OU=For-testing
emailAddress=dummy@example.dum
CN=Dummy-Self-signed-Cert

[v3_req]
subjectAltName = @alt_names
extendedKeyUsage = 1.3.6.1.5.5.7.3.1

[alt_names]
DNS.1 = 127.0.0.1
DNS.2 = localhost
DNS.3 = *.dataapps-minio
DNS.4 = *.dataapps-minio.${NAMESPACE}
DNS.5 = *.dataapps-minio.${NAMESPACE}.svc
DNS.6 = *.svc
DNS.7 = *.svc.cluster.local
EOF
)

dns_counter=$(($(grep -c "DNS" <<< "${svr_conf}") + 1))

for host in "$@"; do
  if [ "x$host" != "x" ]
  then
    svr_conf+="\nDNS.${dns_counter} = *.${host}"
    dns_counter=$((dns_counter+1))
  fi
done 

echo -e "${svr_conf}" >  ${INT_TLS_DIR}/server.csr.cnf

openssl req -x509 -sha512 -newkey rsa:2048 -keyout ${INT_TLS_DIR}/tls.key -out ${INT_TLS_DIR}/tls.crt -days 4096 -nodes -config ${INT_TLS_DIR}/server.csr.cnf  -extensions v3_req

## 744 is not exactly a good idea - but is useful for testing with different user ids inside containers

chmod 744 ${INT_TLS_DIR}/*


}

createJKS()
{
    if [ X"${APP_KEYSTORE_PASSWORD}" == X ];
    then
        echo "missing required APP_KEYSTORE_PASSWORD environment variable"
        exit 1
    fi

    openssl pkcs12 -export -passin pass:${APP_KEYSTORE_PASSWORD} -passout pass:${APP_KEYSTORE_PASSWORD} -in ${INT_TLS_DIR}/tls.crt -inkey ${INT_TLS_DIR}/tls.key -out ${INT_TLS_DIR}/tls.p12 -name ibm-lh-client -CAfile ${INT_TLS_DIR}/tls.crt -caname root -chain

    keytool -importkeystore -alias ibm-lh-client -destalias ibm-lh-client -srckeystore ${INT_TLS_DIR}/tls.p12 -srcstoretype pkcs12 -destkeystore ${INT_TLS_DIR}/lh-ssl-ks.jks -noprompt -srckeypass ${APP_KEYSTORE_PASSWORD} -destkeypass ${APP_KEYSTORE_PASSWORD} -deststorepass ${APP_KEYSTORE_PASSWORD} -srcstorepass ${APP_KEYSTORE_PASSWORD}

#should change to using 'changeit' for java trust stores because its the default. Also look at FIPS + Semeru runtime restrictions.
    keytool -import -noprompt -alias ibm-lh-client -trustcacerts -file ${INT_TLS_DIR}/tls.crt -storepass ${APP_KEYSTORE_PASSWORD} -keystore ${INT_TLS_DIR}/ssl-ts.jks -keypass ${APP_KEYSTORE_PASSWORD}
}

get_domain()
{
    export NAMESPACE="${1}"
    if [ -z "${NAMESPACE}" ];
    then
        export NAMESPACE="roja"
    fi
}

### MAIN


if [ X"${INT_TLS_DIR}" == X ];
then
    export INT_TLS_DIR=/mnt/infra/tls
fi

echo === INT_TLS_DIR is "${INT_TLS_DIR}" =====

get_domain ${1}
genSelfSignedCert "${NAMESPACE}" "${NAMESPACE}.svc" "${NAMESPACE}.svc.cluster.local"

## when we need a Java based microservice
#createJKS 
