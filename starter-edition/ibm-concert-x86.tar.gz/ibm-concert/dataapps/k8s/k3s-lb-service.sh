#!/usr/bin/env bash


set -e

curr_dir=`dirname $0`
cd $curr_dir
curr_dir=`pwd`

source ${curr_dir}/k8s-utils.sh

############### Main  ####################

NS=$1
if [ "X$NS" =  "X" ];
then
    echo "Usage:  $0 <namespace>"
    exit 1
fi
sdir=${curr_dir}/app-in-k3s
update_params_yamls ${sdir}

kubectl kustomize ${sdir} | kubectl apply  --namespace=$NS -f -