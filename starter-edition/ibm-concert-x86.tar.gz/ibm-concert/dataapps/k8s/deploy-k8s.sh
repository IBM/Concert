#!/usr/bin/env bash

curr_dir=`dirname $0`
cd $curr_dir
curr_dir=`pwd`

source ${curr_dir}/k8s-utils.sh

set -e

trap 'catch $? $FUNCNAME $LINENO' EXIT
catch() {
  if [ "$1" != "0" ]; then
    echo "FAILED:  error num: $1 occurred at: $2 $3"
  fi
}

kc_kust()
{
    print_message INFO "kc_kust: $1"
    abdir=${curr_dir}/app-build-cfg
    cat ${abdir}/common.yaml >> ${curr_dir}/$1/kustomization.yaml
    if [ "X${DATAAPPS_k8s_PREVIEW}" != "X" ];
    then
        print_message INFO "DATAAPPS_k8s_PREVIEW: ${DATAAPPS_k8s_PREVIEW}"
        kubectl kustomize ${curr_dir}/${1} >> ${DATAAPPS_k8s_PREVIEW}
    else
        kubectl kustomize ${curr_dir}/${1} |  kubectl apply ${KC_ARGS} --namespace=$NS -f -
    fi
}

set_dns_params()
{
    ifocp=$(kubectl api-resources --api-group=route.openshift.io --no-headers)
    if [[ "x$ifocp" == "x" ]]
    then
        export DNS_NAMESPACE_LABEL="kubernetes.io/metadata.name: kube-system"
    else
        export DNS_NAMESPACE_LABEL="kubernetes.io/metadata.name: openshift-dns"
    fi

    echo "DNS_NAMESPACE_LABEL: $DNS_NAMESPACE_LABEL"
}

setid()
{
   if [[ "x${RUNASUSER}" == "x" ]]
   then
       ifocp=$(kubectl api-resources --api-group=route.openshift.io --no-headers)
       if [[ "x$ifocp" == "x" ]]
       then
           export RUNASUSER=1000
           export RUNASGROUP=1000
           export FS_GROUPID=1000
           export SUPP_GROUPID=1000
       else
           rangestr=`kubectl get namespace ${NS} -o jsonpath='{.metadata.annotations.openshift\.io/sa\.scc\.uid-range}'`
           rangeid="${rangestr%/*}"
           export RUNASUSER=${rangeid}
           export RUNASGROUP=${rangeid}
           export FS_GROUPID=${rangeid}
           export SUPP_GROUPID=${rangeid}
       fi
   fi
}

setup()
{
    print_message INFO "initiating setup for $NS.."

    first_time=true
    if [ -z ${DATAAPPS_k8s_PREVIEW} ];
    then
        curr_status=$(kubectl get secret --ignore-not-found  -o name dataapps-app-cfg-secret -n $NS)
        if [ x"$curr_status" == x"secret/dataapps-app-cfg-secret" ];
        then
            first_time=false
        fi
    fi

    if [ x"${FORCE_SETUP}" == x"true" ] || [ x"$first_time" == x"true" ];
    then
        ### first time setup - its not idempotent because we cannot change the oob secrets afterwards for the 'native' case.

        setup_namespace $NS
        set_dns_params
        setid
        update_params

        if [ x"${DATAAPPS_k8s_cfg}" == x"sw_ent_native" ] && [ "X${SKIP_PULL}" != "Xtrue" ];
        then
            setup_pull_secrets $NS
        fi

        ## this is for the cpfs case when, we want to pull from a dev-test registry instead of relying on Global Pull Secrets
        if [ x"${DATAAPPS_k8s_dev}" != x ] && [ "X${SKIP_PULL}" != "Xtrue" ];
        then
            setup_pull_secrets $NS
        fi

        print_message INFO "generating secrets"
        generate_dataapps_app_secrets ${curr_dir}/setup/dataapps-app.secrets
        rm -f ${curr_dir}/setup/dataapps-oob.secrets
        touch ${curr_dir}/setup/dataapps-oob.secrets
        generate_oob_secrets ${curr_dir}/setup/dataapps-oob.secrets ${NS}

        cat ${curr_dir}/setup/initialize.yaml ${curr_dir}/setup/setup.yaml > ${curr_dir}/setup/kustomization.yaml
        cat ${curr_dir}/setup/mgmt.yaml >> ${curr_dir}/setup/kustomization.yaml

        print_message INFO "setting up gatewy custom headers"
        kubectl create configmap solis-headers-cm-dataapps -n "${NS}" --from-file=headers.conf=${curr_dir}/etc/solis-conf-headers/headers.conf --dry-run=client -o yaml | kubectl label -f - ibmsupport/app=dataapps --local --dry-run=client -o yaml | kubectl apply -n "$NS" -f -

        kc_kust setup

        print_message INFO "$FUNCNAME: $NS"
    else
        # This is not a fresh installation
        set_dns_params
        setid
        update_params

        if [ x"${DATAAPPS_k8s_cfg}" == x"sw_ent_native" ] && [ "X${SKIP_PULL}" != "Xtrue" ];
        then
            # This updates the registry credentials in case
            setup_pull_secrets $NS
        fi

        # Update gateway headers if required
        kubectl create configmap solis-headers-cm-dataapps \
          -n "${NS}" \
          --from-file=headers.conf=${curr_dir}/etc/solis-conf-headers/headers.conf \
          --dry-run=client -o yaml | \
          kubectl label -f - ibmsupport/app=dataapps --local --dry-run=client -o yaml | \
          kubectl apply -n "$NS" -f -

        if ([  x"${DATAAPPS_k8s_cfg}" == xsw_ent_cpfs ] || [  x"${DATAAPPS_k8s_cfg}" == xsw_ent_native ]) && [ $DATAAPPS_UPGRADE == true ];
        then
            print_message INFO "Upgrading...mgmt "
            cp ${curr_dir}/setup/setup.yaml ${curr_dir}/setup/kustomization.yaml
            cat ${curr_dir}/setup/mgmt.yaml >> ${curr_dir}/setup/kustomization.yaml
            kc_kust setup
            wait_for_job "component=dataapps-mgmt-init-tls"
            print_message INFO "$FUNCNAME: $NS"

            source ./config-migrations/migrate.sh
        fi
    fi
}

update_params()
{
    $TRACE updating placeholder parameters, generating yamls..

    basedir=${curr_dir}/app-base
    abdir=${curr_dir}/app-build-cfg
    predir=${curr_dir}/pre-reqs

    export DATAAPPS_DOMAIN="${NS}.svc"

    # Optional IP family ordering for the Services (IP_FAMILIES - comma-separated
    # ordered list of IPv4/IPv6, e.g. "IPv6,IPv4"), rendered into the
    # ${SVC_IP_FAMILIES} placeholder of the Service templates. When unset the
    # placeholder renders empty and the cluster default ordering applies; the
    # policy itself is fixed to PreferDualStack in the templates.
    export SVC_IP_FAMILIES=""
    if [[ -n "${IP_FAMILIES:-}" ]]; then
        SVC_IP_FAMILIES="  ipFamilies:"
        for ip_family in ${IP_FAMILIES//,/ }; do
            if [[ "$ip_family" != "IPv4" && "$ip_family" != "IPv6" ]]; then
                print_message ERROR "Invalid IP family '${ip_family}'. Allowed values: IPv4, IPv6."
                exit 1
            fi
            SVC_IP_FAMILIES+=$'\n'"    - ${ip_family}"
        done
    fi

    if [ x"$DATAAPPS_SCALE_CONFIG" == x ];
    then
        export DATAAPPS_SCALE_CONFIG=level_1
    fi

    sclcfg="${curr_dir}/etc/${DATAAPPS_SCALE_CONFIG}.cfg"
    $TRACE scale_config file: ${sclcfg}
    set -a
    source ${sclcfg}
    set +a

    update_params_yamls  ${curr_dir}/setup
    update_params_yamls  ${curr_dir}/dev-cfg
    update_params_yamls  ${basedir}
    update_params_yamls  ${abdir}
    update_params_yamls  ${predir}

    # Pre-compute all HPA variables before rendering templates so envsubst
    # can substitute plain $VAR patterns. envsubst does not evaluate ${VAR:-default}
    # bash expressions — any unset variable would be passed literally to Kubernetes.
    export DATAAPPS_EPB_HPA_MIN_REPLICAS="${DATAAPPS_EPB_HPA_MIN_REPLICAS:-${DATAAPPS_EPB_REPLICAS}}"
    export DATAAPPS_EPB_HPA_MAX_REPLICAS="${DATAAPPS_EPB_HPA_MAX_REPLICAS:-$((DATAAPPS_EPB_REPLICAS * 2))}"
    export DATAAPPS_IDE_API_HPA_MIN_REPLICAS="${DATAAPPS_IDE_API_HPA_MIN_REPLICAS:-${DATAAPPS_IDE_API_REPLICAS}}"
    export DATAAPPS_IDE_API_HPA_MAX_REPLICAS="${DATAAPPS_IDE_API_HPA_MAX_REPLICAS:-$((DATAAPPS_IDE_API_REPLICAS * 2))}"
    export DATAAPPS_IDE_HPA_MIN_REPLICAS="${DATAAPPS_IDE_HPA_MIN_REPLICAS:-${DATAAPPS_IDE_REPLICAS}}"
    export DATAAPPS_IDE_HPA_MAX_REPLICAS="${DATAAPPS_IDE_HPA_MAX_REPLICAS:-$((DATAAPPS_IDE_REPLICAS * 2))}"
    export DATAAPPS_SOLIS_GW_HPA_MIN_REPLICAS="${DATAAPPS_SOLIS_GW_HPA_MIN_REPLICAS:-${SOLIS_GW_REPLICAS}}"
    export DATAAPPS_SOLIS_GW_HPA_MAX_REPLICAS="${DATAAPPS_SOLIS_GW_HPA_MAX_REPLICAS:-$((SOLIS_GW_REPLICAS * 2))}"
    export DATAAPPS_HPA_CPU_TARGET="${DATAAPPS_HPA_CPU_TARGET:-80}"
    export DATAAPPS_HPA_MEMORY_TARGET="${DATAAPPS_HPA_MEMORY_TARGET:-80}"
    export HPA_SCALEDOWN_STABILIZATION="${HPA_SCALEDOWN_STABILIZATION:-300}"
    update_params_yamls  ${curr_dir}/app-hpa

    # Check if dataapps-postgres should be installed
    # If ADD_POSTGRES is set, include postgres.yaml and ide-api-networkpolicy.yaml
    # Otherwise, use the BYO (Bring Your Own) network policy configuration
    if [ x"${ADD_POSTGRES}" != x ];
    then
        cat ${predir}/postgres.yaml >> ${predir}/kustomization.yaml
        cat ${basedir}/ide-api-networkpolicy.yaml >> ${basedir}/kustomization.yaml
    else
        cat ${basedir}/ide-api-networkpolicy-byo.yaml >> ${basedir}/kustomization.yaml
    fi

    if [ x"${ADD_REDIS}" != x ];
    then
        cat ${predir}/redis.yaml >> ${predir}/kustomization.yaml
    fi

    if [ x"${ADD_SA}" != x ];
    then
        cat ${predir}/serviceaccount.yaml >> ${predir}/kustomization.yaml
    fi
}

## self-contained .. mainly for dev/test - matches ibm-dataapps-dev
## includes postgresql
cfg_sw_ent_native()
{
    print_message INFO "$FUNCNAME: $NS"

    if [ "$BYO_DATABASE" == "false" ];
    then
        export ADD_POSTGRES=true
    fi

    if [ "$BYO_REDIS" == "false" ];
    then
        export ADD_REDIS=true
    fi

    export ADD_SA=true
    export DATAAPPS_AUTH=native
    export DATAAPPS_CONTEXT=sw_ent
    export SEED_DATABASE=true
}

#arg: key=value label condition
wait_for_job()
{
    if [ "X${DATAAPPS_k8s_PREVIEW}" != "X" ];
    then
        return 0
    fi
    print_message INFO "$FUNCNAME: $NS -  $1"
    joblabel="-l $1"

    COUNT=0
    ATTEMPTS=20
    sc=""
    until [[ x"$sc"x != xx ]] || [[ $COUNT -eq $ATTEMPTS ]]; do
        sleep 6
        sc=$(kubectl get -n $NS job --ignore-not-found ${joblabel} -o jsonpath={.items[0].status})
        echo -e "$(( COUNT++ ))... \c"
    done
    echo
    [[ $COUNT -eq $ATTEMPTS ]] && print_message ERROR "failure with $FUNCNAME: $NS $1" && (return 1)

    COUNT=0
    ct=""
    until [[ x"$ct"x != xx ]] || [[ $COUNT -eq $ATTEMPTS ]]; do
        sleep 30
        ct=$(kubectl get -n $NS job --ignore-not-found ${joblabel} -o jsonpath={.items[0].status.completionTime}) 
        echo -e "$(( COUNT++ ))... \c"
    done
    echo

    [[ $COUNT -eq $ATTEMPTS ]] && print_message WARNING "failure with $FUNCNAME: $NS $1 - job did not complete " && (return 1)

    result=$(kubectl get -n $NS job --ignore-not-found ${joblabel} -o jsonpath={.items[0].status.succeeded}) 

    if [ x"$result"x == xx ];
    then
        result=$(kubectl get -n $NS job --ignore-not-found ${joblabel} -o jsonpath={.items[0].status.failed}) 
        print_message WARNING "$NS $1 failed: $result. Completion time: $ct"
    else
        print_message INFO "$NS $1 succeeded: $result. Completion time: $ct"
    fi
    return 0
}

sw_ent_native()
{
    print_message INFO "$FUNCNAME: $NS"
    kc_kust pre-reqs
    kc_kust app-base
    if [[ "${DATAAPPS_ENABLE_HPA}" == "true" ]]; then
        print_message INFO "Deploying HPA resources"
        kc_kust app-hpa
    fi
}

saas_ent()
{
    print_message INFO "$FUNCNAME: $NS"
    kc_kust pre-reqs
    kc_kust app-base
    # HPA is intentionally not enabled for the saas_ent (SaaS/managed) deployment path.
    # This mirrors Concert's roja-dev-utils PR #1314 where saas_ent was also left without
    # the HPA conditional. Enable once the SaaS path is validated for autoscaling.
    # kc_kust app-hpa
}

## with cpfs pre-req
## includes EDB (via CPFS)
cfg_sw_ent_cpfs()
{
    print_message INFO "$FUNCNAME: $NS"

    if [ "$BYO_DATABASE" == "false" ];
    then
        export ADD_POSTGRES=true
    fi

    if [ "$BYO_REDIS" == "false" ];
    then
        export ADD_REDIS=true
    fi

    export ADD_SA=true
    export DATAAPPS_AUTH=cpfs
    export DATAAPPS_CONTEXT=sw_ent
    export SEED_DATABASE=true
}

check_upgrade_cpfs() {
   app_build_cm=dataapps-app-build-cfg-cm
   if kubectl get configmap  "$app_build_cm" -n "$NS" &> /dev/null; then
        print_message INFO "ConfigMap dataapps-app-build-cfg-cm exists."

        CM_IMG_TAG=$(kubectl get configmap "$app_build_cm" -n "$NS" -o jsonpath="{.data.IMG_TAG}")
        if [ -n "$CM_IMG_TAG" ]; then
            print_message INFO "Current image tag is: $CM_IMG_TAG"
            print_message INFO "New image tag is: $IMG_TAG"

            # Compare the value with the expected value
            if [  "$CM_IMG_TAG" == "$IMG_TAG" ]; then
                print_message INFO "Not an upgrade."
            else
                print_message INFO "upgrade needed"
                DATAAPPS_UPGRADE=true
            fi
        else
            print_message INFO "image tag is missing in the config map $app_build_cm"
        fi
    else
        print_message INFO "ConfigMap $app_build_cm does not exist. Its a new deployment."
    fi
}

sw_ent_cpfs()
{
    print_message INFO "$FUNCNAME: $NS"
    kc_kust pre-reqs
    kc_kust app-base
}

## for saas
## out-of-the-box db must be present and secrets created
cfg_saas_ent()
{
    print_message INFO "$FUNCNAME: $NS"

    if [ x"${CLOUD_TYPE}" != x"AWS" ];
    then
        export ADD_SA=true
    fi

    export ADD_REDIS=true
    export DATAAPPS_AUTH=saas
    export DATAAPPS_CONTEXT=saas
}

## no dependencies, repos
cfg_app_only()
{
    print_message INFO "$FUNCNAME: $NS"
    export ADD_SA=true
}

app_only()
{
    print_message INFO "$FUNCNAME: $NS"
    kc_kust pre-reqs
    kc_kust app-base
}


print_header()
{
    print_message INFO "DATAAPPS_k8s_cfg: ${DATAAPPS_k8s_cfg}"
    print_message INFO "IMAGE TAG: $IMG_TAG"
    print_message INFO "NAMESPACE: $NS "
    print_message INFO "REGISTRY: $IMG_PREFIX"
}

pre_process_args()
{
    while [ $# -gt 0 ] ; do
        ######################
        # Required arguments #
        ######################

        if [[ "$1" == --namespace=* ]]
        then
            NS=$(echo $1 | cut -d "=" -f 2) ;
        fi
        if [[ "$1" == --cfg=* ]]
        then
            cfg=$(echo $1 | cut -d "=" -f 2) ;
        fi
        if [[ "$1" == --license_acceptance=* ]]
        then
            license_acceptance=$(echo $1 | cut -d "=" -f 2) ;
        fi
        if [[ "$1" == --storage_class=* ]]
        then
            storage_class=$(echo $1 | cut -d "=" -f 2) ;
        fi

        ######################
        # Optional arguments #
        ######################
        if [[ "$1" == --enable_hpa=* ]]
        then
            enable_hpa=$(echo $1 | cut -d "=" -f 2) ;
        fi
        if [[ "$1" == --hub_url=* ]]
        then
            hub_url=$(echo $1 | cut -d "=" -f 2) ;
            export HUB_URL_EXPORT_LINE="HUB_URL=${hub_url}"
        fi
        if [[ "$1" == --dal_hub_url=* ]]
        then
            dal_hub_url=$(echo $1 | cut -d "=" -f 2) ;
            export DAL_HUB_URL_EXPORT_LINE="DAL_HUB_URL=${dal_hub_url}"
        fi
        if [[ "$1" == --ip_families=* ]]
        then
            export IP_FAMILIES=$(echo $1 | cut -d "=" -f 2) ;
        fi
        if [[ "$1" == --preview=* ]]
        then
            preview=$(echo $1 | cut -d "=" -f 2) ;
        fi
        if [[ "$1" == --scale_config=* ]]
        then
            scale_config=$(echo $1 | cut -d "=" -f 2) ;
        fi
        if [[ "$1" == --userid=* ]]
        then
            export RUNASUSER=$(echo $1 | cut -f2 -d=)
        fi
        if [[ "$1" == --groupid=* ]]
        then
            export RUNASGROUP=$(echo $1 | cut -f2 -d=)
        fi
        if [[ "$1" == --fsgroupid=* ]]
        then
            export FS_GROUPID=$(echo $1 | cut -f2 -d=)
        fi
        if [[ "$1" == --suppgroupid=* ]]
        then
            export SUPP_GROUPID=$(echo $1 | cut -f2 -d=)
        fi
        shift
    done

    if [ "X$license_acceptance" == X ];
    then
        echo "--license_acceptance=y is mandatory"
        exit 1
    fi

    if [ -z ${NS} ];
    then
        echo "Usage:  $0 <namespace>"
        exit 2
    fi

    if [ -z ${cfg} ];
    then
        ### temporary default
        cfg="sw_ent_native"
    fi

    if [ -z ${IMG_PREFIX} ];
    then
        IMG_PREFIX env variable is unset
        exit 1
    fi

    if [ x"${cfg}" == x"sw_ent_native" ] && [ "X${SKIP_PULL}" != "Xtrue" ];
    then
        if [ -z ${REG_USER} ];
        then
            REG_USER env variable is unset
            exit 1
        fi

        if [ -z ${REG_PASS} ];
        then
            REG_PASS env variable is unset
            exit 1
        fi
    fi

    if [ x"${cfg}" == x"saas_ent" ];
    then
        if [ -z ${CLOUD_TYPE} ];
        then
            ### default to IBM
            CLOUD_TYPE="IBM"
        fi
        export CLOUD_TYPE
    fi

    DATAAPPS_k8s_cfg=${DATAAPPS_k8s_cfg:-$cfg}
    DATAAPPS_k8s_PREVIEW=${DATAAPPS_k8s_PREVIEW:-$preview}
    DATAAPPS_STORAGE_CLASS=${DATAAPPS_STORAGE_CLASS:-$storage_class}
    DATAAPPS_SCALE_CONFIG=${DATAAPPS_SCALE_CONFIG:-$scale_config}
    DATAAPPS_ENABLE_HPA=${DATAAPPS_ENABLE_HPA:-$enable_hpa}
    export NS DATAAPPS_k8s_cfg DATAAPPS_k8s_PREVIEW DATAAPPS_STORAGE_CLASS DATAAPPS_SCALE_CONFIG DATAAPPS_ENABLE_HPA

    # Allow user to override the secret used by the
    # ServiceAccounts when pulling images.
    export DATAAPPS_IMG_REG_SECRET=${DATAAPPS_IMG_REG_SECRET:-regcred}
    export MGMT_ROLE_YAML=${CUSTOM_MGMT_ROLE_YAML:-"./110-mgmt-role.yaml"}

    if [ "X${DATAAPPS_k8s_PREVIEW}" != "X" ];
    then
        rm -f ${DATAAPPS_k8s_PREVIEW}
    fi

    if [ x"${DATAAPPS_k8s_cfg}" == x"sw_ent_native" ] || [ x"${DATAAPPS_k8s_cfg}" == x"sw_ent_cpfs" ];
    then
        validate_storage_secrets $NS
    fi

    cfg_${DATAAPPS_k8s_cfg}
}

############### Main  ####################

pre_process_args "$@"

export DATAAPPS_UPGRADE=false

check_upgrade_cpfs

print_header

setup

echo "${KC_ARGS}"
echo Using config ${DATAAPPS_k8s_cfg}
${DATAAPPS_k8s_cfg}

# Check status unless we are doing a dry run
if [ "X${DATAAPPS_k8s_PREVIEW}" == "X" ];
then
   kubectl -n $NS rollout status Deployments,sts -l ibmsupport/app=dataapps --timeout=10m
fi

print_message INFO " DATAAPPS_k8s_cfg $NS : completed."
