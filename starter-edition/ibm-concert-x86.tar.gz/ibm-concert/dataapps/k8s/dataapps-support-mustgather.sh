#!/usr/bin/env bash

#########################################
## IBM Confidential                    ##
## PID: 5900-BD6, 5900-BBE             ##
## Copyright IBM Corp. 2026            ##
#########################################

# IBM Data Apps Support Mustgather for k8s/OCP
#
# Expected usage:
#   ./dataapps-support-mustgather.sh --output-dir=<dir> --namespace=<ns>
#   [--platform=k8s]
#
# Note: Installation logs collection (INSTALLATION-LOGS/) is not yet implemented
#       for Data Apps in k8s. This will be added in a future update.

set -eo pipefail

OUTPUT_DIR=""
NAMESPACE=""
PLATFORM="k8s"
COMPONENT_NAME="IBM Data Apps"
COMPONENT_VERSION=""
COMPONENT_BUILD=""

while [[ $# -gt 0 ]]; do
  case "$1" in
    --output-dir=*)
      OUTPUT_DIR="${1#*=}"
      shift 1
      ;;
    --namespace=*)
      NAMESPACE="${1#*=}"
      shift 1
      ;;
    --platform=*)
      PLATFORM="${1#*=}"
      shift 1
      ;;
    --help|-h)
      echo "Usage: $0 --output-dir=<dir> --namespace=<ns> [--platform=k8s]"
      exit 0
      ;;
    *)
      echo "ERROR: Unknown option: $1" >&2
      exit 1
      ;;
  esac
done

if [ -z "${OUTPUT_DIR}" ] || [ -z "${NAMESPACE}" ]; then
  echo "ERROR: --output-dir and --namespace are required" >&2
  exit 1
fi

if [ "${PLATFORM}" != "k8s" ]; then
  echo "ERROR: Only k8s platform is supported" >&2
  exit 1
fi

OUTPUT_DIR="$(realpath "${OUTPUT_DIR}")"

mkdir -p "${OUTPUT_DIR}/0-README-FIRST" "${OUTPUT_DIR}/1-RUNTIME-DATA"
RUNTIME_LOG="${OUTPUT_DIR}/1-RUNTIME-DATA/runtime.log"
SUMMARY_LOG="${OUTPUT_DIR}/0-README-FIRST/SUMMARY.log"
START_TIME=$(date +%s)

detect_version_metadata() {
  local script_dir build_file
  script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
  build_file="${script_dir}/etc/build_version"

  if [ -f "${build_file}" ]; then
    COMPONENT_BUILD="$(head -n 1 "${build_file}" 2>/dev/null || true)"
    COMPONENT_VERSION="$(echo "${COMPONENT_BUILD}" | sed -nE 's/^v([^-]+)-.*$/\1/p')"
  fi
}

log() {
  local level="$1"
  shift
  local msg="$*"
  local ts
  ts="$(date '+%Y-%m-%d %H:%M:%S')"
  echo "[${ts}] [${level}] ${msg}" | tee -a "${RUNTIME_LOG}" >&2
}

log_section() {
  local title="$1"
  log_info "--------------------------------------------------"
  log_info "${title}"
  log_info "--------------------------------------------------"
}

log_info() { log "INFO" "$@"; }
log_warn() { log "WARN" "$@"; }
log_error() { log "ERROR" "$@"; }

get_k8s_cmd() {
  if command -v oc >/dev/null 2>&1; then
    echo "oc"
  elif command -v kubectl >/dev/null 2>&1; then
    echo "kubectl"
  else
    log_error "Neither oc nor kubectl found in PATH"
    return 1
  fi
}

detect_version_metadata
KCTL="$(get_k8s_cmd)" || exit 1

NS_BASE="${OUTPUT_DIR}/PROD_NAMESPACES/${NAMESPACE}"
mkdir -p "${NS_BASE}"
mkdir -p "${NS_BASE}/configmap"
mkdir -p "${NS_BASE}/deployment.apps"
mkdir -p "${NS_BASE}/endpointslice.discovery.k8s.io"
mkdir -p "${NS_BASE}/hpa"
mkdir -p "${NS_BASE}/ingress"
mkdir -p "${NS_BASE}/networkpolicy"
mkdir -p "${NS_BASE}/pod"
mkdir -p "${NS_BASE}/pvc"
mkdir -p "${NS_BASE}/replicaset.apps"
mkdir -p "${NS_BASE}/route"
mkdir -p "${NS_BASE}/secrets"
mkdir -p "${NS_BASE}/service"

kget_yaml() {
  local kind="$1"
  local ns="$2"
  local out="$3"
  mkdir -p "$(dirname "${out}")"
  "${KCTL}" get "${kind}" -n "${ns}" -o yaml > "${out}" 2>>"${RUNTIME_LOG}" || true
}

run_get_wide_filtered() {
  local kind="$1"
  local out="$2"
  local tmp_out tmp_err
  tmp_out="$(mktemp)"
  tmp_err="$(mktemp)"

  "${KCTL}" get "${kind}" -n "${NAMESPACE}" -o wide > "${tmp_out}" 2>"${tmp_err}" || true

  if [ -s "${tmp_out}" ]; then
    grep -v '^No resources found in .* namespace\.$' "${tmp_out}" > "${out}" || true
  else
    : > "${out}"
  fi

  if [ -s "${tmp_err}" ]; then
    grep -v '^No resources found in .* namespace\.$' "${tmp_err}" > "${tmp_err}.filtered" || true
    if [ -s "${tmp_err}.filtered" ]; then
      cat "${tmp_err}.filtered" >> "${RUNTIME_LOG}" || true
    fi
    rm -f "${tmp_err}.filtered"
  fi

  rm -f "${tmp_out}" "${tmp_err}"
}

collect_previous_logs_if_available() {
  local pod="$1"
  local container="$2"
  local out="$3"

  if "${KCTL}" logs "${pod}" -c "${container}" -n "${NAMESPACE}" --previous > "${out}" 2>"${out}.err"; then
    rm -f "${out}.err"
  else
    if grep -q 'previous terminated container .* not found' "${out}.err"; then
      rm -f "${out}" "${out}.err"
    else
      cat "${out}.err" >> "${RUNTIME_LOG}" || true
      rm -f "${out}.err"
    fi
  fi
}

collect_namespace_info() {
  log_info "Collecting namespace information for ${NAMESPACE}"
  "${KCTL}" get ns "${NAMESPACE}" -o yaml > "${NS_BASE}/namespace.yaml" 2>>"${RUNTIME_LOG}" || true
  "${KCTL}" describe ns "${NAMESPACE}" > "${NS_BASE}/namespace.desc" 2>>"${RUNTIME_LOG}" || true
}

collect_standard_lists() {
  log_info "Collecting standard namespace resource lists"
  : > "${NS_BASE}/oc_all.out"
  local kind
  for kind in cronjobs.batch deployments hpa ingress jobs.batch networkpolicies pods pvc replicasets route services; do
    run_get_wide_filtered "${kind}" "${NS_BASE}/oc_all.out.part"
    if [ -s "${NS_BASE}/oc_all.out.part" ]; then
      cat "${NS_BASE}/oc_all.out.part" >> "${NS_BASE}/oc_all.out"
      echo "" >> "${NS_BASE}/oc_all.out"
    fi
  done
  rm -f "${NS_BASE}/oc_all.out.part"

  run_get_wide_filtered "pods" "${NS_BASE}/oc_pods.out"
  run_get_wide_filtered "pvc" "${NS_BASE}/oc_pvc.out"
}

collect_events() {
  log_info "Collecting events"
  "${KCTL}" get events -n "${NAMESPACE}" --sort-by='.lastTimestamp' > "${NS_BASE}/oc_event.log" 2>>"${RUNTIME_LOG}" || true
}

collect_pods_and_logs() {
  log_info "Collecting pod definitions and logs"
  local pod
  for pod in $("${KCTL}" get pods -n "${NAMESPACE}" -o jsonpath='{.items[*].metadata.name}' 2>>"${RUNTIME_LOG}" || true); do
    [ -z "${pod}" ] && continue
    "${KCTL}" get pod "${pod}" -n "${NAMESPACE}" -o yaml > "${NS_BASE}/pod/${pod}.yaml" 2>>"${RUNTIME_LOG}" || true
    "${KCTL}" describe pod "${pod}" -n "${NAMESPACE}" > "${NS_BASE}/pod/${pod}.desc" 2>>"${RUNTIME_LOG}" || true

    local containers
    containers=$("${KCTL}" get pod "${pod}" -n "${NAMESPACE}" -o jsonpath='{.spec.containers[*].name}' 2>>"${RUNTIME_LOG}" || true)
    for c in ${containers}; do
      [ -z "${c}" ] && continue
      "${KCTL}" logs "${pod}" -c "${c}" -n "${NAMESPACE}" > "${NS_BASE}/pod/${pod}~${c}.log" 2>>"${RUNTIME_LOG}" || true
      collect_previous_logs_if_available "${pod}" "${c}" "${NS_BASE}/pod/${pod}~${c}.previous.log"
    done

    local initcs
    initcs=$("${KCTL}" get pod "${pod}" -n "${NAMESPACE}" -o jsonpath='{.spec.initContainers[*].name}' 2>>"${RUNTIME_LOG}" || true)
    for ic in ${initcs}; do
      [ -z "${ic}" ] && continue
      "${KCTL}" logs "${pod}" -c "${ic}" -n "${NAMESPACE}" > "${NS_BASE}/pod/${pod}~${ic}-init.log" 2>>"${RUNTIME_LOG}" || true
      collect_previous_logs_if_available "${pod}" "${ic}" "${NS_BASE}/pod/${pod}~${ic}-init.previous.log"
    done
  done
}

collect_workloads() {
  log_info "Collecting deployments and replica sets"

  local d
  for d in $("${KCTL}" get deployments -n "${NAMESPACE}" -o name 2>>"${RUNTIME_LOG}" | cut -d/ -f2 || true); do
    [ -z "${d}" ] && continue
    "${KCTL}" get deployment "${d}" -n "${NAMESPACE}" -o yaml > "${NS_BASE}/deployment.apps/${d}.yaml" 2>>"${RUNTIME_LOG}" || true
    "${KCTL}" describe deployment "${d}" -n "${NAMESPACE}" > "${NS_BASE}/deployment.apps/${d}.desc" 2>>"${RUNTIME_LOG}" || true
  done

  local rs
  for rs in $("${KCTL}" get replicasets -n "${NAMESPACE}" -o name 2>>"${RUNTIME_LOG}" | cut -d/ -f2 || true); do
    [ -z "${rs}" ] && continue
    "${KCTL}" get replicaset "${rs}" -n "${NAMESPACE}" -o yaml > "${NS_BASE}/replicaset.apps/${rs}.yaml" 2>>"${RUNTIME_LOG}" || true
    "${KCTL}" describe replicaset "${rs}" -n "${NAMESPACE}" > "${NS_BASE}/replicaset.apps/${rs}.desc" 2>>"${RUNTIME_LOG}" || true
  done

  kget_yaml "jobs.batch" "${NAMESPACE}" "${NS_BASE}/jobs.yaml"
  kget_yaml "cronjobs.batch" "${NAMESPACE}" "${NS_BASE}/cronjobs.yaml"
}

collect_services_ingress_routes() {
  log_info "Collecting services, endpoint slices, ingress resources, and routes"

  local svc
  for svc in $("${KCTL}" get svc -n "${NAMESPACE}" -o name 2>>"${RUNTIME_LOG}" | cut -d/ -f2 || true); do
    [ -z "${svc}" ] && continue
    "${KCTL}" get service "${svc}" -n "${NAMESPACE}" -o yaml > "${NS_BASE}/service/${svc}.yaml" 2>>"${RUNTIME_LOG}" || true
  done

  local eps
  for eps in $("${KCTL}" get endpointslices.discovery.k8s.io -n "${NAMESPACE}" -o name 2>>"${RUNTIME_LOG}" | cut -d/ -f2 || true); do
    [ -z "${eps}" ] && continue
    "${KCTL}" get endpointslice.discovery.k8s.io "${eps}" -n "${NAMESPACE}" -o yaml > "${NS_BASE}/endpointslice.discovery.k8s.io/${eps}.yaml" 2>>"${RUNTIME_LOG}" || true
  done

  local ing
  for ing in $("${KCTL}" get ingress -n "${NAMESPACE}" -o name 2>>"${RUNTIME_LOG}" | cut -d/ -f2 || true); do
    [ -z "${ing}" ] && continue
    "${KCTL}" get ingress "${ing}" -n "${NAMESPACE}" -o yaml > "${NS_BASE}/ingress/${ing}.yaml" 2>>"${RUNTIME_LOG}" || true
    "${KCTL}" describe ingress "${ing}" -n "${NAMESPACE}" > "${NS_BASE}/ingress/${ing}.desc" 2>>"${RUNTIME_LOG}" || true
  done

  local route
  for route in $("${KCTL}" get route -n "${NAMESPACE}" -o name 2>>"${RUNTIME_LOG}" | cut -d/ -f2 || true); do
    [ -z "${route}" ] && continue
    "${KCTL}" get route "${route}" -n "${NAMESPACE}" -o yaml > "${NS_BASE}/route/${route}.yaml" 2>>"${RUNTIME_LOG}" || true
    "${KCTL}" describe route "${route}" -n "${NAMESPACE}" > "${NS_BASE}/route/${route}.desc" 2>>"${RUNTIME_LOG}" || true
  done
}

collect_configmaps() {
  log_info "Collecting config maps"
  local cm
  for cm in $("${KCTL}" get configmaps -n "${NAMESPACE}" -o name 2>>"${RUNTIME_LOG}" | cut -d/ -f2 || true); do
    [ -z "${cm}" ] && continue
    "${KCTL}" get configmap "${cm}" -n "${NAMESPACE}" -o yaml > "${NS_BASE}/configmap/${cm}.yaml" 2>>"${RUNTIME_LOG}" || true
    "${KCTL}" describe configmap "${cm}" -n "${NAMESPACE}" > "${NS_BASE}/configmap/${cm}.desc" 2>>"${RUNTIME_LOG}" || true
  done
}

collect_secrets_metadata() {
  log_info "Collecting secret metadata"
  local s
  for s in $("${KCTL}" get secrets -n "${NAMESPACE}" -o name 2>>"${RUNTIME_LOG}" | cut -d/ -f2 || true); do
    [ -z "${s}" ] && continue
    "${KCTL}" describe secret "${s}" -n "${NAMESPACE}" > "${NS_BASE}/secrets/${s}.desc" 2>>"${RUNTIME_LOG}" || true
    if command -v jq >/dev/null 2>&1; then
      "${KCTL}" get secret "${s}" -n "${NAMESPACE}" -o json 2>>"${RUNTIME_LOG}" \
        | jq 'del(.data)' > "${NS_BASE}/secrets/${s}-metadata.json" 2>>"${RUNTIME_LOG}" || true
      "${KCTL}" get secret "${s}" -n "${NAMESPACE}" -o jsonpath='{.data}' 2>>"${RUNTIME_LOG}" \
        | jq 'keys' > "${NS_BASE}/secrets/${s}.keys.json" 2>>"${RUNTIME_LOG}" || true
    else
      "${KCTL}" get secret "${s}" -n "${NAMESPACE}" -o json 2>>"${RUNTIME_LOG}" \
        | python3 -c 'import json,sys,yaml; obj=json.load(sys.stdin); obj.pop("data", None); yaml.safe_dump(obj, sys.stdout, sort_keys=False)' \
        > "${NS_BASE}/secrets/${s}-metadata.yaml" 2>>"${RUNTIME_LOG}" || true
    fi
  done
}

collect_pvcs() {
  log_info "Collecting PVCs and bound PV details"

  local pvc
  for pvc in $("${KCTL}" get pvc -n "${NAMESPACE}" -o name 2>>"${RUNTIME_LOG}" | cut -d/ -f2 || true); do
    [ -z "${pvc}" ] && continue
    "${KCTL}" get pvc "${pvc}" -n "${NAMESPACE}" -o yaml > "${NS_BASE}/pvc/${pvc}.yaml" 2>>"${RUNTIME_LOG}" || true
    "${KCTL}" describe pvc "${pvc}" -n "${NAMESPACE}" > "${NS_BASE}/pvc/${pvc}.desc" 2>>"${RUNTIME_LOG}" || true
  done

  local pv
  for pv in $("${KCTL}" get pv -o name 2>>"${RUNTIME_LOG}" | cut -d/ -f2 || true); do
    [ -z "${pv}" ] && continue
    local pvc_name pvc_ns
    pvc_name=$("${KCTL}" get pv "${pv}" -o jsonpath='{.spec.claimRef.name}' 2>>"${RUNTIME_LOG}" || echo "")
    pvc_ns=$("${KCTL}" get pv "${pv}" -o jsonpath='{.spec.claimRef.namespace}' 2>>"${RUNTIME_LOG}" || echo "")
    if [ "${pvc_ns}" = "${NAMESPACE}" ] && [ -n "${pvc_name}" ]; then
      "${KCTL}" get pv "${pv}" -o yaml > "${NS_BASE}/pvc/${pv}.yaml" 2>>"${RUNTIME_LOG}" || true
      "${KCTL}" describe pv "${pv}" > "${NS_BASE}/pvc/${pv}.desc" 2>>"${RUNTIME_LOG}" || true
    fi
  done
}

collect_hpa() {
  log_info "Collecting Horizontal Pod Autoscalers"

  local hpa
  for hpa in $("${KCTL}" get hpa -n "${NAMESPACE}" -o name 2>>"${RUNTIME_LOG}" | cut -d/ -f2 || true); do
    [ -z "${hpa}" ] && continue
    "${KCTL}" get hpa "${hpa}" -n "${NAMESPACE}" -o yaml > "${NS_BASE}/hpa/${hpa}.yaml" 2>>"${RUNTIME_LOG}" || true
    "${KCTL}" describe hpa "${hpa}" -n "${NAMESPACE}" > "${NS_BASE}/hpa/${hpa}.desc" 2>>"${RUNTIME_LOG}" || true
  done
}

collect_network_policies() {
  log_info "Collecting network policies"

  local np
  for np in $("${KCTL}" get networkpolicies -n "${NAMESPACE}" -o name 2>>"${RUNTIME_LOG}" | cut -d/ -f2 || true); do
    [ -z "${np}" ] && continue
    "${KCTL}" get networkpolicy "${np}" -n "${NAMESPACE}" -o yaml > "${NS_BASE}/networkpolicy/${np}.yaml" 2>>"${RUNTIME_LOG}" || true
    "${KCTL}" describe networkpolicy "${np}" -n "${NAMESPACE}" > "${NS_BASE}/networkpolicy/${np}.desc" 2>>"${RUNTIME_LOG}" || true
  done
}

collect_version() {
  log_info "Collecting Data Apps status information"
  : > "${NS_BASE}/dataapps-status-all-resources.out"
  local kind
  for kind in deployments hpa replicasets pods services ingress route pvc jobs.batch cronjobs.batch networkpolicies; do
    run_get_wide_filtered "${kind}" "${NS_BASE}/dataapps-status-all-resources.out.part"
    if [ -s "${NS_BASE}/dataapps-status-all-resources.out.part" ]; then
      cat "${NS_BASE}/dataapps-status-all-resources.out.part" >> "${NS_BASE}/dataapps-status-all-resources.out"
      echo "" >> "${NS_BASE}/dataapps-status-all-resources.out"
    fi
  done
  rm -f "${NS_BASE}/dataapps-status-all-resources.out.part"
}

analyze_namespace_health() {
  {
    echo ""
    echo "Namespace Health Summary"
    echo "------------------------"
  } >> "${SUMMARY_LOG}"

  local deployment_statuses
  local pod_statuses
  deployment_statuses=$("${KCTL}" get deployments -n "${NAMESPACE}" -o jsonpath='{range .items[*]}{.metadata.name}{"|"}{.status.readyReplicas}{"|"}{.status.replicas}{"\n"}{end}' 2>>"${RUNTIME_LOG}" || true)
  pod_statuses=$("${KCTL}" get pods -n "${NAMESPACE}" -o jsonpath='{range .items[*]}{.metadata.name}{"|"}{.status.phase}{"|"}{range .status.containerStatuses[*]}{.ready},{end}{"\n"}{end}' 2>>"${RUNTIME_LOG}" || true)

  if [ -z "${deployment_statuses}" ] && [ -z "${pod_statuses}" ]; then
    echo "No resources found in namespace '${NAMESPACE}'." >> "${SUMMARY_LOG}"
    echo "" >> "${SUMMARY_LOG}"
    return 0
  fi

  local failed_deployments=0
  local ready_deployments=0
  local failed_pods=0
  local ready_pods=0
  local completed_pods=0

  while IFS='|' read -r name ready total; do
    [ -z "${name}" ] && continue
    ready="${ready:-0}"
    total="${total:-0}"
    if [ "${total}" -gt 0 ] && [ "${ready}" -eq "${total}" ]; then
      ready_deployments=$((ready_deployments + 1))
    else
      failed_deployments=$((failed_deployments + 1))
    fi
  done <<< "${deployment_statuses}"

  while IFS='|' read -r name phase readiness; do
    [ -z "${name}" ] && continue
    if [ "${phase}" = "Completed" ] || [ "${phase}" = "Succeeded" ]; then
      completed_pods=$((completed_pods + 1))
    elif [ "${phase}" = "Running" ] && ! echo "${readiness}" | grep -q 'false'; then
      ready_pods=$((ready_pods + 1))
    else
      failed_pods=$((failed_pods + 1))
    fi
  done <<< "${pod_statuses}"

  echo "- Deployments ready     : ${ready_deployments}" >> "${SUMMARY_LOG}"
  echo "- Deployments not ready : ${failed_deployments}" >> "${SUMMARY_LOG}"
  echo "- Pods running/ready    : ${ready_pods}" >> "${SUMMARY_LOG}"
  echo "- Pods completed        : ${completed_pods}" >> "${SUMMARY_LOG}"
  echo "- Pods not ready        : ${failed_pods}" >> "${SUMMARY_LOG}"
  echo "- Review events         : PROD_NAMESPACES/${NAMESPACE}/oc_event.log" >> "${SUMMARY_LOG}"
  echo "" >> "${SUMMARY_LOG}"
}

analyze_pvc_status() {
  local oc_pvc_file="${NS_BASE}/oc_pvc.out"
  local good_ctr=0
  local bad_ctr=0
  local total_ctr=0

  {
    echo "PVC Health Summary"
    echo "------------------"
    echo ""
  } >> "${SUMMARY_LOG}"

  if [ ! -s "${oc_pvc_file}" ]; then
    echo "No PVC list collected or namespace has no PVCs." >> "${SUMMARY_LOG}"
    echo "" >> "${SUMMARY_LOG}"
    return 0
  fi

  while IFS= read -r line; do
    [ -z "${line}" ] && continue
    echo "${line}" | grep -q "No resources found" && continue
    local pvc_name pvc_status
    pvc_name=$(echo "${line}" | awk '{print $1}')
    pvc_status=$(echo "${line}" | awk '{print $2}')
    [ -z "${pvc_name}" ] && continue
    [ "${pvc_name}" = "NAME" ] && continue

    total_ctr=$((total_ctr + 1))
    if [ "${pvc_status}" = "Bound" ]; then
      good_ctr=$((good_ctr + 1))
    else
      bad_ctr=$((bad_ctr + 1))
    fi
  done < "${oc_pvc_file}"

  echo "- PVCs bound           : ${good_ctr}" >> "${SUMMARY_LOG}"
  echo "- PVCs not bound       : ${bad_ctr}" >> "${SUMMARY_LOG}"
  echo "- Total PVCs collected : ${total_ctr}" >> "${SUMMARY_LOG}"
  echo "" >> "${SUMMARY_LOG}"
}

generate_summary() {
  local end_time duration version_display build_display
  end_time=$(date +%s)
  duration=$((end_time - START_TIME))
  version_display="${COMPONENT_VERSION:-not detected}"
  build_display="${COMPONENT_BUILD:-not detected}"

  cat > "${SUMMARY_LOG}" <<EOF
==================================================
IBM Data Apps Support Mustgather Summary
==================================================

Overview
--------
Component            : ${COMPONENT_NAME}
Collection Date      : $(date)
Platform             : ${PLATFORM}
Namespace            : ${NAMESPACE}
Version              : ${version_display}
Build                : ${build_display}
Output Directory     : ${OUTPUT_DIR}
Collection Duration  : ${duration} seconds

Collected Data
--------------
- Namespace definition:
  PROD_NAMESPACES/${NAMESPACE}/namespace.(yaml|desc)
- Namespace resource snapshots:
  PROD_NAMESPACES/${NAMESPACE}/oc_all.out
  PROD_NAMESPACES/${NAMESPACE}/oc_pods.out
  PROD_NAMESPACES/${NAMESPACE}/oc_pvc.out
  PROD_NAMESPACES/${NAMESPACE}/oc_event.log
- Pods and container logs:
  PROD_NAMESPACES/${NAMESPACE}/pod/
- Workloads:
  PROD_NAMESPACES/${NAMESPACE}/deployment.apps/
  PROD_NAMESPACES/${NAMESPACE}/replicaset.apps/
- Scheduled and batch workloads:
  PROD_NAMESPACES/${NAMESPACE}/jobs.yaml
  PROD_NAMESPACES/${NAMESPACE}/cronjobs.yaml
- Services:
  PROD_NAMESPACES/${NAMESPACE}/service/
- Endpoint slices:
  PROD_NAMESPACES/${NAMESPACE}/endpointslice.discovery.k8s.io/
- Config maps:
  PROD_NAMESPACES/${NAMESPACE}/configmap/
- Secret metadata:
  PROD_NAMESPACES/${NAMESPACE}/secrets/
- Persistent storage:
  PROD_NAMESPACES/${NAMESPACE}/pvc/
- Ingress and routes:
  PROD_NAMESPACES/${NAMESPACE}/ingress/
  PROD_NAMESPACES/${NAMESPACE}/route/
- Horizontal Pod Autoscalers:
  PROD_NAMESPACES/${NAMESPACE}/hpa/
- Network policies:
  PROD_NAMESPACES/${NAMESPACE}/networkpolicy/
- Consolidated status snapshot:
  PROD_NAMESPACES/${NAMESPACE}/dataapps-status-all-resources.out

Logs
----
- Runtime log:
  1-RUNTIME-DATA/runtime.log

Recommended Review Order
------------------------
1. Start with this SUMMARY.log.
2. Review failing or restarting pod logs under:
   PROD_NAMESPACES/${NAMESPACE}/pod/
3. Review recent namespace events:
   PROD_NAMESPACES/${NAMESPACE}/oc_event.log
4. Review storage status:
   PROD_NAMESPACES/${NAMESPACE}/oc_pvc.out
5. Review the consolidated status snapshot:
   PROD_NAMESPACES/${NAMESPACE}/dataapps-status-all-resources.out

EOF
}

log_section "IBM Data Apps Support Mustgather"
log_info "Namespace        : ${NAMESPACE}"
log_info "Output Directory : ${OUTPUT_DIR}"
log_info "Platform         : ${PLATFORM}"

collect_namespace_info
collect_standard_lists
collect_events
collect_pods_and_logs
collect_workloads
collect_services_ingress_routes
collect_configmaps
collect_secrets_metadata
collect_pvcs
collect_hpa
collect_network_policies
collect_version
generate_summary
analyze_namespace_health
analyze_pvc_status

log_section "Mustgather completed successfully"
log_info "Summary Log      : ${SUMMARY_LOG}"
log_info "Runtime Log      : ${RUNTIME_LOG}"
exit 0

# Made with Bob
