#!/usr/bin/env bash

#########################################
## IBM Confidential                    ##
## PID: 5900-BD6, 5900-BBE             ##
## Copyright IBM Corp. 2026            ##
#########################################

# Component: IBM Concert
# This script collects support data for IBM Concert VM (k3s) and on k8s/OCP 

set -e

OUTPUT_DIR=""
NAMESPACE=""

# Parse arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --output-dir=*)
            OUTPUT_DIR="${1#*=}"
            shift 1
            ;;
        --namespace=*)
            NAMESPACE="${1#*=}"
            shift 1
            ;;
        --platform=*)
            PLATFORM="${1#*=}"
            shift 1
            ;;
        --help|-h)
            echo "Usage: $0 --output-dir=<path> --namespace=<name> [--platform=vm|k8s]"
            exit 0
            ;;
        *)
            echo "ERROR: Unknown parameter: $1"
            echo "Usage: $0 --output-dir=<path> --namespace=<name> [--platform=vm|k8s]"
            exit 1
            ;;
    esac
done

if [ -z "${OUTPUT_DIR}" ]; then
    echo "ERROR: --output-dir parameter is required"
    exit 1
fi

if [ -z "${NAMESPACE}" ]; then
    echo "ERROR: --namespace parameter is required"
    exit 1
fi

mkdir -p "${OUTPUT_DIR}"

PLATFORM="${PLATFORM:-k8s}"

echo "[INFO] IBM Concert mustgather - Output: ${OUTPUT_DIR}, Namespace: ${NAMESPACE}, Platform: ${PLATFORM}"

# TODO: Implement component-specific data collection

echo "[INFO] IBM Concert mustgather completed"
