#!/usr/bin/env bash


curr_dir=`dirname $0`
cd $curr_dir
curr_dir=`pwd`

source ${curr_dir}/k8s-utils.sh

if [[ "${SKIP_CONCERT_MIGRATION}" == "false" ]]; then
    source ${script_dir}/migration-utils.sh
fi

set -e

trap 'catch $? $FUNCNAME $LINENO' EXIT
catch() {
  if [ "$1" != "0" ]; then
    echo "FAILED:  error num: $1 occurred at: $2 $3"
  fi
}

kc_kust()
{
    print_message INFO "kc_kust: $1"
    abdir=${curr_dir}/app-build-cfg
    cat ${abdir}/common.yaml >> ${curr_dir}/$1/kustomization.yaml
    if [ "X${ROJA_k8s_PREVIEW}" != "X" ];
    then
        print_message INFO "ROJA_k8s_PREVIEW: ${ROJA_k8s_PREVIEW}"
        kubectl kustomize ${curr_dir}/${1} >> ${ROJA_k8s_PREVIEW}
    else
        kubectl kustomize ${curr_dir}/${1} |  kubectl apply ${KC_ARGS} --namespace=$NS -f -
    fi
}

setid()
{
   if [[ "x${RUNASUSER}" == "x" ]]
   then
       ifocp=$(kubectl api-resources --api-group=route.openshift.io --no-headers)
       if [[ "x$ifocp" == "x" ]]
       then
           export RUNASUSER=1000
           export RUNASGROUP=1000
           export FS_GROUPID=1000
           export SUPP_GROUPID=1000
           # k3s/EKS/kind aren't SCC-constrained, so leave Osprey's code default fsGroup (1001) in place.
           [[ "${INSTALL_VEIAS}" == "TRUE" ]] && export VEIAS_OSPREY_FS_GROUP=1001
       else
           rangestr=`kubectl get namespace ${NS} -o jsonpath='{.metadata.annotations.openshift\.io/sa\.scc\.uid-range}'`
           rangeid="${rangestr%/*}"
           export RUNASUSER=${rangeid}
           export RUNASGROUP=${rangeid}
           export FS_GROUPID=${rangeid}
           export SUPP_GROUPID=${rangeid}
           # OCP SCC rejects the fixed fsGroup default; leave it empty so the SCC assigns one.
           [[ "${INSTALL_VEIAS}" == "TRUE" ]] && export VEIAS_OSPREY_FS_GROUP=""
       fi
   fi

   echo "RUNASUSER: $RUNASUSER"
   echo "RUNASGROUP: $RUNASGROUP"
   echo "FS_GROUPID: $FS_GROUPID"
   echo "SUPP_GROUPID: $SUPP_GROUPID"

}

setid4upgrade()
{
   if [[ "x${RUNASUSER}" == "x" ]]
   then
       # 1st: read from app-cfg-cm — written at install time, survives pod scale-down if values set
       iduser=$(kubectl get cm app-cfg-cm -n "${NS}" \
           -o jsonpath='{.data.RUNASUSER}' 2>/dev/null || true)

       # 2nd: fall back to the roja-mgmt deployment spec if the configmap value is missing
       if [[ -z "$iduser" ]]; then
           print_message INFO "setid4upgrade: RUNASUSER not in app-cfg-cm, reading from roja-mgmt deployment"
           iduser=$(kubectl get deployment roja-mgmt -n "${NS}" \
               -o jsonpath='{.spec.template.spec.containers[0].securityContext.runAsUser}' 2>/dev/null || true)
       fi

       export RUNASUSER=$iduser
       export RUNASGROUP=$iduser
       export FS_GROUPID=$iduser
       export SUPP_GROUPID=$iduser
   fi

   echo "RUNASUSER: $RUNASUSER"
   echo "RUNASGROUP: $RUNASGROUP"
   echo "FS_GROUPID: $FS_GROUPID"
   echo "SUPP_GROUPID: $SUPP_GROUPID"
}

set_dns_params()
{
    ifocp=$(kubectl api-resources --api-group=route.openshift.io --no-headers)
    if [[ "x$ifocp" == "x" ]]
    then
        # kubernetes
        export DNS_NAMESPACE_LABEL="kubernetes.io/metadata.name: kube-system"
    else
        # ocp
        export DNS_NAMESPACE_LABEL="kubernetes.io/metadata.name: openshift-dns"
    fi

}

apply_prereq_network_policies()
{
    if [ "X${ROJA_k8s_PREVIEW}" != "X" ];
    then
        return 0
    fi

    print_message INFO "Applying pre-requisite NetworkPolicies (MinIO, ConfigDB, AppDB)..."
    
    update_params_yamls ${curr_dir}/app-networkpolicy-prereqs
    kc_kust app-networkpolicy-prereqs
}

apply_app_network_policies()
{
    if [ "X${ROJA_k8s_PREVIEW}" != "X" ];
    then
        return 0
    fi

    if [[ "x${KUBE_API_CIDR}" == "x" ]]
    then
        if [[ "${COMPONENT_DEPLOYMENT_TARGET_CONCERT}" == "k3s" ]]; then
            # VM (k3s): kube-router enforces NetworkPolicy against pre-DNAT destinations.
            # ipBlock with the kubernetes ClusterIP is never matched because kube-router
            # does not populate ipsets for virtual ClusterIPs. Use the real node IP from
            # the kubernetes EndpointSlice instead. Single endpoint, port 6443.
            kube_api_endpoints=$(kubectl get endpointslices -n default \
                -l kubernetes.io/service-name=kubernetes \
                -o jsonpath='{.items[*].endpoints[*].addresses[*]}')
            export KUBE_API_PORT="6443"

        elif [[ "x$(kubectl api-resources --api-group=route.openshift.io --no-headers 2>/dev/null)" != "x" ]]; then
            # OCP: OVN-Kubernetes (newer versions) also evaluates NetworkPolicy pre-DNAT,
            # so ipBlock with the ClusterIP is not matched. Use the real master endpoint IPs
            # from the EndpointSlice. Multiple masters are possible, so we collect all IPs.
            kube_api_endpoints=$(kubectl get endpointslices -n default \
                -l kubernetes.io/service-name=kubernetes \
                -o jsonpath='{.items[*].endpoints[*].addresses[*]}')
            export KUBE_API_PORT="6443"

        else
            # SaaS / standard k8s (EKS, IKS, etc.): CNI evaluates NetworkPolicy post-DNAT,
            # so ipBlock with the kubernetes ClusterIP works correctly on port 443.
            print_message INFO "Waiting for roja-mgmt rollout to complete..."
            kubectl -n ${NS} rollout status deployment/roja-mgmt --timeout=300s

            mgmt_pod=$(kubectl -n ${NS} get pods -l component=roja-mgmt --field-selector=status.phase=Running -o jsonpath='{.items[0].metadata.name}')
            kube_api_endpoints=$(kubectl -n ${NS} exec "${mgmt_pod}" -- sh -c 'echo $KUBERNETES_SERVICE_HOST')
            kube_api_endpoints=$(echo "${kube_api_endpoints}" | tr -d '[:space:]')
            export KUBE_API_PORT="443"
        fi

        if [[ "x${kube_api_endpoints}" == "x" ]]; then
            print_message ERROR "Failed to discover Kubernetes API server endpoints."
            exit 1
        fi

        # Build one ipBlock entry per endpoint IP, detecting IPv6 (contains colons) vs IPv4.
        # For VM and SaaS/k8s this is a single entry; for OCP it may be multiple masters.
        export KUBE_API_EGRESS_BLOCK=""
        for ip in ${kube_api_endpoints}; do
            if [[ "${ip}" == *":"* ]]; then
                cidr="${ip}/128"
            else
                cidr="${ip}/32"
            fi
            KUBE_API_EGRESS_BLOCK+="    - ipBlock:"$'\n'"        cidr: ${cidr}"$'\n'
        done

        print_message INFO "KUBE_API_EGRESS_BLOCK: $KUBE_API_EGRESS_BLOCK, KUBE_API_PORT: $KUBE_API_PORT"
    else
        # KUBE_API_CIDR was pre-supplied externally; default port if not also pre-supplied.
        # Default to 443 (safe for post-DNAT CNIs - EKS, IKS, standard k8s).
        # For k3s or OCP pre-supply, set KUBE_API_PORT=6443 explicitly alongside KUBE_API_CIDR.
        export KUBE_API_PORT="${KUBE_API_PORT:-443}"
        export KUBE_API_EGRESS_BLOCK="    - ipBlock:"$'\n'"        cidr: ${KUBE_API_CIDR}"$'\n'
    fi

    echo "DNS_NAMESPACE_LABEL: $DNS_NAMESPACE_LABEL"
    echo "KUBE_API_PORT: $KUBE_API_PORT"

    print_message INFO "Applying application NetworkPolicies..."
    update_params_yamls ${curr_dir}/app-networkpolicy

    # Check if ADD_POSTGRES is set to determine which compliance networkpolicy to use.
    # Using ADD_POSTGRES (not BYO_* variables) avoids communication issues in SaaS.
    # If ADD_POSTGRES is set, use the standard compliance networkpolicy (internal Postgres).
    # Otherwise, use the BYO variant which adds egress to external IPs for Postgres connectivity.
    if [ x"${ADD_POSTGRES}" != x ];
    then
        echo "- 241-roja-compliance-networkpolicy.yaml" >> ${curr_dir}/app-networkpolicy/kustomization.yaml
    else
        echo "- 241-roja-compliance-networkpolicy-byo.yaml" >> ${curr_dir}/app-networkpolicy/kustomization.yaml
    fi

    kc_kust app-networkpolicy
}

check_and_handle_schema_jobs() {
    local namespace="${1}"

    print_message INFO "Checking for running schema-validation jobs in namespace '${namespace}'..."

    local jobs
    jobs=$(kubectl get jobs -n "${namespace}" -l component=schema-validation -o jsonpath='{.items[*].metadata.name}')

    local all_jobs=()
	for job_name in $jobs; do
		all_jobs+=("${job_name}")
	done

    if [[ ${#all_jobs[@]} -gt 0 ]]; then
        print_message WARN "The following schema-validation jobs are present in '${namespace}':"
        for job in "${all_jobs[@]}"; do
            echo "  - ${job}"
        done
		local delete_cmd="kubectl delete jobs -n ${namespace} -l component=schema-validation --ignore-not-found"
		print_message ERROR "Cannot proceed with the upgrade: schema-validation jobs are still present in the namespace: ${namespace}"
        print_message INFO "Running jobs will continue until completion."
		print_message INFO "Finished jobs (succeeded or failed) will be automatically removed by Kubernetes after 5 minutes (ttlSecondsAfterFinished=300)."
		print_message INFO "Manual deletion is optional, but deleting jobs now may result in incomplete validation and logs."
		print_message INFO "You can cleanup the jobs by running: ${delete_cmd}"
        exit 1
    else
        print_message INFO "No running schema-validation jobs found."
    fi
}

setup()
{
    print_message INFO "initiating setup for $NS.."

    first_time=true
    if [ -z ${ROJA_k8s_PREVIEW} ];
    then
        curr_status=$(kubectl get secret --ignore-not-found app-cfg-internal-tls -o name  -n $NS)
        if [ x"$curr_status" == x"secret/app-cfg-internal-tls" ];
        then
            first_time=false
        fi
    fi

	check_and_handle_schema_jobs "${NS}"

    if [ x"${FORCE_SETUP}" == x"true" ] || [ x"$first_time" == x"true" ];
    then
        ### first time setup - its not idempotent because we cannot change the oob secrets afterwards for the 'native' case.

        setup_namespace $NS

        setid
        set_dns_params
        update_params

        if [ x"${ROJA_k8s_cfg}" == x"sw_ent_native" ];
        then
            setup_pull_secrets $NS 
        fi

        ## this is for the cpfs case when, we want to pull from a dev-test registry instead of relying on Global Pull Secrets
        if [ x"${ROJA_k8s_dev}" != x ];
        then
            setup_pull_secrets $NS 
        fi


        print_message INFO "generating secrets"
        generate_roja_app_secrets ${curr_dir}/setup/roja-app.secrets
        rm -f ${curr_dir}/setup/roja-oob.secrets
        touch ${curr_dir}/setup/roja-oob.secrets
        rm -f ${curr_dir}/setup-cpfs/roja-edb.secrets
        touch ${curr_dir}/setup-cpfs/roja-edb.secrets
        generate_edb_secret ${curr_dir}/setup-cpfs/roja-edb.secrets ${NS}

        generate_oob_secrets ${curr_dir}/setup/roja-oob.secrets ${NS}
        
        if [ x"${ROJA_k8s_cfg}" == xsw_ent_cpfs ];
        then
           cat ${curr_dir}/setup-cpfs/initialize-sw-ent-cpfs.yaml >  ${curr_dir}/setup-cpfs/kustomization.yaml
           cat  ${curr_dir}/setup/initialize.yaml  ${curr_dir}/setup/setup.yaml > ${curr_dir}/setup/kustomization.yaml   
           kc_kust setup-cpfs
        
        else
            cat ${curr_dir}/setup/initialize.yaml > ${curr_dir}/setup/kustomization.yaml
            if [ "$BYO_CONFIGDB" == "false" ] && [ "$BYO_APPDB" == "false" ];
            then
                cat ${curr_dir}/setup/pg-custom.yaml >> ${curr_dir}/setup/kustomization.yaml
            fi
            cat ${curr_dir}/setup/setup.yaml >> ${curr_dir}/setup/kustomization.yaml
        fi
        cat ${curr_dir}/setup/mgmt.yaml >> ${curr_dir}/setup/kustomization.yaml
        kc_kust setup

        wait_for_job "component=roja-mgmt-init-tls"
        print_message INFO "$FUNCNAME: $NS"
    else 

        setid4upgrade
        set_dns_params
        update_params
	update_configmap_for_upgrade ${NS}

        if [ x"${ROJA_k8s_cfg}" == x"sw_ent_native" ];
        then
            setup_pull_secrets $NS
        fi

        if ([  x"${ROJA_k8s_cfg}" == xsw_ent_cpfs ] || [  x"${ROJA_k8s_cfg}" == xsw_ent_native ]) && [ $ROJA_UPGRADE == true ];
        then
            print_message INFO "Upgrading...mgmt "
            echo "configMapGenerator:" > ${curr_dir}/setup/kustomization.yaml
            cat ${curr_dir}/setup/setup.yaml >> ${curr_dir}/setup/kustomization.yaml
            cat ${curr_dir}/setup/mgmt.yaml >> ${curr_dir}/setup/kustomization.yaml
            kc_kust setup
            generate_upgrade_required_secret ${NS}
            wait_for_job "component=roja-mgmt-init-tls"
            print_message INFO "$FUNCNAME: $NS"

            # Add secure if byo is false
            if [ "$BYO_CONFIGDB" == "false" ] && [ "$BYO_APPDB" == "false" ];
            then
                secret_ref=$(kubectl get secret --ignore-not-found app-cfg-oob-secret -o name  -n $NS)
                if [ x"$secret_ref" == x"secret/app-cfg-oob-secret" ];
                then
                    configdb_secure="true"
                    appdb_secure="true"
                    if [  x"${ROJA_k8s_cfg}" == xsw_ent_cpfs ];
                    then
                        configdb_secure="false"
                        appdb_secure="false"
                    fi
                    configdb_secure_encoded=$(echo -n $configdb_secure | base64)
                    appdb_secure_encoded=$(echo -n $appdb_secure | base64)
                    PATCH_OOB_SECRET=$(cat <<EOF
{
"data": {
    "CONFIGDB_SECURE": "${configdb_secure_encoded}", 
    "APPDB_SECURE": "${appdb_secure_encoded}"
    }
}
EOF
)
                    kubectl patch secret app-cfg-oob-secret --type='merge' -n ${NS} -p "$PATCH_OOB_SECRET"
                fi

                # Check for customization configmaps
                pgcm_ref=$(kubectl get configmap --ignore-not-found configdb-custom -o name  -n $NS)
                if [ x"$pgcm_ref" == x"configmap/configdb-custom" ];
                then
                    print_message INFO "Postgres customization configmaps exist"          
                else
                    echo "configMapGenerator:" > ${curr_dir}/setup/kustomization.yaml
                    cat ${curr_dir}/setup/pg-custom.yaml >> ${curr_dir}/setup/kustomization.yaml
                    kc_kust setup
                fi
            fi    
        fi

        # Cleanup successful jobs in SaaS
        if [ x"${ROJA_k8s_cfg}" == xsaas_ent ];
        then
            job_name=$(kubectl get job --ignore-not-found roja-pre-job -o name  -n $NS)
            if [ x"$job_name" == x"job.batch/roja-pre-job" ];
            then
                job_success=$(kubectl get job --ignore-not-found roja-pre-job -o json  -n $NS | jq -r '.status.succeeded')
                if [ x"$job_success" == x"1" ];
                then
                    kubectl delete job --ignore-not-found roja-pre-job -n $NS 
                fi         
            fi
        fi
        print_message INFO "$NS was already setup."

    fi
}

update_params()
{
    $TRACE updating placeholder parameters, generating yamls..

    basedir=${curr_dir}/app-base
    abdir=${curr_dir}/app-build-cfg
    predir=${curr_dir}/pre-reqs

    export ROJA_DOMAIN="${NS}.svc"

    if [ x"$ROJA_SCALE_CONFIG" == x ];
    then
        export ROJA_SCALE_CONFIG=level_1
    fi

    sclcfg="${curr_dir}/etc/${ROJA_SCALE_CONFIG}.cfg"
    $TRACE scale_config file: ${sclcfg}
    set -a
    source ${sclcfg}
    export ROJACORE_APPDB_MAX_POOL_CONN_PER_REPLICA=$(( ROJACORE_APPDB_MAX_CONN / ROJA_CORE_REPLICAS ))
    # Ingestion's budget is shared by both deployments; guard the no-pod case.
    export INGESTION_APPDB_MAX_OPEN_CONNS=$(( (ING_REPLICAS + ING_COMMON_SVC_REPLICAS) > 0 ? INGESTION_APPDB_MAX_CONN / (ING_REPLICAS + ING_COMMON_SVC_REPLICAS) : 0 ))
    set +a

    # Set BUDDY_PVC_ACCESS_MODE based on platform before processing templates
    # Default to ReadWriteMany, override to ReadWriteOnce for K3S
    export BUDDY_PVC_ACCESS_MODE="ReadWriteMany"
    if [[ "${COMPONENT_DEPLOYMENT_TARGET_CONCERT}" == "k3s" ]]; then
        export BUDDY_PVC_ACCESS_MODE="ReadWriteOnce"
        print_message INFO "For VM deployment on k3s, the Buddy PVCs are going to be set to ${BUDDY_PVC_ACCESS_MODE}"
    fi

    # Optional IP family ordering for the Services (IP_FAMILIES - comma-separated
    # ordered list of IPv4/IPv6, e.g. "IPv6,IPv4"), rendered into the
    # ${SVC_IP_FAMILIES} placeholder of the Service templates. When unset the
    # placeholder renders empty and the cluster default ordering applies; the
    # policy itself is fixed to PreferDualStack in the templates.
    export SVC_IP_FAMILIES=""
    if [[ -n "${IP_FAMILIES:-}" ]]; then
        SVC_IP_FAMILIES="  ipFamilies:"
        for ip_family in ${IP_FAMILIES//,/ }; do
            if [[ "$ip_family" != "IPv4" && "$ip_family" != "IPv6" ]]; then
                print_message ERROR "Invalid IP family '${ip_family}'. Allowed values: IPv4, IPv6."
                exit 1
            fi
            SVC_IP_FAMILIES+=$'\n'"    - ${ip_family}"
        done
    fi

    update_params_yamls  ${curr_dir}/setup
    update_params_yamls  ${curr_dir}/setup-cpfs
    update_params_yamls  ${curr_dir}/app-prep
    update_params_yamls  ${curr_dir}/dev-cfg
    update_params_yamls  ${curr_dir}/app-buddy
    update_params_yamls  ${curr_dir}/app-veias
    update_params_yamls  ${basedir}
    update_params_yamls  ${abdir}
    update_params_yamls  ${predir}
    update_params_yamls  ${curr_dir}/app-post-cpfs
    update_params_yamls  ${curr_dir}/app-post-saas
    update_params_yamls  ${curr_dir}/schema-validation
    update_params_yamls  ${curr_dir}/app-metering-events
    update_params_yamls  ${curr_dir}/app-hpa
    update_params_yamls  ${curr_dir}/app-cross-product-ai
    update_params_yamls  ${curr_dir}/migration

    if [ x"${ADD_MINIO}" != x ];
    then
        cat ${predir}/minio.yaml >> ${predir}/kustomization.yaml
        if [[ "${SKIP_CONCERT_MIGRATION}" == "false" ]]; then
            cat ${curr_dir}/migration/minio.yaml >> ${curr_dir}/migration/kustomization.yaml
        fi
    fi

    if [ x"${ADD_POSTGRES}" != x ];
    then
        cat ${predir}/postgres.yaml >> ${predir}/kustomization.yaml
        if [[ "${SKIP_CONCERT_MIGRATION}" == "false" ]]; then
            cat ${curr_dir}/migration/postgres.yaml >> ${curr_dir}/migration/kustomization.yaml
        fi
    fi

    if [ x"${ADD_EDB}" != x ];
    then
        cat ${predir}/edb.yaml >> ${predir}/kustomization.yaml
    fi

    if [ x"${ADD_BUDDY_PVC}" != x ];
    then
        cat ${predir}/buddy.yaml >> ${predir}/kustomization.yaml
    fi

    if [ x"${ADD_SA}" != x ];
    then
        cat ${predir}/serviceaccount.yaml >> ${predir}/kustomization.yaml
    fi

}


## self-contained .. mainly for dev/test - matches ibm-roja-dev
## includes minio, postgresql
cfg_sw_ent_native()
{
    if [ "$BYO_CONFIGDB" == "false" ] && [ "$BYO_APPDB" == "false" ];
    then
        export ADD_POSTGRES=true
        export DB_COMPONENT=roja-postgres
    fi
    if [ "$BYO_ELBUCKET" == "false" ] && [ "$BYO_LZBUCKET" == "false" ];
    then
        export ADD_MINIO=true
    fi
    # Buddy is enabled by default on VM/OCP (sw_ent_native) form factors
    ENABLE_BUDDY=${ENABLE_BUDDY:-true}
    export ENABLE_BUDDY
    if [ "$ENABLE_BUDDY" == "true" ]; then
        # Default file storage class to block storage class if not explicitly set
        FILE_STORAGE_CLASS_CONCERT=${FILE_STORAGE_CLASS_CONCERT:-$ROJA_STORAGE_CLASS}
        export FILE_STORAGE_CLASS_CONCERT
        if [ -z "$FILE_STORAGE_CLASS_CONCERT" ]; then
            echo "Error: FILE_STORAGE_CLASS_CONCERT is not set, which is required for buddy installation"
            exit 1
        fi
        export ADD_BUDDY_PVC=true
    fi
    export ROJA_CONTEXT=sw_ent
    export ADD_SA=true
    export ROJA_AUTH=native
}

# Check for ImagePullBackOff errors in namespace
check_image_pull_errors() {
    local ns=$1
    local label=$2
    
    local pods=$($kc get pods -n "${ns}" -l "${label}" -o jsonpath='{range .items[*]}{.metadata.name}{"\n"}{end}' 2>/dev/null)
    
    if [[ -z "$pods" ]]; then
        return 0
    fi
    
    local has_errors=false
    
    for pod in $pods; do
        local jsonpath_query='{range .status.containerStatuses[*]}'
        jsonpath_query+='{.state.waiting.reason}{"|"}{.image}{"|"}{.state.waiting.message}{"\n"}{end}'
        local container_statuses=$($kc get pod "${pod}" -n "${ns}" -o jsonpath="${jsonpath_query}" 2>/dev/null)
        
        if [[ -n "$container_statuses" ]]; then
            while IFS='|' read -r reason image message; do
                if [[ "$reason" == "ImagePullBackOff" ]] || [[ "$reason" == "ErrImagePull" ]]; then
                    if [[ "$has_errors" == "false" ]]; then
                        print_message "ERROR" "Image pull failures detected in namespace ${ns}:"
                        has_errors=true
                    fi
                    print_message "ERROR" "  Pod: ${pod}"
                    echo "    Image: ${image}" >&2
                    echo "    Error: ${message}" >&2
                fi
            done <<< "$container_statuses"
        fi
    done
    
    if [[ "$has_errors" == "true" ]]; then
        return 1
    fi
    return 0
}

#arg: key=value label condition
# wait_for_job <label> [completion_attempts]
#   completion_attempts controls how many 30s polls to wait for completionTime.
#   Default 20 (10 min).  Pass 60 for long-running jobs (30 min).
wait_for_job()
{
    if [ "X${ROJA_k8s_PREVIEW}" != "X" ];
    then
        return 0
    fi
    print_message INFO "$FUNCNAME: $NS -  $1"
    joblabel="-l $1"
    local completion_attempts="${2:-20}"

    COUNT=0
    ATTEMPTS=20
    sc=""
    until [[ x"$sc"x != xx ]] || [[ $COUNT -eq $ATTEMPTS ]]; do
        sleep 6
        sc=$(kubectl get -n $NS job --ignore-not-found ${joblabel} -o jsonpath={.items[0].status})
        echo -e "$(( COUNT++ ))... \c"
        
        # Check for image pull errors every iteration
        if ! check_image_pull_errors "${NS}" "${1}"; then
            print_message "ERROR" "Cannot proceed due to image pull failures"
            return 1
        fi
    done
    echo
    [[ $COUNT -eq $ATTEMPTS ]] && check_image_pull_errors "${NS}" "${1}" && print_message ERROR "failure with $FUNCNAME: $NS $1" && (return 1)

    COUNT=0
    ct=""
    until [[ x"$ct"x != xx ]] || [[ $COUNT -eq ${completion_attempts} ]]; do
        sleep 30
        ct=$(kubectl get -n $NS job --ignore-not-found ${joblabel} -o jsonpath={.items[0].status.completionTime})
        echo -e "$(( COUNT++ ))... \c"
        
        # Check for image pull errors during completion wait
        if ! check_image_pull_errors "${NS}" "${1}"; then
            print_message "ERROR" "Cannot proceed due to image pull failures"
            return 1
        fi
    done
    echo

    [[ $COUNT -eq ${completion_attempts} ]] && print_message WARNING "failure with $FUNCNAME: $NS $1 - job did not complete " && (return 1)

    result=$(kubectl get -n $NS job --ignore-not-found ${joblabel} -o jsonpath={.items[0].status.succeeded}) 

    if [ x"$result"x == xx ];
    then
        result=$(kubectl get -n $NS job --ignore-not-found ${joblabel} -o jsonpath={.items[0].status.failed}) 
        print_message WARNING "$NS $1 failed: $result. Completion time: $ct"
    else
        print_message INFO "$NS $1 succeeded: $result. Completion time: $ct"
    fi
    return 0
}

wait_for_zen_extn()
{
    if [ "X${ROJA_k8s_PREVIEW}" != "X" ];
    then
        return 0
    fi
    print_message INFO "$FUNCNAME: $NS "
    print_message INFO "Waiting for zen extension to complete"
    COUNT=0
    ATTEMPTS=12
    until [[ x"$sc"x != xx ]] || [[ $COUNT -eq $ATTEMPTS ]]; do
        sleep 5m
        sc=$(kubectl get ZenExtension -n $NS --ignore-not-found -l component=roja-zen-extn -o jsonpath={.items[0].status.zenExtensionStatus})

        echo -e "$(( COUNT++ ))... \c"
    done
    echo
    [[ $COUNT -eq $ATTEMPTS ]] && print_message WARNING "failure with $FUNCNAME: $NS - setting up zen extension " && (return 1)
    echo 
    sc=$(kubectl get ZenExtension -n $NS --ignore-not-found -l component=roja-zen-extn -o jsonpath={.items[0].status.zenExtensionStatus})
    if [ x"$sc"x != x"Completed"x ];
    then
      print_message WARNING "failure with $FUNCNAME: $NS - zen extension " && (return 1)
    else
      print_message INFO "$NS zen extension succeeded"
    fi
    return 0
}

delete_zen_extensions(){
    if [ "X${ROJA_k8s_PREVIEW}" != "X" ];
    then
        return 0
    fi
    print_message INFO "$FUNCNAME: $NS "
    pn=$(kubectl get cm product-configmap -n $NS -o jsonpath={.data.IBM_PRODUCT_NAME})
    if [ x"$pn"x != x"IBM Concert"x ];
    then
      #patch the prod name with IBM Concert
      kubectl patch configmap product-configmap -n $NS -p '{"data":{"IBM_PRODUCT_NAME": "IBM Concert"}}'  
      pn=$(kubectl get cm product-configmap -n $NS -o jsonpath={.data.IBM_PRODUCT_NAME})
      if [ x"$pn"x != x"IBM Concert"x ];
      then
        print_message ERROR "faiure with $FUNCNAME: $NS - failed to update product name " && (return 1)
      fi
      kubectl rollout restart deployment usermgmt -n $NS
    fi
    # get zen secret
    zs=$(kubectl get secret zen-service-broker-secret -n $NS -o jsonpath='{.data.token}' | base64 -d)
    # get zen svc URL
    url=$(kubectl get cm product-configmap -n $NS -o jsonpath={.data.ZEN_CORE_API_URL})
    id_arr=$(curl -k -X GET -H "secret: ${zs}" ${url}/v1/extensions?extension_name=dap-header-service-catalog,zen_homepage_getting_started_internal_service_catalog,dap-support-community,dap-support-diagnostics,dap-support-share-an-idea,zen_homepage_resource_community,zen_homepage_resource_diagnostics,zen_homepage_resource_share_an_idea,dap-support-open-a-ticket,zen_homepage_resource_open_a_ticket,guided_tours,zen_lite_about_modal_info,dap-support-documentation,zen_homepage_resource_document,service_instance_details)
    extn_ids=`echo ${id_arr} | jq -r .data[].id`
    for id in ${extn_ids}; do
        curl -k -X DELETE -H "secret: ${zs}" ${url}/v1/extensions/${id}
    done
    return 0

}

cleanup_concert_migration_resources()
{
    print_message INFO "Cleaning up Concert migration resources in namespace ${NS}..."
    if [ "$BYO_CONFIGDB" == "false" ] && [ "$BYO_APPDB" == "false" ]; then
        kubectl delete job concert-postgres-migration-job -n ${NS} --ignore-not-found
        kubectl delete pvc concert-migration-pvc -n ${NS} --ignore-not-found
    fi
    if [ "$BYO_ELBUCKET" == "false" ] && [ "$BYO_LZBUCKET" == "false" ]; then
        kubectl delete job concert-minio-migration-job -n ${NS} --ignore-not-found
    fi
}

sw_ent_native()
{
    print_message INFO "$FUNCNAME: $NS"
    kc_kust pre-reqs
   # apply_prereq_network_policies

    if [[ "${SKIP_CONCERT_MIGRATION}" == "false" ]] && \
       { [ "$BYO_CONFIGDB" == "false" ] || [ "$BYO_ELBUCKET" == "false" ]; }; then
        cleanup_concert_migration_resources
        kc_kust migration
        if [ "$BYO_CONFIGDB" == "false" ] && [ "$BYO_APPDB" == "false" ]; then
            wait_for_job "component=concert-postgres-migration" 60
        fi
        if [ "$BYO_ELBUCKET" == "false" ] && [ "$BYO_LZBUCKET" == "false" ]; then
            wait_for_job "component=concert-minio-migration"   60
        fi
    fi
    
    kc_kust app-prep
    wait_for_job "component=roja-prep" 60
    kc_kust app-base
   # apply_app_network_policies
    if [[ "${SCHEMA_VALIDATION_REQUIRED}" == "true" ]]; then
    kc_kust schema-validation
    fi
    kc_kust app-metering-events
    if [[ "${ENABLE_CROSS_PRODUCT_INTEGRATION}" == "true" ]]; then
        print_message INFO "Deploying Concert AI resources for cross platform integration"
        kc_kust app-cross-product-ai
    fi
    if [[ "${ENABLE_HPA}" == "true" ]]; then
        print_message INFO "Deploying HPA resources"
        kc_kust app-hpa
    fi
    if [[ "${ENABLE_BUDDY}" == "true" ]]; then
        print_message INFO "Deploying Buddy resources"
        kc_kust app-buddy
    fi
    if [[ "${INSTALL_VEIAS}" == "TRUE" ]]; then
        print_message INFO "Deploying VEIAS resources"
        kc_kust app-veias
    fi
}

saas_ent()
{
    print_message INFO "$FUNCNAME: $NS"
    kc_kust pre-reqs
    kc_kust app-prep
    wait_for_job "component=roja-prep" 60
    kc_kust app-base
    if [[ "${ENABLE_BUDDY}" == "true" ]]; then
        kc_kust app-buddy
    fi
    kc_kust app-post-saas
    # kc_kust app-hpa
    if [[ "${SCHEMA_VALIDATION_REQUIRED}" == "true" ]]; then
    kc_kust schema-validation
    fi
    if [[ "${ENABLE_CROSS_PRODUCT_INTEGRATION}" == "true" ]]; then
        print_message INFO "Deploying Concert AI resources for cross platform integration"
        kc_kust app-cross-product-ai
    fi
}

## with cpfs pre-req
## includes minio, EDB (via CPFS)
cfg_sw_ent_cpfs()
{
    print_message INFO "$FUNCNAME: $NS"
    if [ "$BYO_CONFIGDB" == "false" ] && [ "$BYO_APPDB" == "false" ];
    then
        export ADD_EDB=true
        export DB_COMPONENT=roja-postgres-edb
    fi
    if [ "$BYO_ELBUCKET" == "false" ] && [ "$BYO_LZBUCKET" == "false" ];
    then
        export ADD_MINIO=true
    fi
    # Buddy is enabled by default on all form factors
    ENABLE_BUDDY=${ENABLE_BUDDY:-true}
    export ENABLE_BUDDY
    FILE_STORAGE_CLASS_CONCERT=${FILE_STORAGE_CLASS_CONCERT:-$ROJA_STORAGE_CLASS}
    export FILE_STORAGE_CLASS_CONCERT
    export ADD_BUDDY_PVC=true
    export ADD_SA=true
    export ROJA_CONTEXT=sw_ent
    export ROJA_AUTH=cpfs
    cp ${curr_dir}/app-base/rojacore-deployment.cpfs ${curr_dir}/app-base/305-rojacore-deployment.yaml.tmpl
}

check_upgrade_cpfs() {
   app_build_cm=app-build-cfg-cm 
   if kubectl get configmap  "$app_build_cm" -n "$NS" &> /dev/null; then
        print_message INFO "ConfigMap app-build-cfg-cm exists."

        CM_IMG_TAG=$(kubectl get configmap "$app_build_cm" -n "$NS" -o jsonpath="{.data.IMG_TAG}")
        if [ -n "$CM_IMG_TAG" ]; then
            print_message INFO "Current image tag is: $CM_IMG_TAG"
            print_message INFO "New image tag is: $IMG_TAG"

            # Compare the value with the expected value
            if [  "$CM_IMG_TAG" == "$IMG_TAG" ]; then
                print_message INFO "Not an upgrade."
            else
                print_message INFO "upgrade needed"
                SCHEMA_VALIDATION_REQUIRED="true"
                ROJA_UPGRADE=true
            fi
        else
            print_message INFO "image tag is missing in the config map $app_build_cm"
        fi
    else
        print_message INFO "ConfigMap $app_build_cm does not exist. Its a new deployment."
        SCHEMA_VALIDATION_REQUIRED="true"
    fi
}

sw_ent_cpfs()
{
    print_message INFO "$FUNCNAME: $NS"
    kc_kust pre-reqs
   # apply_prereq_network_policies
    kc_kust app-prep
    wait_for_job "component=roja-prep" 60
    kc_kust app-base
   # apply_app_network_policies
    kc_kust app-post-cpfs
    if [[ "${SCHEMA_VALIDATION_REQUIRED}" == "true" ]]; then
    kc_kust schema-validation
    fi
    kc_kust app-metering-events
    wait_for_zen_extn
    if [[ "${INSTALL_VEIAS}" == "TRUE" ]]; then
        print_message INFO "Deploying VEIAS resources"
        kc_kust app-veias
    fi

    #delete_zen_extensions # no longer needed since we use ibm concert as the main page - and  just zen - not cpd_platform
}

## for saas
## out-of-the-box buckets, dbs must be present and secrets created

cfg_saas_ent()
{
    export ROJA_CONTEXT=saas
    export ROJA_AUTH=solis
    if [ x"${CLOUD_TYPE}" != x"AWS" ];
    then
        export ADD_SA=true
    fi
    if [[ "${ENABLE_BUDDY}" == "true" ]]; then
        if [ -z "$FILE_STORAGE_CLASS_CONCERT" ]; then
            echo "Error: FILE_STORAGE_CLASS_CONCERT is not set, which is required for buddy installation"
            exit 1
        fi
        export ADD_BUDDY_PVC=true
    fi

    print_message INFO "$FUNCNAME: $NS"
}

## no dependencies, repos
cfg_app_only()
{
    print_message INFO "$FUNCNAME: $NS"
    export ADD_SA=true
}

app_only()
{
    print_message INFO "$FUNCNAME: $NS"
    kc_kust pre-reqs
   # apply_prereq_network_policies
    kc_kust app-base
  #  apply_app_network_policies
}


print_header()
{
    print_message INFO "deploy-k8s: $NS"
    print_message INFO "REGISTRY: $IMG_PREFIX"
    print_message INFO "IMAGE TAG: $IMG_TAG"
    print_message INFO "NAMESPACE: $NS "
    print_message INFO "ROJA_k8s_cfg: ${ROJA_k8s_cfg}"
}

pre_process_args()
{
    while [ $# -gt 0 ] ; do
      if [[ "$1" == --namespace=* ]]
      then
         NS=$(echo $1 | cut -d "=" -f 2) ;
      elif [[ "$1" == --cfg=* ]]
      then
         cfg=$(echo $1 | cut -d "=" -f 2) ;
      elif [[ "$1" == --preview=* ]]
      then
         preview=$(echo $1 | cut -d "=" -f 2) ;
      elif [[ "$1" == --enable_buddy=* ]]
      then
         enable_buddy=$(echo $1 | cut -d "=" -f 2) ;
      elif [[ "$1" == --enable_cross_product_integration=* ]]
      then
         enable_cross_product_integration=$(echo $1 | cut -d "=" -f 2) ;
      elif [[ "$1" == --storage_class=* ]]
      then
         storage_class=$(echo $1 | cut -d "=" -f 2) ;
      elif [[ "$1" == --file_storage_class=* ]]
      then
         file_storage_class=$(echo $1 | cut -d "=" -f 2) ;
      elif [[ "$1" == --scale_config=* ]]
      then
         scale_config=$(echo $1 | cut -d "=" -f 2) ;
      elif [[ "$1" == --enable_hpa=* ]]
      then
         enable_hpa=$(echo $1 | cut -d "=" -f 2) ;
      elif [[ "$1" == --external_host=* ]]
      then
         EXTERNAL_HOST=$(echo $1 | cut -d "=" -f 2) ;
      elif [[ "$1" == --hub_url=* ]]
      then
         hub_url=$(echo $1 | cut -d "=" -f 2) ;
         export HUB_URL_EXPORT_LINE="HUB_URL=${hub_url}"
      elif [[ "$1" == --dal_hub_url=* ]]
      then
         dal_hub_url=$(echo $1 | cut -d "=" -f 2) ;
         export DAL_HUB_URL_EXPORT_LINE="DAL_HUB_URL=${dal_hub_url}"
      elif [[ "$1" == --ip_families=* ]]
      then
         export IP_FAMILIES=$(echo $1 | cut -d "=" -f 2) ;
      else
         NS=$1
         ### temporary default
      fi
      shift
    done


    if [ -z ${NS} ];
    then
        echo "Usage:  $0 <namespace>"
        exit 2
    fi

    if [ -z ${cfg} ];
    then
        ### temporary default
        cfg="sw_ent_native"
    fi


    if [ -z ${IMG_PREFIX} ];
    then
        echo "IMG_PREFIX env variable is unset"
        exit 1
    fi


    if [ x"${cfg}" == x"sw_ent_native" ] && [ "X${SKIP_PULL}" != "Xtrue" ];
    then
        if [ -z ${REG_USER} ];
        then
            echo "REG_USER env variable is unset"
            exit 1
        fi

        if [ -z ${REG_PASS} ];
        then
            echo "REG_PASS env variable is unset"
            exit 1
        fi
    fi

    if [ x"${cfg}" == x"saas_ent" ];
    then
        if [ -z ${CLOUD_TYPE} ];
        then
            ### default to IBM
            CLOUD_TYPE="IBM"
        fi
        export CLOUD_TYPE
    fi

    if [ x"${cfg}" == x"saas_ent" ]; then
        export ROJA_METERING_COLLECT_SCHEDULE="30 * * * *"
    else
        export ROJA_METERING_COLLECT_SCHEDULE="30 0 * * *"
    fi

    ROJA_k8s_cfg=${ROJA_k8s_cfg:-$cfg}
    ROJA_k8s_PREVIEW=${ROJA_k8s_PREVIEW:-$preview}
    ROJA_STORAGE_CLASS=${ROJA_STORAGE_CLASS:-$storage_class}
    ENABLE_BUDDY=${ENABLE_BUDDY:-$enable_buddy}
    ENABLE_CROSS_PRODUCT_INTEGRATION=${ENABLE_CROSS_PRODUCT_INTEGRATION:-$enable_cross_product_integration}
    FILE_STORAGE_CLASS_CONCERT=${FILE_STORAGE_CLASS_CONCERT:-$file_storage_class}
    if [ x"${ROJA_k8s_cfg}" == xsaas_ent ];
    then
        ENABLE_BUDDY=true
    fi
    ROJA_SCALE_CONFIG=${ROJA_SCALE_CONFIG:-$scale_config}
    ENABLE_HPA=${ENABLE_HPA:-$enable_hpa}
    export NS ROJA_k8s_cfg ROJA_k8s_PREVIEW ROJA_STORAGE_CLASS ROJA_SCALE_CONFIG
    export NS ROJA_k8s_cfg ROJA_k8s_PREVIEW ROJA_STORAGE_CLASS FILE_STORAGE_CLASS_CONCERT ENABLE_HPA ENABLE_BUDDY ROJA_SCALE_CONFIG ENABLE_CROSS_PRODUCT_INTEGRATION

    # Allow user to override the secret used by the
    # ServiceAccounts when pulling images.
    export ROJA_IMG_REG_SECRET=${ROJA_IMG_REG_SECRET:-regcred}
    export MGMT_ROLE_YAML=${CUSTOM_MGMT_ROLE_YAML:-"./110-mgmt-role.yaml"}

    if [ "X${ROJA_k8s_PREVIEW}" != "X" ];
    then
        rm -f ${ROJA_k8s_PREVIEW}
    fi

    if [[ "${SKIP_CONCERT_MIGRATION}" == "false" ]]; then
        inspect_std_concert_byo "${CONCERT_STD_MIGRATION_DIR:-${CONCERT_STD_DIR}}"
        setup_namespace "${NS}"
        create_std_concert_byo_secrets "${NS}" "${CONCERT_STD_MIGRATION_DIR:-${CONCERT_STD_DIR}}"
    fi

    if [ x"${ROJA_k8s_cfg}" == x"sw_ent_native" ] || [ x"${ROJA_k8s_cfg}" == x"sw_ent_cpfs" ];
    then
        validate_storage_secrets $NS
    fi

    cfg_${ROJA_k8s_cfg}
}

function chat_config() {
    export chat_target_product_id='set $target_product_id "concert";'
    export chat_target_product_url='set $target_product_url "";'
    export chat_new_uri='set $new_uri "";'
    export chat_new_host_header='set $new_host_header "";'
    export chat_proxy_set_header_host='proxy_set_header Host $new_host_header;'
    export chat_X_ForwardedFor='proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;'
    export chat_rewrite='rewrite_by_lua_file /nginx_data/lib/host-lookup.lua;'
    export chat_proxy_pass='proxy_pass $new_uri;'
    export chat_X_Final_URL='add_header X-Final-URL $new_uri;'
    export chat_X_Real_IP='proxy_set_header X-Real-IP $remote_addr;'
    export chat_X_Forwarded_Proto='proxy_set_header X-Forwarded-Proto $scheme;'
}

function buddy_config() {
    export buddy_target_product_id='set $target_product_id "concert";'
    export buddy_target_product_url='set $target_product_url "";'
    export buddy_new_uri='set $new_uri "";'
    export buddy_new_host_header='set $new_host_header "";'
    export buddy_proxy_set_header_host='proxy_set_header Host $new_host_header;'
    export buddy_X_ForwardedFor='proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;'
    export buddy_rewrite='rewrite_by_lua_file /nginx_data/lib/host-lookup.lua;'
    export buddy_proxy_pass='proxy_pass $new_uri;'
    export buddy_X_Final_URL='add_header X-Final-URL $new_uri;'
    export buddy_X_Real_IP='proxy_set_header X-Real-IP $remote_addr;'
    export buddy_X_Forwarded_Proto='proxy_set_header X-Forwarded-Proto $scheme;'
}


function securecoder_config() {
    export securecoder_access_by_lua='access_by_lua_block {
        local auth_header = ngx.var.http_Authorization
        if auth_header and string.match(auth_header, "C_API_KEY .*") then
            -- Call roja
            local http = require("resty.http")
            local http_headers = require("resty.http_headers")

            local headers = http_headers.new()
            headers["Authorization"] = auth_header
            headers["InstanceId"] = ngx.var.http_InstanceId
            headers["Content-Type"] = "application/json"

            local params = {
                method = "POST",
                path = "/core/api/v1/authorize",
                version = 1.1,
                headers = headers,
            }

            local httpc = require("resty.http").new()
            local ns = ".roja.svc"
            local res, err = httpc:request_uri("https://ibm-rojacore-svc" .. ns .. ":8000", params)

            if not res then
                -- ngx.log(ngx.ERR, "request failed: ", err)
                return nil, "request failed, err=" .. err
            end

            local status = res.status
            if status > 299 then
                return nil, "response error from authorization status=" .. status
            end
        end
      }'
    export securecoder_rewrite_by_lua='rewrite_by_lua_block {
        local securecoder_uri = ngx.var.uri
        local new_securecoder_uri = securecoder_uri:gsub("^/securecoder/?", "/", 1)
        ngx.req.set_uri(new_securecoder_uri)
      }'
    export securecoder_target_product_id='set $target_product_id "securecoder";'
    export securecoder_target_product_url='set $target_product_url "";'
    export securecoder_new_uri='set_by_lua $securecoder_ns '"'"'return env_util.get_env("SECURECODER_NS")'"'"';
      set $new_uri "https://securecoder-service.$securecoder_ns.svc.cluster.local:20443";'
    export securecoder_proxy_set_header_host='proxy_set_header Host $host;'
    export securecoder_X_ForwardedFor='proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;'
    export securecoder_proxy_pass='proxy_pass $new_uri;'
    export securecoder_X_Final_URL='add_header X-Final-URL $new_uri;'
    export securecoder_X_Real_IP='proxy_set_header X-Real-IP $remote_addr;'
    export securecoder_X_Forwarded_Proto='proxy_set_header X-Forwarded-Proto $scheme;'
}

############### Main  ####################

export RUN_ID=$(date +"%s")

chat_config
buddy_config
securecoder_config

pre_process_args "$@"

export SCHEMA_VALIDATION_REQUIRED="false"

export ROJA_UPGRADE=false

check_upgrade_cpfs

#update_params

print_header

setup

echo Using config ${ROJA_k8s_cfg}
${ROJA_k8s_cfg}

# Check status unless we are doing a dry run
if [ "X${ROJA_k8s_PREVIEW}" == "X" ];
then
   kubectl -n $NS rollout status Deployments,sts -l ibmsupport/app=roja --timeout=10m
fi

if [[ "${SKIP_CONCERT_MIGRATION}" == "false" ]] && \
   { [ "$BYO_CONFIGDB" == "false" ] || [ "$BYO_ELBUCKET" == "false" ]; }; then
    if [ "$BYO_CONFIGDB" == "false" ] && [ "$BYO_APPDB" == "false" ]; then
        print_message INFO "=== Concert postgres migration job logs ==="
        if kubectl get pods -n ${NS} -l component=concert-postgres-migration --ignore-not-found 2>/dev/null | grep -q .; then
            kubectl logs -n ${NS} -l component=concert-postgres-migration --tail=-1 2>/dev/null || true
        else
            print_message INFO "No concert-postgres-migration pods found — skipping log collection"
        fi
    fi
    if [ "$BYO_ELBUCKET" == "false" ] && [ "$BYO_LZBUCKET" == "false" ]; then
        print_message INFO "=== Concert minio migration job logs ==="
        if kubectl get pods -n ${NS} -l component=concert-minio-migration --ignore-not-found 2>/dev/null | grep -q .; then
            kubectl logs -n ${NS} -l component=concert-minio-migration --tail=-1 2>/dev/null || true
        else
            print_message INFO "No concert-minio-migration pods found — skipping log collection"
        fi
    fi
    cleanup_concert_migration_resources
fi

print_message INFO " ROJA_k8s_cfg $NS : completed."