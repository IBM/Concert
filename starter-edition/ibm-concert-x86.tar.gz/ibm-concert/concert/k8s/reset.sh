#!/usr/bin/env bash

#########################################
## IBM Confidential                    ##
## PID: 5900-BD6, 5900-BBE             ##
## Copyright IBM Corp. 2024            ##
#########################################

set -e

UTILS_BIN_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${UTILS_BIN_DIR}/k8s-utils.sh"

PARAMS_FILE="${UTILS_BIN_DIR}/../etc/params.ini"
if [[ ! -f "${PARAMS_FILE}" ]]; then
	print_message ERROR "Required params file not found: ${PARAMS_FILE}"
	exit 1
fi
readonly CDW_BIN_DIR=$(cd ../bin && pwd)

set -a
source "${PARAMS_FILE}"
set +a

motd() {
	cat <<EOM
###########################################################
#        Script for reseting the data in concert          #
###########################################################
EOM
}

usage() {
	exitCode=${1:-0}
	cat <<EOM
Usage: ${0##*/} [-h --help] [-v --verbose]

Flags:
  -h    --help              Show this message.
  -v    --verbose           Enable verbose shell tracing.

Defaults:
  Required values are sourced from: ${PARAMS_FILE}

WARNING: This script will reset ALL data in the Concert instance.
         You will be prompted for confirmation before proceeding.

EOM
	exit "${exitCode}"
}

for arg in "$@"; do
	case "$arg" in
	--help) set -- "$@" "-h" ;;
	--verbose) set -- "$@" "-v" ;;
	*) set -- "$@" "$arg" ;;
	esac
	shift
done

while getopts ":hv" opt; do
	case "${opt}" in
	h)
		motd
		usage
		;;
	v)
		VERBOSE=1
		;;
	\?)
		echo "Error: invalid option: -${OPTARG}"
		usage 1
		;;
	:)
		echo "Error: option -${OPTARG} requires an argument"
		usage 1
		;;
	*)
		echo "Error: invalid option"
		usage 1
		;;
	esac
done
# Variables
if [[ -f "${CDW_BIN_DIR}/common-utils.sh" ]]; then
    eval "$(declare -f print_message | sed '1s/print_message/print_message_saved/')"
    source "${CDW_BIN_DIR}/common-utils.sh"
    eval "$(declare -f print_message_saved | sed '1s/print_message_saved/print_message/')"
    unset -f print_message_saved
	validate_common_parameters
	determine_installation_platform
	validate_concert_parameters
fi
NAMESPACE=${NAMESPACE:-${CONCERT_NS}}
STORAGE_CLASS=${STORAGE_CLASS:-${STORAGE_CLASS_CONCERT}}
SCALE_CONFIG=${SCALE_CONFIG:-${SCALE_CONFIG_CONCERT:-"level_1"}}
IMG_PREFIX=${IMG_PREFIX:-"${IMAGE_REGISTRY_PREFIX:-cp.icr.io/cp}${CONCERT_IMAGE_REGISTRY_SUFFIX:-/concert}"}

export ROJA_STORAGE_CLASS=${STORAGE_CLASS}
export IMG_PREFIX

# Functions
debug() {
	set -x
}

wait_for_job() {
	if [ "X${ROJA_k8s_PREVIEW}" != "X" ]; then
		return 0
	fi
	print_message INFO "$FUNCNAME: $NAMESPACE -  $1"
	joblabel="-l $1"

	COUNT=0
	ATTEMPTS=20
	sc=""
	until [[ x"$sc"x != xx ]] || [[ $COUNT -eq $ATTEMPTS ]]; do
		sleep 6
		sc=$(kubectl get -n $NAMESPACE job --ignore-not-found ${joblabel} -o jsonpath={.items[0].status})
		echo -e "$((COUNT++))... \c"
	done
	echo
	[[ $COUNT -eq $ATTEMPTS ]] && print_message ERROR "failure with $FUNCNAME: $NAMESPACE $1" && (return 1)

	COUNT=0
	ct=""
	until [[ x"$ct"x != xx ]] || [[ $COUNT -eq $ATTEMPTS ]]; do
		sleep 30
		ct=$(kubectl get -n $NAMESPACE job --ignore-not-found ${joblabel} -o jsonpath={.items[0].status.completionTime})
		echo -e "$((COUNT++))... \c"
	done
	echo

	[[ $COUNT -eq $ATTEMPTS ]] && print_message WARNING "failure with $FUNCNAME: $NAMESPACE $1 - job did not complete " && (return 1)

	result=$(kubectl get -n $NAMESPACE job --ignore-not-found ${joblabel} -o jsonpath={.items[0].status.succeeded})

	if [ x"$result"x == xx ]; then
		result=$(kubectl get -n $NAMESPACE job --ignore-not-found ${joblabel} -o jsonpath={.items[0].status.failed})
		print_message WARNING "$NAMESPACE $1 failed: $result. Completion time: $ct"
	else
		print_message INFO "$NAMESPACE $1 succeeded: $result. Completion time: $ct"
	fi
	return 0
}

kc_kust() {
	print_message INFO "kc_kust: $1"
	abdir=${UTILS_BIN_DIR}/app-build-cfg
	cat ${abdir}/common.yaml >>${UTILS_BIN_DIR}/$1/kustomization.yaml
	kubectl kustomize ${curr_dir}/${1} | kubectl apply ${KC_ARGS} --namespace=$NAMESPACE -f -
}

check() {
	if [[ -z ${NAMESPACE} ]] || [[ -z ${STORAGE_CLASS} ]] || [[ -z ${SCALE_CONFIG} ]] || [[ -z ${IMG_PREFIX} ]]; then
		print_message ERROR "Missing required values in ${PARAMS_FILE}."
		exit 1
	fi
}

load_security_context() {
	RUNASUSER=${RUNASUSER:-$(kubectl get cm app-cfg-cm -n "${NAMESPACE}" -o jsonpath='{.data.RUNASUSER}' 2>/dev/null || true)}
	RUNASGROUP=${RUNASGROUP:-$(kubectl get cm app-cfg-cm -n "${NAMESPACE}" -o jsonpath='{.data.RUNASGROUP}' 2>/dev/null || true)}
	FS_GROUPID=${FS_GROUPID:-$(kubectl get cm app-cfg-cm -n "${NAMESPACE}" -o jsonpath='{.data.FS_GROUPID}' 2>/dev/null || true)}
	SUPP_GROUPID=${SUPP_GROUPID:-$(kubectl get cm app-cfg-cm -n "${NAMESPACE}" -o jsonpath='{.data.SUPP_GROUPID}' 2>/dev/null || true)}

	RUNASUSER=${RUNASUSER:-1000}
	RUNASGROUP=${RUNASGROUP:-1000}
	FS_GROUPID=${FS_GROUPID:-1000}
	SUPP_GROUPID=${SUPP_GROUPID:-1000}
	FSGROUP_POLICY=${FSGROUP_POLICY:-OnRootMismatch}

	export RUNASUSER RUNASGROUP FS_GROUPID SUPP_GROUPID FSGROUP_POLICY
}

confirm_reset() {
	echo ""
	echo "╔══════════════════════════════════════════════════════════════════╗"
	echo "║                        WARNING                                   ║"
	echo "║                                                                  ║"
	echo "║    This operation will RESET ALL DATA in the concert instance!   ║"
	echo "║                                                                  ║"
	echo "║    The following will be deleted:                                ║"
	echo "║      • All MinIO data                                            ║"
	echo "║      • All PostgreSQL databases (appdb, cfgdb)                   ║"
	echo "║      • All persistent volume claims                              ║"
	echo "║                                                                  ║"
	echo "║    This action CANNOT be undone!                                 ║"
	echo "╚══════════════════════════════════════════════════════════════════╝"
	echo ""
	echo "Namespace: ${NAMESPACE}"
	echo "Storage Class: ${STORAGE_CLASS}"
	echo "Scale Config: ${SCALE_CONFIG}"
	echo ""
	read -p "Are you sure you want to proceed with the reset? (yes/no): " -r
	echo ""
	if [[ ! $REPLY =~ ^[Yy][Ee][Ss]$ ]]; then
		print_message INFO "Reset operation cancelled by user."
		exit 0
	fi
	print_message INFO "User confirmed. Proceeding with reset..."
}

print_header() {
	print_message INFO "NAMESPACE: ${NAMESPACE}"
	print_message INFO "STORAGE_CLASS: ${STORAGE_CLASS}"
	print_message INFO "SCALE_CONFIG: ${SCALE_CONFIG}"
}

wipe() {
	print_message INFO "Cleaning up the concert data..."
	local predir
	local abdir
	predir="${UTILS_BIN_DIR}/pre-reqs"
	abdir="${UTILS_BIN_DIR}/app-build-cfg"
	set -a
	source "${UTILS_BIN_DIR}/etc/${SCALE_CONFIG}.cfg"
	source "${UTILS_BIN_DIR}/etc/level_0.cfg"
	set +a
	update_params_yamls "${abdir}"
	update_params_yamls "${predir}"
	update_params_yamls "${UTILS_BIN_DIR}/app-prep"
	cat "${predir}/minio.yaml" >>"${predir}/kustomization.yaml"
	cat "${predir}/serviceaccount.yaml" >>"${predir}/kustomization.yaml"
	cat "${predir}/postgres.yaml" >>"${predir}/kustomization.yaml"
	cat "${abdir}/common.yaml" >>"${predir}/kustomization.yaml"
	print_message INFO "Scaling down the pods of minio ,appdb, cfgdb..."
	kubectl kustomize "${predir}" | kubectl apply ${KC_ARGS} --namespace="${NAMESPACE}" -f -
	print_message INFO "Successfully scale down the pods of minio ,appdb, cfgdb."
	print_message INFO "Deleting the pvc's of minio ,appdb, cfgdb..."
	kubectl delete pvc data-roja-minio-{0..2} roja-appdb-pvc roja-configdb-pvc --ignore-not-found --namespace="${NAMESPACE}"
	print_message INFO "Successfully deleted the pvc's of minio ,appdb, cfgdb."
	print_message INFO "Successfully cleaned up the concert data."
}

setup() {
	print_message INFO "Resetting the concert instance..."
	unset MINIO_REPLICAS CFGDB_REPLICAS APPDB_REPLICAS
	local predir
	local abdir
	predir="${UTILS_BIN_DIR}/pre-reqs"
	abdir="${UTILS_BIN_DIR}/app-build-cfg"
	set -a
	source "${UTILS_BIN_DIR}/etc/${SCALE_CONFIG}.cfg"
	set +a
	if [[ "${INSTALL_VM}" == "TRUE" ]]; then
		load_security_context
	fi
	update_params_yamls "${abdir}"
	update_params_yamls "${predir}"
	update_params_yamls "${UTILS_BIN_DIR}/app-prep"
	cat "${predir}/minio.yaml" >>"${predir}/kustomization.yaml"
	cat "${predir}/serviceaccount.yaml" >>"${predir}/kustomization.yaml"
	cat "${predir}/postgres.yaml" >>"${predir}/kustomization.yaml"
	cat "${abdir}/common.yaml" >>"${predir}/kustomization.yaml"
	kc_kust pre-reqs
	kc_kust app-prep
	wait_for_job "component=roja-prep" 60
	print_message INFO "Successfully completed the concert reset."
}

#################
#     Logic     #
#################

if [[ -n ${VERBOSE} ]]; then
	debug
fi
check
print_header
confirm_reset
wipe
setup
