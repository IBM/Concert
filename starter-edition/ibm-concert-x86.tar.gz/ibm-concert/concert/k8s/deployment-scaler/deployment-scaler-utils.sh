#!/bin/sh

#########################################
## IBM Confidential                    ##
## PID: 5900-BD6, 5900-BBE             ##
## Copyright IBM Corp. 2026            ##
#########################################

set -euo pipefail

SCALE_LEVEL=""
ROLLOUT_TIMEOUT=10m

### ========= Help Function ========= ###

show_help() {
    cat << EOF
    
IBM Concert Deployments Scale Script
================================================================================

Description:
    Scales IBM Concert deployments to a specific resource level.
    This script is typically executed inside Kubernetes Jobs/CronJobs.

Usage: 
    $(basename "$0") [OPTIONS]

Options:
    --scale-level=<level>    Scale level (required)
                             Valid: level_0, level_1, level_2, level_3, level_3_1, level_3_2, level_4
    -h, --help               Display this help message

Examples:
    # Scale to level_1 (minimal resources)
    $(basename "$0") --scale-level=level_1

    # Scale to level_3 (high resources)
    $(basename "$0") --scale-level=level_3

Available Scale Levels:
    level_0    - All replicas set to 0 (shutdown)
    level_1    - Minimal resources (1 replica for most services)
    level_2    - Medium resources (2 replicas for most services)
    level_3    - High resources (3 replicas for most services)
    level_3_1  - High resources with increased replicas for key services
    level_3_2  - High resources with optimized (reduced) resource requests
    level_4    - Maximum resources (4 replicas for most services)

EOF
}

### ========= Logging Functions ========= ###

print() {
    local level message color label nocolor timestamp

    timestamp=$(date -u +"%Y-%m-%d %H:%M:%S %Z")
    nocolor='\033[0m'

    level="info"
    message="$1"

    if [[ $# -eq 2 ]]; then
        level="$1"
        message="$2"
    fi

    case "$level" in
        info)
            color='\033[0;32m'
            label='[INFO]'
            ;;
        error)
            color='\033[0;31m'
            label='[ERROR]'
            ;;
        warn)
            color='\033[0;33m'
            label='[WARN]'
            ;;
    esac

    echo -e "[${timestamp}] ${color}${label}${nocolor} ${message}"
}

### ========= Validation Functions ========= ###

validate_prerequisites() {
    for cmd in kubectl jq; do
        if ! command -v "$cmd" >/dev/null 2>&1; then
            print error "Required command not found: $cmd"
            exit 2
        fi
    done    
}

### ========= Reusable Functions ========= ###

wait_for_rollout() {
    local failed=0
    echo
    print "Waiting for deployments rollout to complete (timeout: $ROLLOUT_TIMEOUT each)..."

    for deploy in $(kubectl get deploy -o name | grep -v 'roja-postgres-'); do
        local deploy_name="${deploy##*/}"
        
        print "Checking rollout: ${deploy_name}"
        if ! kubectl rollout status "$deploy" --timeout="$ROLLOUT_TIMEOUT"; then
            print error "Rollout failed: ${deploy_name}"
            failed=1
        fi
    done

    if [[ "$failed" -ne 0 ]]; then
        print error "One or more deployments failed rollout"
        exit 3
    fi

    print "All deployments rolled out successfully"
}

get_deployment_config_prefix() {
    local deploy="$1"
    local prefix=""
    
    # Map deployment names to configuration variable prefix
    case "$deploy" in
        *rojacore*|*roja-core*)
            prefix="ROJA_CORE"
            ;;
        *py-utils*|*roja-py-utils*)
            prefix="PY_UTILS"
            ;;
        *g-fwk*|*roja-g-fwk*)
            prefix="G_FWK"
            ;;
        *roja-ui*|*ibm-roja-ui*)
            prefix="ROJA_UI"
            ;;
        *portal-gw*|*roja-portal-gw*)
            prefix="PORTAL_GW"
            ;;
        *compliance*|*roja-compliance*)
            prefix="COMP"
            ;;
        *ingestion*|*roja-ingestion*)
            prefix="ING"
            ;;
        *pipeline*|*roja-pipeline*)
            prefix="PIPEL"
            ;;
        *mcp*|*roja-mcp*)
            prefix="MCP"
            ;;
        *buddy*|*roja-buddy*)
            prefix="BUDDY"
            ;;
        *sra*|*roja-sra*)
            prefix="SRA"
            ;;
        *mgmt*|*roja-mgmt*)
            prefix="MGMT"
            ;;
        *solis-gw*|*concert-solis-gw*)
            prefix="SOLIS_GW"
            ;;
        *)
            prefix=""
            ;;
    esac
    
    echo "$prefix"
}

scale_deployment_with_resources() {
    local deploy="$1"
    local replicas="$2"
    local prefix="$3"
    
    # Get resource values from environment variables
    local req_cpu="${prefix}_REQ_C"
    local req_mem="${prefix}_REQ_M"
    local req_ephemeral="${prefix}_REQ_ES"
    local lim_cpu="${prefix}_LIM_C"
    local lim_mem="${prefix}_LIM_M"
    local lim_ephemeral="${prefix}_LIM_ES"
    
    local cpu_request="${!req_cpu:-}"
    local mem_request="${!req_mem:-}"
    local ephemeral_request="${!req_ephemeral:-}"
    local cpu_limit="${!lim_cpu:-}"
    local mem_limit="${!lim_mem:-}"
    local ephemeral_limit="${!lim_ephemeral:-}"
    
    # Get all containers in the deployment
    local containers=$(kubectl get deploy "${deploy}" -o jsonpath='{.spec.template.spec.containers[*].name}')
    
    if [[ -z "$containers" ]]; then
        print warn "No containers found in deployment: ${deploy}"
        return 1
    fi
    
    # Build JSON patch operations array
    local patch_operations='['
    local first=true
    
    # Add replica count patch operation
    patch_operations+='{"op":"replace","path":"/spec/replicas","value":'${replicas}'}'
    first=false
    
    # Add resource patches for each container (if resources are defined)
    if [[ -n "$cpu_request" || -n "$mem_request" || -n "$ephemeral_request" || -n "$cpu_limit" || -n "$mem_limit" || -n "$ephemeral_limit" ]]; then
        for container in $containers; do
            local container_index=0
            local all_containers=$(kubectl get deploy "${deploy}" -o jsonpath='{.spec.template.spec.containers[*].name}')
            for c in $all_containers; do
                if [[ "$c" == "$container" ]]; then
                    break
                fi
                container_index=$((container_index + 1))
            done
            
            # Skip if no resources defined for this container
            if [[ -z "$cpu_request" && -z "$mem_request" && -z "$ephemeral_request" && -z "$cpu_limit" && -z "$mem_limit" && -z "$ephemeral_limit" ]]; then
                continue
            fi
            
            # Add comma separator
            if [[ "$first" == false ]]; then
                patch_operations+=','
            fi
            first=false
            
            # Build resource patch for this container
            local resource_patch='{"op":"replace","path":"/spec/template/spec/containers/'${container_index}'/resources","value":{'
            local resource_first=true
            
            # Add requests
            if [[ -n "$cpu_request" || -n "$mem_request" || -n "$ephemeral_request" ]]; then
                resource_patch+='"requests":{'
                local req_first=true
                if [[ -n "$cpu_request" ]]; then
                    resource_patch+='"cpu":"'${cpu_request}'"'
                    req_first=false
                fi
                if [[ -n "$mem_request" ]]; then
                    [[ "$req_first" == false ]] && resource_patch+=','
                    resource_patch+='"memory":"'${mem_request}'"'
                    req_first=false
                fi
                if [[ -n "$ephemeral_request" ]]; then
                    [[ "$req_first" == false ]] && resource_patch+=','
                    resource_patch+='"ephemeral-storage":"'${ephemeral_request}'"'
                fi
                resource_patch+='}'
                resource_first=false
            fi
            
            # Add limits
            if [[ -n "$cpu_limit" || -n "$mem_limit" || -n "$ephemeral_limit" ]]; then
                [[ "$resource_first" == false ]] && resource_patch+=','
                resource_patch+='"limits":{'
                local lim_first=true
                if [[ -n "$cpu_limit" ]]; then
                    resource_patch+='"cpu":"'${cpu_limit}'"'
                    lim_first=false
                fi
                if [[ -n "$mem_limit" ]]; then
                    [[ "$lim_first" == false ]] && resource_patch+=','
                    resource_patch+='"memory":"'${mem_limit}'"'
                    lim_first=false
                fi
                if [[ -n "$ephemeral_limit" ]]; then
                    [[ "$lim_first" == false ]] && resource_patch+=','
                    resource_patch+='"ephemeral-storage":"'${ephemeral_limit}'"'
                fi
                resource_patch+='}'
            fi
            
            resource_patch+='}}'
            patch_operations+="$resource_patch"
        done
    fi
    
    patch_operations+=']'
    
    # Apply the patch 
    if kubectl patch deploy "${deploy}" --type='json' -p="${patch_operations}" >/dev/null 2>&1; then
        return 0
    else
        print error "Failed to scale deployment '${deploy}' to ${replicas} replica(s) with resource updates"
        return 1
    fi
}

### ========= Scale to Level Function ========= ###

scale_to_level() {
    local scale_level="$1"
    
    print "Starting deployment scaling process"
    print "Target Scale Level: ${scale_level}"
        
    # Check current scale level to avoid unnecessary scaling
    print "Checking current scale level..."
    local current_level
    current_level=$(kubectl get configmap scaler-config \
        -o jsonpath='{.metadata.labels.current-scale-level}' 2>/dev/null || true)
    
    if [[ -n "$current_level" && "$current_level" == "$scale_level" ]]; then
        print warn "Already at scale level '${scale_level}'. Skipping scaling operation."
        exit 0
    fi
    
    if [[ -n "$current_level" ]]; then
        print "Current scale level: ${current_level}"
    else
        print "No current scale level found (first run or ConfigMap not labeled)"
    fi
    
    # Read configuration from mounted ConfigMap volume
    local config_file="/config/${scale_level}.cfg"
    
    print "Loading scale configuration from file: ${config_file}"
    
    if [[ ! -f "$config_file" ]]; then
        print error "Scale config file not found: ${config_file}"
        print error "Available files in /config:"
        ls -la /config/ || true
        exit 3
    fi
    
    # Source the configuration file
    print "Sourcing scale configuration for ${scale_level}..."
    set -a
    source "${config_file}"
    set +a
    
    # Get all deployments, excluding postgres databases
    print "Retrieving deployments..."
    local deployments=$(kubectl get deploy -o jsonpath='{.items[*].metadata.name}' | \
        tr ' ' '\n' | grep -v '^roja-postgres-' | tr '\n' ' ' | xargs)
    
    if [[ -z "$deployments" ]]; then
        print warn "No scalable deployments found"
        exit 0
    fi
    
    print "Found deployments: ${deployments}"
    
    # Apply scaling to each deployment
    local scaled=0
    local failed=0
    local skipped=0
    
    for deploy in $deployments; do
        # Get configuration prefix for this deployment
        local config_prefix=$(get_deployment_config_prefix "$deploy")
        
        if [[ -z "$config_prefix" ]]; then
            print warn "Unknown deployment: ${deploy}, skipping..."
            skipped=$((skipped + 1))
            continue
        fi
        
        # Get replica count from sourced environment variable
        local replica_var="${config_prefix}_REPLICAS"
        local replicas="${!replica_var:-}"
        
        if [[ -z "$replicas" ]]; then
            print warn "Replica count not found for ${deploy} (${replica_var}), skipping..."
            skipped=$((skipped + 1))
            continue
        fi
        
        print "Scaling ${deploy} to ${replicas} replica(s) with resource updates..."
        
        # Scale replicas AND update resources
        if scale_deployment_with_resources "$deploy" "$replicas" "$config_prefix"; then
            scaled=$((scaled + 1))
        else
            failed=$((failed + 1))
        fi
    done
    
    echo
    echo "=====================================================================================" 
    print "Scaling summary: Scaled: ${scaled}, Failed: ${failed}, Skipped: ${skipped}"
    echo "=====================================================================================" 
    
    if [[ "$failed" -gt 0 ]]; then
        exit 2
    fi
    
    wait_for_rollout

    # Record the current scale level as a label on the scaler-config ConfigMap
    if kubectl label configmap scaler-config \
        "current-scale-level=${scale_level}" \
        --overwrite >/dev/null 2>&1; then
        print "Recorded current scale level '${scale_level}' on ConfigMap 'scaler-config'"
    else
        print warn "Could not update scale level label on ConfigMap 'scaler-config' (non-fatal)"
    fi

    print "Scale to level ${scale_level} completed successfully"
}

### ========= Main Execution ========= ###

if [[ $# -eq 0 ]]; then
    show_help
    exit 0
fi

# Parse command line arguments
while [[ $# -gt 0 ]]; do
    case "$1" in
        --scale-level=*)
            SCALE_LEVEL="${1#*=}"
            shift
            ;;
        -h|--help)
            show_help
            exit 0
            ;;
        *)
            print error "Unknown argument: $1"
            show_help
            exit 1
            ;;
    esac
done

# Scale level is required
if [[ -z "${SCALE_LEVEL}" ]]; then
    print error "Scale level is required"
    show_help
    exit 1
fi

# Validate prerequisites
validate_prerequisites

# Execute scaling
scale_to_level "${SCALE_LEVEL}"

exit 0
