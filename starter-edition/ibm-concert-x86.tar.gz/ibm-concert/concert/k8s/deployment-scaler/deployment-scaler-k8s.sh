#!/bin/bash

#########################################
## IBM Confidential                    ##
## PID: 5900-BD6, 5900-BBE             ##
## Copyright IBM Corp. 2026            ##
#########################################

set -euo pipefail

### ========= Global Variables ========= ###

CONCERT_NAMESPACE=""
SCALE_LEVEL=""
SCHEDULE=""
FORCE_REPLACE=false
MODE=""  # "on-demand", "cronjob", or "manage"
ACTION=""  # "list", "suspend", "resume", "delete", "delete-all"
CRONJOB_NAME=""
KUBECTL=""
BUILD_CFG_CM="app-build-cfg-cm"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SCRIPT_NAME="$(basename "${BASH_SOURCE[0]}")"
PRODUCT_BASE_DIR="$(cd "${SCRIPT_DIR}/../.." && pwd)"
CRONJOB_TEMPLATE_FILE="${SCRIPT_DIR}/app-scaling/scale-cron-job.yaml.tmpl"
JOB_TEMPLATE_FILE="${SCRIPT_DIR}/app-scaling/scale-job.yaml.tmpl"
SCALER_SCRIPT="${SCRIPT_DIR}/deployment-scaler-utils.sh"
LOG_FILE="${SCRIPT_DIR}/$(basename "$0" .sh)_$(date +'%Y%m%d_%H%M%S').log"

### ========= Logging Functions ========= ###

print() {
    local level message color label nocolor timestamp
    
    timestamp=$(date -u +"%Y-%m-%d %H:%M:%S %Z")
    nocolor='\033[0m'
    
    level="info"
    message="$1"
    
    if [[ $# -eq 2 ]]; then
        level="$1"
        message="$2"
    fi
    
    case "$level" in
        info)
            color='\033[0;32m'
            label='[INFO]'
            ;;
        error)
            color='\033[0;31m'
            label='[ERROR]'
            ;;
        warn)
            color='\033[0;33m'
            label='[WARN]'
            ;;
    esac
    
    echo -e "[${timestamp}] ${color}${label}${nocolor} ${message}" >&2
}

### ========= Help Function ========= ###

get_valid_scale_levels_text() {
    local config_dir="${SCRIPT_DIR}/../etc"
    local valid_levels=()
    local valid_levels_text=""

    for cfg_file in "${config_dir}"/*.cfg; do
        [[ -f "$cfg_file" ]] || continue
        local name
        name="$(basename "${cfg_file}" .cfg)"
        [[ "$name" == "level_minicpureq" ]] && continue
        valid_levels+=("$name")
    done

    valid_levels_text="$(printf '%s, ' "${valid_levels[@]}")"
    valid_levels_text="${valid_levels_text%, }"

    echo "${valid_levels_text}"
}

show_help() {
    local valid_levels_text
    valid_levels_text="$(get_valid_scale_levels_text)"

    cat << EOF
    
IBM Concert Deployments Scale Script
================================================================================

Description:
    Scale IBM Concert deployments based on predefined scale levels.

    On-Demand Scaling:
        - Immediately applies a predefined scale level (e.g., level_1, level_3) to all deployments
          in the target namespace by running a one-off Kubernetes Job.
        - Use this to manually switch between resource profiles.

    Schedule-based Scaling:
        - Creates a Kubernetes CronJob that automatically scales to a specific level at scheduled times.
        - Multiple CronJobs can be created for different levels at different times.

    CronJob Management:
        - List, suspend, resume, or delete existing scaling CronJobs.
        - Manage automated scaling schedules without recreating them.

USAGE:
    ${SCRIPT_NAME} [OPTIONS]

Options:
    --concert-namespace=<ns>      Concert namespace (required)
    --scale-level=<level>         Scale level (required for scaling operations)
                                    Valid: ${valid_levels_text}
    --schedule="<cron>"           Cron schedule (optional, enables CronJob mode)
    --action=<action>             Management action (optional, enables management mode)
                                    Valid: list, suspend, resume, delete, delete-all
    --cronjob-name=<name>         CronJob name (required for suspend/resume/delete actions)
    --force                       Force replace existing CronJob at the same time (optional)
    -h, --help                    Display this help message

Scaling Modes:

    1. On-Demand Scaling (immediate):
        --concert-namespace=<ns> --scale-level=<level>

    2. Schedule-based Scaling (CronJob):
        --concert-namespace=<ns> --scale-level=<level> --schedule="<cron>"

    3. CronJob Management:
        --concert-namespace=<ns> --action=<action> [--cronjob-name=<name>]
    
Examples:

    # ===== Scaling Operations =====
    
    # On-demand scaling - Scale Concert to level_3 immediately
    ${SCRIPT_NAME} --concert-namespace=concert --scale-level=level_3

    # Schedule level_1 for idle hours (10 PM daily)
    ${SCRIPT_NAME} --concert-namespace=concert --scale-level=level_1 --schedule="0 22 * * *"

    # Schedule level_3 for user hours (6 AM daily)
    ${SCRIPT_NAME} --concert-namespace=concert --scale-level=level_3 --schedule="0 6 * * *"

    # Schedule level_4 for peak load (12 PM daily)
    ${SCRIPT_NAME} --concert-namespace=concert --scale-level=level_4 --schedule="0 12 * * *"

    # Replace existing CronJob at 10 PM with a different level
    ${SCRIPT_NAME} --concert-namespace=concert --scale-level=level_2 --schedule="0 22 * * *" --force

    # ===== CronJob Management =====
    
    # List all scaling CronJobs
    ${SCRIPT_NAME} --concert-namespace=concert --action=list

    # Suspend a CronJob (pause scheduled scaling)
    ${SCRIPT_NAME} --concert-namespace=concert --action=suspend --cronjob-name=scale-to-level-1-at-2200-cron

    # Resume a suspended CronJob
    ${SCRIPT_NAME} --concert-namespace=concert --action=resume --cronjob-name=scale-to-level-1-at-2200-cron

    # Delete a specific CronJob
    ${SCRIPT_NAME} --concert-namespace=concert --action=delete --cronjob-name=scale-to-level-3-at-0600-cron

    # Delete all scaling CronJobs
    ${SCRIPT_NAME} --concert-namespace=concert --action=delete-all

Available Scale Levels:
    level_0           - All replicas set to 0 (shutdown)
    level_1           - Minimal resources (1 replica for most services)
    level_2           - Medium resources (2 replicas for most services)
    level_3           - High resources (3 replicas for most services)
    level_3_1         - High resources with increased replicas for key services
    level_3_2         - High resources with optimized resource requests
    level_4           - Maximum resources (4 replicas for most services)
    level_k3s         - Scale profile for K3s environments
    level_k3s_3_3     - K3s scale profile variant 3_3

Management Actions:
    list        - List all scaling CronJobs with their schedules and status
    suspend     - Suspend a CronJob (stops it from triggering new jobs)
    resume      - Resume a suspended CronJob (re-enables scheduled execution)
    delete      - Delete a specific CronJob (with confirmation prompt)
    delete-all  - Delete all scaling CronJobs (with confirmation prompt)

CronJob Naming:
    CronJobs are named: scale-to-<level>-at-<time>-cron
    Examples:
        - level_1 at 22:00           → scale-to-level-1-at-0-22-cron
        - level_3 at 06:00           → scale-to-level-3-at-0-6-cron
        - level_2 at 17:00           → scale-to-level-2-at-0-17-cron
        - level_3 at 10-11:00        → scale-to-level-3-at-0-10-11-cron
        - level_4 at 9,12,18:00      → scale-to-level-4-at-0-9-12-18-cron

Cron Schedule Format:
    ┌───────────── minute (0 - 59)
    │ ┌───────────── hour (0 - 23)
    │ │ ┌───────────── day of month (1 - 31)
    │ │ │ ┌───────────── month (1 - 12)
    │ │ │ │ ┌───────────── day of week (0 - 6) (Sunday to Saturday)
    │ │ │ │ │
    * * * * *

Common Workflows:

    1. Set up daily scaling schedule:
       - Morning scale-up:   ${SCRIPT_NAME} --concert-namespace=concert --scale-level=level_3 --schedule="0 6 * * *"
       - Evening scale-down: ${SCRIPT_NAME} --concert-namespace=concert --scale-level=level_1 --schedule="0 22 * * *"

    2. Temporarily disable scaling:
       - List CronJobs:   ${SCRIPT_NAME} --concert-namespace=concert --action=list
       - Suspend CronJob: ${SCRIPT_NAME} --concert-namespace=concert --action=suspend --cronjob-name=<name>

    3. Re-enable scaling:
       - Resume CronJob: ${SCRIPT_NAME} --concert-namespace=concert --action=resume --cronjob-name=<name>

    4. Clean up all schedules:
       - ${SCRIPT_NAME} --concert-namespace=concert --action=delete-all

EOF
}

### ========= Validation Functions ========= ###

validate_prerequisites() {
    local required_cmds=("kubectl" "envsubst")

    for cmd in "${required_cmds[@]}"; do
        if command -v "$cmd" >/dev/null 2>&1; then
            [[ "$cmd" == "kubectl" ]] && KUBECTL="kubectl"
        elif [[ "$cmd" == "kubectl" ]] && command -v oc >/dev/null 2>&1; then
            KUBECTL="oc"
            print warn "kubectl not found — using 'oc' as Kubernetes CLI"
        else
            print error "Required command not found: $cmd"
            exit 2
        fi
    done

    if [ ! -f "${SCALER_SCRIPT}" ]; then
        print error "Scaler script not found: ${SCALER_SCRIPT}"
        exit 2
    fi
}

validate_cron_schedule() {
    local schedule="$1"
    local name="$2"
    
    schedule="$(echo "$schedule" | xargs)"

    # Strict 5-field cron validation
    if ! [[ "$schedule" =~ ^([0-9*/,-]+[[:space:]]+){4}[0-9*/,-]+$ ]]; then
        print error "Invalid cron format for ${name}: '$schedule'"
        print error "Expected: 'minute hour day month weekday'"
        exit 2
    fi
    
    # Extract minute and hour fields
    local cron_minute cron_hour
    cron_minute=$(echo "$schedule" | awk '{print $1}')
    cron_hour=$(echo "$schedule" | awk '{print $2}')
    
    # Reject wildcards and step values
    if [[ "$cron_minute" =~ [\*/] ]] || [[ "$cron_hour" =~ [\*/] ]]; then
        print error "Invalid schedule for ${name}: '$schedule'"
        print error "This script currently does not support wildcards (*) and step values (*/) in minute/hour fields"
        print error "Supported formats: single values (0), ranges (0-30), lists (0,15,30)"
        exit 2
    fi
    
    # Validate minute field format and values
    if ! [[ "$cron_minute" =~ ^[0-9,-]+$ ]]; then
        print error "Invalid minute format: $cron_minute"
        print error "Supported: single (0), range (0-30), list (0,15,30)"
        exit 2
    fi
    
    # Validate hour field format and values
    if ! [[ "$cron_hour" =~ ^[0-9,-]+$ ]]; then
        print error "Invalid hour format: $cron_hour"
        print error "Supported: single (9), range (9-17), list (9,12,18)"
        exit 2
    fi
}

validate_namespace() {
    local ns="$1"
    if ! "${KUBECTL}" get namespace "${ns}" >/dev/null 2>&1; then
        print error "Namespace '${ns}' does not exist"
        return 1
    fi
    return 0
}

validate_scale_level() {
    local level="$1"
    local config_dir="${SCRIPT_DIR}/../etc"
    local valid_levels=()

    for cfg_file in "${config_dir}"/*.cfg; do
        [[ -f "$cfg_file" ]] || continue
        local name
        name="$(basename "${cfg_file}" .cfg)"
        [[ "$name" == "level_minicpureq" ]] && continue
        valid_levels+=("$name")
    done

    for valid in "${valid_levels[@]}"; do
        if [[ "$level" == "$valid" ]]; then
            return 0
        fi
    done

    print error "Invalid scale level: $level"
    print error "Valid levels: ${valid_levels[*]}"
    exit 2
}

validate_cronjob_exists() {
    local cronjob_name="$1"
    
    # Check if CronJob exists
    if ! "${KUBECTL}" get cronjob "${cronjob_name}" -n "${CONCERT_NAMESPACE}" >/dev/null 2>&1; then
        print error "CronJob '${cronjob_name}' not found in namespace '${CONCERT_NAMESPACE}'"
        echo
        print "Available scaling CronJobs:"
        local available_cronjobs
        available_cronjobs=$("${KUBECTL}" get cronjob -n "${CONCERT_NAMESPACE}" -o name 2>/dev/null \
            | grep "scale-to-" | sed 's|cronjob.batch/||' || true)
        
        if [[ -z "$available_cronjobs" ]]; then
            print warn "  No scaling CronJobs found"
        else
            while IFS= read -r name; do
                [[ -z "$name" ]] && continue
                print "  - ${name}"
            done <<< "$available_cronjobs"
        fi
        return 1
    fi
    return 0
}

### ========= Argument Parsing ========= ###

parse_arguments() {
    if [ $# -eq 0 ]; then
        show_help
        exit 0
    fi
    
    for arg in "$@"; do
        case $arg in
            --concert-namespace=*)
                CONCERT_NAMESPACE="${arg#*=}"
                ;;
            --scale-level=*)
                SCALE_LEVEL="${arg#*=}"
                ;;
            --schedule=*)
                SCHEDULE="${arg#*=}"
                ;;
            --action=*)
                ACTION="${arg#*=}"
                ;;
            --cronjob-name=*)
                CRONJOB_NAME="${arg#*=}"
                ;;
            --force)
                FORCE_REPLACE=true
                ;;
            -h|--help)
                show_help
                exit 0
                ;;
            *)
                print error "Unknown argument: $arg"
                echo
                show_help
                exit 1
                ;;
        esac
    done
    
    # --concert-namespace is always required
    if [[ -z "$CONCERT_NAMESPACE" ]]; then
        print error "Missing required argument: --concert-namespace"
        exit 2
    fi

    # Determine mode based on action parameter
    if [[ -n "$ACTION" ]]; then
        MODE="manage"
        
        # Validate action
        case "$ACTION" in
            list|suspend|resume|delete|delete-all)
                # Valid actions
                ;;
            *)
                print error "Invalid action: $ACTION"
                print error "Valid actions: list, suspend, resume, delete, delete-all"
                exit 2
                ;;
        esac
        
        # Validate required parameters for each action
        case "$ACTION" in
            suspend|resume|delete)
                if [[ -z "$CRONJOB_NAME" ]]; then
                    print error "Action '${ACTION}' requires --cronjob-name parameter"
                    exit 2
                fi
                ;;
            list|delete-all)
                # No additional parameters required
                ;;
        esac
        
    else
        # Scaling mode (on-demand or cronjob)
        
        # --scale-level is required for scaling operations
        if [[ -z "$SCALE_LEVEL" ]]; then
            print error "Missing required argument: --scale-level"
            print error "Usage:"
            print error "  For on-demand scaling:  --scale-level=<level>"
            print error "  For scheduled scaling:  --scale-level=<level> --schedule=\"<cron>\""
            print error "  For CronJob management: --action=<action> [--cronjob-name=<name>]"
            exit 2
        fi
        
        # Validate scale level
        validate_scale_level "$SCALE_LEVEL"
        
        # Determine mode based on whether schedule is provided
        if [[ -n "$SCHEDULE" ]]; then
            MODE="cronjob"
            # Validate cron schedule
            validate_cron_schedule "$SCHEDULE" "schedule"
        else
            MODE="on-demand"
        fi
    fi
}

### ========= Configuration Retrieval ========= ###

get_config_values() {
    print "Retrieving configuration from namespace: ${CONCERT_NAMESPACE}"

    get_cm_val() {
        "${KUBECTL}" get cm app-cfg-cm -n "$CONCERT_NAMESPACE" \
            -o jsonpath="{.data.$1}" 2>/dev/null || true
    }

    RUNASUSER="$(get_cm_val RUNASUSER)";   RUNASUSER="${RUNASUSER:-1000}"
    RUNASGROUP="$(get_cm_val RUNASGROUP)"; RUNASGROUP="${RUNASGROUP:-1000}"
    FS_GROUPID="$(get_cm_val FS_GROUPID)"; FS_GROUPID="${FS_GROUPID:-1000}"
    SUPP_GROUPID="$(get_cm_val SUPP_GROUPID)"; SUPP_GROUPID="${SUPP_GROUPID:-1000}"
    
    # Get IMG_PREFIX and IMG_TAG from configMap
    if ! "${KUBECTL}" get cm "${BUILD_CFG_CM}" -n "${CONCERT_NAMESPACE}" >/dev/null 2>&1; then
        print error "ConfigMap ${BUILD_CFG_CM} not found in namespace ${CONCERT_NAMESPACE}"
        exit 2
    fi

    IMG_PREFIX=$("${KUBECTL}" get cm "${BUILD_CFG_CM}" -n "${CONCERT_NAMESPACE}" \
        -o jsonpath='{.data.IMG_PREFIX}' 2>/dev/null || true)
    if [ -z "${IMG_PREFIX}" ]; then
        print error "IMG_PREFIX key missing in ${BUILD_CFG_CM} ConfigMap"
        exit 2
    fi
    
    IMG_TAG=$("${KUBECTL}" get cm "${BUILD_CFG_CM}" -n "${CONCERT_NAMESPACE}" \
        -o jsonpath='{.data.IMG_TAG}' 2>/dev/null || true)
    if [ -z "${IMG_TAG}" ]; then
        print error "IMG_TAG key missing in ${BUILD_CFG_CM} ConfigMap"
        exit 2
    fi

    print "Configuration retrieved successfully:"
    print "  RUNASUSER: ${RUNASUSER}"
    print "  RUNASGROUP: ${RUNASGROUP}"
    print "  FS_GROUPID: ${FS_GROUPID}"
    print "  SUPP_GROUPID: ${SUPP_GROUPID}"
    print "  IMG_PREFIX: ${IMG_PREFIX}"
    print "  IMG_TAG: ${IMG_TAG}"
}

### ========= ConfigMap Creation ========= ###

create_scaler_configmap() {
    print "Creating ConfigMap with deployment-scaler-utils.sh script..."
    
    if "${KUBECTL}" create configmap scaler-script \
        --from-file=deployment-scaler-utils.sh="${SCALER_SCRIPT}" \
        --namespace="${CONCERT_NAMESPACE}" \
        --dry-run=client -o yaml | "${KUBECTL}" apply -f - -n "${CONCERT_NAMESPACE}"; then
        print "ConfigMap 'scaler-script' created/updated successfully"
    else
        print error "Failed to create ConfigMap 'scaler-script'"
        exit 2
    fi
}

create_scale_config_configmap() {
    print "Creating ConfigMap with all scale configurations..."
    
    local config_dir="${SCRIPT_DIR}/../etc"
    
    # Build kubectl command with individual file mappings
    local kubectl_cmd="${KUBECTL} create configmap scaler-config --namespace=${CONCERT_NAMESPACE}"
    
    local config_files=("${config_dir}"/*.cfg)
    
    for config_file in "${config_files[@]}"; do
        [[ -f "${config_file}" ]] || { print warn "No scale config files (*.cfg) found in: ${config_dir}"; continue; }
        kubectl_cmd="${kubectl_cmd} --from-file=$(basename "${config_file}")=${config_file}"
    done
    
    # Create ConfigMap with explicit key names
    if eval "${kubectl_cmd} --dry-run=client -o yaml" | "${KUBECTL}" apply -f - -n "${CONCERT_NAMESPACE}"; then
        print "ConfigMap 'scaler-config' created/updated successfully"
    else
        print error "Failed to create ConfigMap 'scaler-config'"
        exit 2
    fi
}

### ========= Job Generation and Deployment ========= ###

deploy_scale_job() {
    local scale_level="$1"
    local level_name="${scale_level//_/-}"
    local job_name="scale-to-${level_name}-job-$(date +%s)"
    local output_file="/tmp/${job_name}.yaml"

    print "Checking current scale level in namespace ${CONCERT_NAMESPACE}..."
    local current_level
    current_level=$("${KUBECTL}" get configmap scaler-config \
        -n "${CONCERT_NAMESPACE}" \
        -o jsonpath='{.metadata.labels.current-scale-level}' 2>/dev/null || true)
    if [[ -n "$current_level" && "$current_level" == "$scale_level" ]]; then
        print warn "Namespace '${CONCERT_NAMESPACE}' is already at scale level '${scale_level}'. Skipping."
        exit 0
    fi

    print "Generating scaling Job for level: ${scale_level}"
    
    if [ ! -f "${JOB_TEMPLATE_FILE}" ]; then
        print error "Job Template file not found: ${JOB_TEMPLATE_FILE}"
        exit 2
    fi
    
    # Export variables for envsubst
    export ACTION="scale"
    export SCALE_LEVEL="${scale_level}"
    export JOB_NAME="${job_name}"
    export RUNASUSER
    export RUNASGROUP
    export FS_GROUPID
    export SUPP_GROUPID
    export IMG_PREFIX
    export IMG_TAG
    
    # Generate YAML from template
    if envsubst < "${JOB_TEMPLATE_FILE}" > "${output_file}"; then
        print "Job YAML generated: ${output_file}"
    else
        print error "Failed to generate Job YAML"
        exit 2
    fi
    
    # Deploy Job
    print "Deploying scaling Job: ${job_name}"
    if "${KUBECTL}" apply -f "${output_file}" -n "${CONCERT_NAMESPACE}"; then
        print "Job deployed successfully: ${job_name}"
    else
        print error "Failed to deploy Job"
        rm -f "${output_file}"
        exit 2
    fi
    
    echo
    print "You can follow the job logs with:"
    echo "${KUBECTL} logs -f job/${job_name} -n ${CONCERT_NAMESPACE}"
    echo
    
    local pod_creation_timeout=300
    local pod_ready_timeout=300
    local job_completion_timeout=600
    local elapsed=0    

    print "Waiting up to ${pod_creation_timeout}s for Job pod creation..."
    while [ $elapsed -lt $pod_creation_timeout ]; do
        pod_name=$("${KUBECTL}" get pod \
            -l job-name="${job_name}" -n "${CONCERT_NAMESPACE}" \
            -o jsonpath='{.items[0].metadata.name}' 2>/dev/null || true)

        if [ -n "${pod_name}" ]; then
            print "Job pod created: ${pod_name}"
            break
        fi

        sleep 2
        elapsed=$((elapsed + 2))
    done

    if [ $elapsed -ge $pod_creation_timeout ]; then
        print error "Job pod did not start within ${pod_creation_timeout}s"
        print error "Check pod events: ${KUBECTL} describe pod -l job-name=${job_name} -n ${CONCERT_NAMESPACE}"
        rm -f "${output_file}"
        exit 2
    fi
    
    print "Waiting up to ${pod_ready_timeout}s for Job pod to become ready..."
    if ! "${KUBECTL}" wait --for=condition=ready pod -l job-name="${job_name}" \
        -n "${CONCERT_NAMESPACE}" --timeout="${pod_ready_timeout}s" >/dev/null 2>&1; then
        print error "Job pod did not become ready within ${pod_ready_timeout}s"
        print error "Check pod events: ${KUBECTL} describe pod -l job-name=${job_name} -n ${CONCERT_NAMESPACE}"
        rm -f "${output_file}"
        exit 2
    fi
    print "Job pod is ready: ${pod_name}"

    # Stream logs
    echo
    echo "=============================== Scale Job Pod logs ==============================="
    "${KUBECTL}" logs -f "job/${job_name}" -n "${CONCERT_NAMESPACE}" || true
    echo "=================================================================================="    

    # Validate Job completion status
    print "Waiting up to ${job_completion_timeout}s for Job completion..."
    
    local elapsed=0

    while [ "${elapsed}" -lt "${job_completion_timeout}" ]; do
        succeeded=$("${KUBECTL}" get job "${job_name}" \
            -n "${CONCERT_NAMESPACE}" \
            -o jsonpath='{.status.succeeded}' 2>/dev/null || true)

        failed=$("${KUBECTL}" get job "${job_name}" \
            -n "${CONCERT_NAMESPACE}" \
            -o jsonpath='{.status.failed}' 2>/dev/null || true)

        if [ "${succeeded}" = "1" ]; then
            print "Job job/${job_name} completed successfully"
            rm -f "${output_file}"
            return 0
        fi

        if [ -n "${failed}" ] && [ "${failed}" -gt 0 ]; then
            print error "Job job/${job_name} failed"
            print error "Check Job Events: ${KUBECTL} describe job ${job_name} -n ${CONCERT_NAMESPACE}"
            exit 2
        fi

        sleep 5
        elapsed=$((elapsed + 5))
    done   

    print error "Job did not complete within ${job_completion_timeout}s"
    print error "Check Job Events: ${KUBECTL} describe job ${job_name} -n ${CONCERT_NAMESPACE}"
    exit 2     
}

### ========= CronJob Generation and Deployment ========= ###

generate_cronjob() {
    local scale_level="$1"
    local schedule="$2"
    local cronjob_name="$3"
    local output_file="$4"
    
    print "Generating CronJob: ${cronjob_name}"
    
    if [ ! -f "${CRONJOB_TEMPLATE_FILE}" ]; then
        print error "CronJob Template file not found: ${CRONJOB_TEMPLATE_FILE}"
        exit 2
    fi
    
    # Export variables for envsubst
    export SCALE_LEVEL="${scale_level}"
    export SCHEDULE="${schedule}"
    export CRONJOB_NAME="${cronjob_name}"
    export RUNASUSER
    export RUNASGROUP
    export FS_GROUPID
    export SUPP_GROUPID
    export IMG_PREFIX
    export IMG_TAG
    
    # Generate YAML from template
    if envsubst < "${CRONJOB_TEMPLATE_FILE}" > "${output_file}"; then
        print "CronJob YAML generated: ${output_file}"
    else
        print error "Failed to generate CronJob YAML for level: ${scale_level}"
        exit 2
    fi
}

deploy_cronjob() {
    local yaml_file="$1"
    local cronjob_name="$2"
    
    print "Deploying CronJob: ${cronjob_name}"
    
    if "${KUBECTL}" apply -f "${yaml_file}" -n "${CONCERT_NAMESPACE}"; then
        print "CronJob deployed successfully: ${cronjob_name}"
    else
        print error "Failed to deploy CronJob: ${cronjob_name}"
        exit 2
    fi
}

### ========= On-Demand Scaling ========= ###

run_on_demand() {
    echo
    echo "===================== On-Demand Scaling Mode ====================="
    print "Concert Namespace: ${CONCERT_NAMESPACE}"
    print "Scale Level: ${SCALE_LEVEL}"
    echo "=================================================================="
    echo

    # Create ConfigMaps
    create_scaler_configmap
    create_scale_config_configmap

    # Deploy and run scaling job
    deploy_scale_job "$SCALE_LEVEL"

    echo
    print "=========================================="
    print "On-demand scaling completed successfully!"
    print "=========================================="
}

### ========= Schedule-based Scaling ========= ###

run_cronjob() {
    # Extract hour and minute from cron schedule for display and naming
    local cron_minute cron_hour cron_time
    cron_minute=$(echo "$SCHEDULE" | awk '{print $1}')
    cron_hour=$(echo "$SCHEDULE" | awk '{print $2}')
    
    # Generate a sanitized time string for the CronJob name
    # Replace commas with hyphens, keep existing hyphens 
    local time_suffix
    time_suffix=$(echo "${cron_minute}-${cron_hour}" | tr ',' '-')
    
    local level_name="${SCALE_LEVEL//_/-}"
    local cronjob_name="scale-to-${level_name}-at-${time_suffix}-cron"
    
    echo
    echo "===================== CronJob Deployment Mode ====================="
    print "Concert Namespace: ${CONCERT_NAMESPACE}"
    print "Scale Level: ${SCALE_LEVEL}"
    print "Schedule: ${SCHEDULE}"
    echo "==================================================================="
    echo

    # Check for conflicting CronJobs with the same schedule
    print "Checking for existing CronJobs with schedule '${SCHEDULE}'..."
    local all_cronjobs_with_schedule
    all_cronjobs_with_schedule=$("${KUBECTL}" get cronjob -n "${CONCERT_NAMESPACE}" \
        -o json 2>/dev/null | jq -r --arg sched "${SCHEDULE}" \
        '.items[] | select(.spec.schedule == $sched) | .metadata.name' || true)
    
    if [[ -n "$all_cronjobs_with_schedule" ]]; then
        local same_level_exists=false
        local different_level_exists=false
        local conflicting_cronjobs=""
        
        while IFS= read -r existing_cron; do
            [[ -z "$existing_cron" ]] && continue
            
            if [[ "$existing_cron" == "$cronjob_name" ]]; then
                # Same level and same schedule - this is a duplicate
                same_level_exists=true
            else
                # Different level but same schedule - this is a conflict
                different_level_exists=true
                conflicting_cronjobs="${conflicting_cronjobs}${existing_cron}\n"
            fi
        done <<< "$all_cronjobs_with_schedule"
        
        # Case 1: Same level + same schedule = Duplicate (reject, no force option)
        if [[ "$same_level_exists" == "true" ]]; then
            echo
            print error "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
            print error "DUPLICATE DETECTED: CronJob already exists"
            print error "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
            print error ""
            print error "A CronJob with the same scale level and schedule already exists:"
            print error "  Name: ${cronjob_name}"
            print error "  Scale Level: ${SCALE_LEVEL}"
            print error "  Schedule: ${SCHEDULE}"
            print error ""
            print error "This is a duplicate. The CronJob already exists and does not need to be recreated."
            print error ""
            print error "To view existing CronJob:"
            print error "  ${KUBECTL} get cronjob ${cronjob_name} -n ${CONCERT_NAMESPACE}"
            print error ""
            print error "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
            exit 2
        fi
        
        # Case 2: Different level + same schedule = Conflict (reject, offer --force)
        if [[ "$different_level_exists" == "true" ]]; then
            if [[ "$FORCE_REPLACE" == "true" ]]; then
                # Force mode: Delete conflicting CronJobs
                echo
                print "Force mode enabled - Deleting conflicting CronJobs with schedule '${SCHEDULE}'..."
                while IFS= read -r existing_cron; do
                    [[ -z "$existing_cron" ]] && continue
                    print "Deleting CronJob: ${existing_cron}"
                    if "${KUBECTL}" delete cronjob "${existing_cron}" -n "${CONCERT_NAMESPACE}"; then
                        print "Successfully deleted: ${existing_cron}"
                    else
                        print error "Failed to delete: ${existing_cron}"
                        exit 2
                    fi
                done <<< "$(echo -e "${conflicting_cronjobs}")"
                echo
            else
                # No force mode: Show error and exit
                echo
                print error "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
                print error "CONFLICT DETECTED: Different scale level with same schedule exists"
                print error "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
                print error ""
                print error "The following CronJob(s) already exist with schedule '${SCHEDULE}':"
                while IFS= read -r line; do
                    [[ -n "$line" ]] && print error "  - ${line}"
                done <<< "$(echo -e "${conflicting_cronjobs}")"
                print error ""
                print error "Only one scale level can be scheduled at a specific time."
                print error "You are trying to create: ${cronjob_name} (${SCALE_LEVEL})"
                print error ""
                print error "Resolution Options:"
                print error ""
                print error "Option 1: Use --force to replace the existing CronJob(s)"
                print error "  ${SCRIPT_NAME} --concert-namespace=${CONCERT_NAMESPACE} --scale-level=${SCALE_LEVEL} --schedule=\"${SCHEDULE}\" --force"
                print error ""
                print error "Option 2: Manually delete the conflicting CronJob(s) first"
                while IFS= read -r line; do
                    [[ -n "$line" ]] && print error "  ${KUBECTL} delete cronjob ${line} -n ${CONCERT_NAMESPACE}"
                done <<< "$(echo -e "${conflicting_cronjobs}")"
                print error ""
                print error "Option 3: Choose a different schedule time"
                print error "  Example: --schedule=\"0 12 * * *\"  (different time)"
                print error ""
                print error "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
                exit 2
            fi
        fi
    fi

    # Create ConfigMaps
    create_scaler_configmap
    create_scale_config_configmap

    # Generate CronJob YAML
    local cronjob_yaml="/tmp/${cronjob_name}.yaml"
    generate_cronjob "${SCALE_LEVEL}" "${SCHEDULE}" "${cronjob_name}" "${cronjob_yaml}"

    # Deploy CronJob
    deploy_cronjob "${cronjob_yaml}" "${cronjob_name}"

    rm -f "${cronjob_yaml}" 2>/dev/null || true

    echo
    print "=========================================="
    print "CronJob Deployment completed successfully!"
    print "=========================================="
    print ""
    print "Summary:"
    print "  Concert Namespace: ${CONCERT_NAMESPACE}"
    print "  Scale Level: ${SCALE_LEVEL}"
    print "  Schedule: ${SCHEDULE} (Daily at ${cron_hour}:${cron_minute})"
    print "  CronJob Name: ${cronjob_name}"
    print ""
    print "Verify CronJob:"
    print "  ${KUBECTL} get cronjob ${cronjob_name} -n ${CONCERT_NAMESPACE}"
    print ""
    print "View CronJob details:"
    print "  ${KUBECTL} describe cronjob ${cronjob_name} -n ${CONCERT_NAMESPACE}"
    print ""
    print "List all scaling CronJobs:"
    print "  ${KUBECTL} get cronjob -n ${CONCERT_NAMESPACE} | grep 'scale-to'"
    print ""
    print "Monitor jobs:"
    print "  ${KUBECTL} get jobs -n ${CONCERT_NAMESPACE} --watch"
}
### ========= CronJob Management Functions ========= ###

list_cronjobs() {
    echo
    echo "===================== Listing Scaling CronJobs ====================="
    print "Concert Namespace: ${CONCERT_NAMESPACE}"
    echo "===================================================================="
    echo
    
    # Get all CronJobs and filter for scale-to-* pattern
    local all_cronjobs
    all_cronjobs=$("${KUBECTL}" get cronjob -n "${CONCERT_NAMESPACE}" -o name 2>/dev/null \
        | grep "scale-to-" | sed 's|cronjob.batch/||' || true)
    
    if [[ -z "$all_cronjobs" ]]; then
        print warn "No scaling CronJobs found in namespace '${CONCERT_NAMESPACE}'"
        echo
        print "To create a CronJob, use:"
        print "  ${SCRIPT_NAME} --concert-namespace=${CONCERT_NAMESPACE} --scale-level=<level> --schedule=\"<cron>\""
        return 0
    fi
    
    # Print header
    printf "%-45s %-20s %-12s %-15s\n" "CRONJOB NAME" "SCHEDULE" "STATUS" "LAST SCHEDULE"
    printf "%-45s %-20s %-12s %-15s\n" "----------------------------------" "-------------" "-----------" "--------------"
    
    # Print CronJobs
    local count=0
    while IFS= read -r name; do
        [[ -z "$name" ]] && continue
        
        # Get details for each CronJob
        local schedule suspended last_schedule
        schedule=$("${KUBECTL}" get cronjob "${name}" -n "${CONCERT_NAMESPACE}" -o jsonpath='{.spec.schedule}' 2>/dev/null || echo "N/A")
        suspended=$("${KUBECTL}" get cronjob "${name}" -n "${CONCERT_NAMESPACE}" -o jsonpath='{.spec.suspend}' 2>/dev/null || echo "false")
        last_schedule=$("${KUBECTL}" get cronjob "${name}" -n "${CONCERT_NAMESPACE}" -o jsonpath='{.status.lastScheduleTime}' 2>/dev/null || echo "Never")
        
        # Format status
        local status="Active"
        [[ "$suspended" == "true" ]] && status="Suspended"
        
        # Format last schedule time
        if [[ "$last_schedule" != "Never" && -n "$last_schedule" ]]; then
            last_schedule=$(date -u -d "$last_schedule" "+%Y-%m-%d %H:%M" 2>/dev/null || \
                        date -u -j -f "%Y-%m-%dT%H:%M:%SZ" "$last_schedule" "+%Y-%m-%d %H:%M" 2>/dev/null || \
                        echo "$last_schedule") || last_schedule="$last_schedule"        
        fi
        
        printf "%-45s %-20s %-12s %-15s\n" "$name" "$schedule" "$status" "$last_schedule"
        ((count++)) || true
    done <<< "$all_cronjobs"
    
    echo
    print "Total Scaling CronJobs: ${count}"
    echo
    print "Management Commands:"
    print "  Suspend:      ${SCRIPT_NAME} --concert-namespace=${CONCERT_NAMESPACE} --action=suspend --cronjob-name=<name>"
    print "  Resume:       ${SCRIPT_NAME} --concert-namespace=${CONCERT_NAMESPACE} --action=resume --cronjob-name=<name>"
    print "  Delete:       ${SCRIPT_NAME} --concert-namespace=${CONCERT_NAMESPACE} --action=delete --cronjob-name=<name>"
    print "  Delete-all:   ${SCRIPT_NAME} --concert-namespace=${CONCERT_NAMESPACE} --action=delete-all"
    print "  Details:      ${KUBECTL} describe cronjob <name> -n ${CONCERT_NAMESPACE}"
}

suspend_cronjob() {
    local cronjob_name="$1"
    
    echo
    echo "===================== Suspending CronJob ====================="
    print "Concert Namespace: ${CONCERT_NAMESPACE}"
    print "CronJob Name: ${cronjob_name}"
    echo "=============================================================="
    echo
    
    # Validate CronJob exists
    if ! validate_cronjob_exists "${cronjob_name}"; then
        exit 2
    fi
    
    # Check if already suspended
    local is_suspended
    is_suspended=$("${KUBECTL}" get cronjob "${cronjob_name}" -n "${CONCERT_NAMESPACE}" \
        -o jsonpath='{.spec.suspend}' 2>/dev/null)
    
    if [[ "$is_suspended" == "true" ]]; then
        print warn "CronJob '${cronjob_name}' is already suspended"
        return 0
    fi
    
    # Suspend the CronJob
    print "Suspending CronJob '${cronjob_name}'..."
    if "${KUBECTL}" patch cronjob "${cronjob_name}" -n "${CONCERT_NAMESPACE}" \
        -p '{"spec":{"suspend":true}}' --type=merge; then
        echo
        print "CronJob '${cronjob_name}' suspended successfully"
        echo
        print "The CronJob will not trigger any new jobs until resumed."
        print "Existing running jobs will continue to completion."
        echo
        print "To resume:"
        print "  ${SCRIPT_NAME} --concert-namespace=${CONCERT_NAMESPACE} --action=resume --cronjob-name=${cronjob_name}"
    else
        print error "Failed to suspend CronJob '${cronjob_name}'"
        exit 2
    fi
}

resume_cronjob() {
    local cronjob_name="$1"
    
    echo
    echo "===================== Resuming CronJob ====================="
    print "Concert Namespace: ${CONCERT_NAMESPACE}"
    print "CronJob Name: ${cronjob_name}"
    echo "============================================================"
    echo
    
    # Validate CronJob exists
    if ! validate_cronjob_exists "${cronjob_name}"; then
        exit 2
    fi
    
    # Check if already active
    local is_suspended
    is_suspended=$("${KUBECTL}" get cronjob "${cronjob_name}" -n "${CONCERT_NAMESPACE}" \
        -o jsonpath='{.spec.suspend}' 2>/dev/null)
    
    if [[ "$is_suspended" != "true" ]]; then
        print warn "CronJob '${cronjob_name}' is already active (not suspended)"
        return 0
    fi
    
    # Resume the CronJob
    print "Resuming CronJob '${cronjob_name}'..."
    if "${KUBECTL}" patch cronjob "${cronjob_name}" -n "${CONCERT_NAMESPACE}" \
        -p '{"spec":{"suspend":false}}' --type=merge; then
        echo
        print "CronJob '${cronjob_name}' resumed successfully"
        echo
        
        # Get schedule info
        local schedule
        schedule=$("${KUBECTL}" get cronjob "${cronjob_name}" -n "${CONCERT_NAMESPACE}" \
            -o jsonpath='{.spec.schedule}' 2>/dev/null)
        
        print "The CronJob is now active and will run according to schedule: ${schedule}"
        echo
        print "To suspend:"
        print "  ${SCRIPT_NAME} --concert-namespace=${CONCERT_NAMESPACE} --action=suspend --cronjob-name=${cronjob_name}"
    else
        print error "Failed to resume CronJob '${cronjob_name}'"
        exit 2
    fi
}

delete_cronjob() {
    local cronjob_name="$1"
    
    echo
    echo "===================== Deleting CronJob ====================="
    print "Concert Namespace: ${CONCERT_NAMESPACE}"
    print "CronJob Name: ${cronjob_name}"
    echo "============================================================"
    echo
    
    # Validate CronJob exists
    if ! validate_cronjob_exists "${cronjob_name}"; then
        exit 2
    fi
    
    # Get CronJob details for confirmation
    local schedule
    schedule=$("${KUBECTL}" get cronjob "${cronjob_name}" -n "${CONCERT_NAMESPACE}" \
        -o jsonpath='{.spec.schedule}' 2>/dev/null)
    
    print warn "This will permanently delete the CronJob"
    print "  CronJob: ${cronjob_name}"
    print "  Schedule: ${schedule}"
    echo
    
    # Confirmation prompt
    read -p "Are you sure you want to delete this CronJob? (yes/no): " -r confirmation
    echo
    
    if [[ "$confirmation" != "yes" ]]; then
        print "Deletion cancelled by user"
        return 0
    fi
    
    # Delete the CronJob
    print "Deleting CronJob '${cronjob_name}'..."
    if "${KUBECTL}" delete cronjob "${cronjob_name}" -n "${CONCERT_NAMESPACE}"; then
        echo
        print "CronJob '${cronjob_name}' deleted successfully"
        echo
        print "Note: Any currently running jobs from this CronJob will continue to completion."
        print "To view running jobs: ${KUBECTL} get jobs -n ${CONCERT_NAMESPACE}"
    else
        print error "Failed to delete CronJob '${cronjob_name}'"
        exit 2
    fi
}

delete_all_cronjobs() {
    echo
    echo "===================== Deleting All Scaling CronJobs ====================="
    print "Concert Namespace: ${CONCERT_NAMESPACE}"
    echo "========================================================================="
    echo
    
    # Get all CronJobs and filter for scale-to-* pattern
    local cronjobs
    cronjobs=$("${KUBECTL}" get cronjob -n "${CONCERT_NAMESPACE}" -o name 2>/dev/null \
        | grep "scale-to-" | sed 's|cronjob.batch/||' || true)
    
    if [[ -z "$cronjobs" ]]; then
        print warn "No scaling CronJobs found in namespace '${CONCERT_NAMESPACE}'"
        return 0
    fi
    
    local count
    count=$(echo "$cronjobs" | wc -l | tr -d ' ')
    
    print warn "This will permanently delete ALL ${count} scaling CronJob(s)"
    echo
    print "CronJobs to be deleted:"
    while IFS= read -r name; do
        [[ -z "$name" ]] && continue
        local schedule
        schedule=$("${KUBECTL}" get cronjob "${name}" -n "${CONCERT_NAMESPACE}" \
            -o jsonpath='{.spec.schedule}' 2>/dev/null || echo "N/A")
        print "  - ${name} (Schedule: ${schedule})"
    done <<< "$cronjobs"
    echo
    
    # Confirmation prompt
    read -p "Are you sure you want to delete ALL scaling CronJobs? (yes/no): " -r confirmation
    echo
    
    if [[ "$confirmation" != "yes" ]]; then
        print "Deletion cancelled by user"
        return 0
    fi
    
    # Delete all CronJobs
    print "Deleting all scaling CronJobs..."
    local deleted=0
    local failed=0
    
    while IFS= read -r name; do
        [[ -z "$name" ]] && continue
        if "${KUBECTL}" delete cronjob "${name}" -n "${CONCERT_NAMESPACE}" 2>/dev/null; then
            print "Deleted: ${name}"
            ((deleted++)) || true
        else
            print error "Failed to delete: ${name}"
            ((failed++)) || true
        fi
    done <<< "$cronjobs"
    
    echo
    print "=========================================="
    print "Deletion Summary:"
    print "  Successfully deleted CronJobs: ${deleted}"
    [[ $failed -gt 0 ]] && print error "  Failed: ${failed}"
    print "=========================================="
}


### ========= Main Execution ========= ###

: > "$LOG_FILE"
exec > >(tee -a "$LOG_FILE") 2>&1

main() {
    # Parse command line arguments
    parse_arguments "$@"

    print "=============================================="
    print "IBM Concert - Deployment Scaler"
    print "=============================================="
    echo
    print "Log file: ${LOG_FILE}"

    # Validate prerequisites
    print "Validating prerequisites..."
    validate_prerequisites

    # Validate namespace
    print "Validating namespace..."
    validate_namespace "$CONCERT_NAMESPACE"

    # Route to appropriate function based on mode
    case "$MODE" in
        on-demand)
            get_config_values
            run_on_demand
            ;;
        cronjob)
            get_config_values
            run_cronjob
            ;;
        manage)
            case "$ACTION" in
                list)
                    list_cronjobs
                    ;;
                suspend)
                    suspend_cronjob "$CRONJOB_NAME"
                    ;;
                resume)
                    resume_cronjob "$CRONJOB_NAME"
                    ;;
                delete)
                    delete_cronjob "$CRONJOB_NAME"
                    ;;
                delete-all)
                    delete_all_cronjobs
                    ;;
                *)
                    print error "Unknown action: $ACTION"
                    exit 2
                    ;;
            esac
            ;;
        *)
            print error "Unknown mode: $MODE"
            exit 2
            ;;
    esac
}

# Execute main function
main "$@"

exit 0
