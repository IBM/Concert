#!/bin/bash

set -e

curr_dir=`dirname $0`
cd $curr_dir
curr_dir=`pwd`

source ${curr_dir}/../k8s-utils.sh

# Load params and scale configuration (same mechanism as cdw/bin/setup)
load_params_and_config() {
    print_message INFO "Loading parameters and configuration..."
    
    local PARAMS_FILE="${curr_dir}/../../etc/params.ini"
    if [ ! -f "${PARAMS_FILE}" ]; then
        print_message ERROR "params.ini not found at: etc/params.ini"
        print_message ERROR "Please ensure params.ini exists with SCALE_CONFIG_CONCERT parameter"
        exit 1
    fi
    
    print_message INFO "Loading parameters from: etc/params.ini"
    set -a
    source "${PARAMS_FILE}"
    set +a
    print_message INFO "Parameters loaded successfully from params.ini"
    
    # SCALE_CONFIG_CONCERT must be defined in params.ini
    if [ -z "${SCALE_CONFIG_CONCERT}" ]; then
        print_message ERROR "SCALE_CONFIG_CONCERT is not defined in params.ini"
        print_message ERROR "Please add SCALE_CONFIG_CONCERT parameter (e.g., SCALE_CONFIG_CONCERT=level_2)"
        exit 1
    fi
    
    # Load scale configuration file using SCALE_CONFIG_CONCERT
    local sclcfg="${curr_dir}/../etc/${SCALE_CONFIG_CONCERT}.cfg"
    if [ ! -f "${sclcfg}" ]; then
        print_message ERROR "Scale config file not found: ${sclcfg}"
        print_message ERROR "Please ensure the scale config file exists for SCALE_CONFIG_CONCERT=${SCALE_CONFIG_CONCERT}"
        exit 1
    fi
    
    print_message INFO "Loading scale config from: ${sclcfg}"
    set -a
    source "${sclcfg}"
    set +a
}

# Load configuration at startup
load_params_and_config

# Default values
DRY_RUN="${DRY_RUN:-false}"
VERBOSE="${VERBOSE:-false}"

# Function to check prerequisites
check_prerequisites() {
    print_message INFO "Checking prerequisites..." 
    
    # Check namespace
    if ! kubectl get namespace "$NAMESPACE" &> /dev/null; then
        print_message ERROR "Namespace '$NAMESPACE' does not exist."
        exit 1
    fi
    
    # Check metrics server
    if ! kubectl get deployment metrics-server -n kube-system &> /dev/null; then
        print_message WARN "Metrics server not found in kube-system namespace."
        print_message WARN "HPA requires metrics server to function properly."
        if [ -t 0 ]; then
            read -p "Continue anyway? (y/N): " -n 1 -r
            echo
            if [[ ! $REPLY =~ ^[Yy]$ ]]; then
                exit 1
            fi
        else
            print_message WARN "Non-interactive mode detected, continuing anyway..."
        fi
    fi
    
    print_message SUCCESS "Prerequisites check passed"
}

# Function to apply HPA configurations
apply_hpa() {
    print_message INFO "Applying HPA configurations..."
    
    local apply_cmd="kubectl apply"
    [ "$DRY_RUN" = "true" ] && apply_cmd="kubectl apply --dry-run=client" && print_message WARN "DRY RUN MODE - No changes will be made"
    
    # Process template files using update_params_yamls (same as deploy-k8s.sh)
    print_message INFO "Processing template files with update_params_yamls..."
    update_params_yamls "${curr_dir}"
    
    # Check if kustomization.yaml was generated
    if [ ! -f "$curr_dir/kustomization.yaml" ]; then
        print_message ERROR "kustomization.yaml not found after template processing"
        exit 1
    fi
    
    print_message INFO "Using kustomize to apply configurations..."
    cd "$curr_dir"
    
    if [ "$VERBOSE" = "true" ]; then
        kubectl kustomize . | $apply_cmd -n "$NAMESPACE" -f -
    else
        kubectl kustomize . | $apply_cmd -n "$NAMESPACE" -f - > /dev/null 2>&1
    fi
    
    if [ $? -eq 0 ]; then
        print_message SUCCESS "HPA configurations applied successfully"
    else
        print_message ERROR "Failed to apply HPA configurations"
        exit 1
    fi
}

# Function to verify HPA status
verify_hpa() {
    print_message INFO "Verifying HPA status..."
    sleep 5  # Wait for HPAs to be created
    
    local hpas=(
        "concert-solis-gw-hpa"
        "roja-compliance-hpa"
        "roja-g-fwk-hpa"
        "roja-ingestion-hpa"
        "roja-ingestion-common-hpa"
        "roja-mgmt-hpa"
        "roja-pipeline-hpa"
        "roja-portal-gw-hpa"
        "roja-py-utils-hpa"
        "roja-sra-hpa"
        "roja-ui-hpa"
        "rojacore-hpa"
    )
    
    local failed=0
    for hpa in "${hpas[@]}"; do
        kubectl get hpa "$hpa" -n "$NAMESPACE" &> /dev/null && print_message SUCCESS "HPA '$hpa' created" || { print_message ERROR "HPA '$hpa' not found"; ((failed++)); }
    done
    
    [ $failed -eq 0 ] && print_message SUCCESS "All HPAs verified successfully" || { print_message ERROR "$failed HPA(s) failed verification"; exit 1; }
}

# Function to show HPA status
show_status() {
    print_message INFO "Current HPA Status:"
    kubectl get hpa -n "$NAMESPACE"
}

# Function to show usage
usage() {
    cat << EOF
Usage: $0 [OPTIONS]

Deploy Horizontal Pod Autoscaler configurations for IBM Concert

OPTIONS:
    -n, --namespace NAMESPACE    Kubernetes namespace (default: concert)
    -d, --dry-run               Perform a dry run without making changes
    -v, --verbose               Enable verbose output
    -s, --status-only           Only show HPA status, don't deploy
    -h, --help                  Show this help message

ENVIRONMENT VARIABLES:
    NAMESPACE                   Kubernetes namespace
    DRY_RUN                     Set to 'true' for dry run
    VERBOSE                     Set to 'true' for verbose output

EXAMPLES:
    # Deploy with default settings
    $0

    # Deploy to specific namespace
    $0 -n my-namespace

    # Dry run to preview changes
    $0 --dry-run

    # Show current HPA status
    $0 --status-only

    # Deploy with env variable
    NAMESPACE=concert $0

EOF
}

# Main function
main() {
    local status_only=false
    
    # Parse command line arguments
    while [[ $# -gt 0 ]]; do
        case $1 in
            -n|--namespace)
                NAMESPACE="$2"
                shift 2
                ;;
            -d|--dry-run)
                DRY_RUN=true
                shift
                ;;
            -v|--verbose)
                VERBOSE=true
                shift
                ;;
            -s|--status-only)
                status_only=true
                shift
                ;;
            -h|--help)
                usage
                exit 0
                ;;
            *)
                print_message ERROR "Unknown option: $1"
                usage
                exit 1
                ;;
        esac
    done
    
    # Set namespace: command line input takes precedence, otherwise use CONCERT_NS from params.ini
    if [ -z "${NAMESPACE}" ]; then
        NAMESPACE="${CONCERT_NS}"
    fi
    
    echo "=========================================="
    echo "IBM Concert HPA Deployment"
    echo "=========================================="
    echo ""
    
    print_message INFO "Using namespace: ${NAMESPACE}"
    print_message INFO "Using scale config: ${SCALE_CONFIG_CONCERT}"
    
    if [ "$status_only" = "true" ]; then
        check_prerequisites
        show_status
        exit 0
    fi
    
    # Execute deployment steps
    check_prerequisites
    
    if [ "$DRY_RUN" != "true" ]; then
        if [ -t 0 ]; then
            read -p "Proceed with deployment? (y/N): " -n 1 -r
            echo
            [[ ! $REPLY =~ ^[Yy]$ ]] && {
                print_message INFO "Deployment cancelled"
                exit 0
            }
        else
            print_message WARN "Non-interactive mode detected, skipping confirmation"
        fi
    fi
    
    apply_hpa
    
    if [ "$DRY_RUN" != "true" ]; then
        verify_hpa
        echo ""
        show_status
    fi
    
    echo ""
    print_message SUCCESS "HPA deployment completed successfully!"
    echo ""
}

# Run main function
main "$@"


