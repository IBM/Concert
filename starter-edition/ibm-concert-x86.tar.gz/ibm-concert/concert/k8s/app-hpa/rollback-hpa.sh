#!/bin/bash

set -e

curr_dir=`dirname $0`
cd $curr_dir
curr_dir=`pwd`

source ${curr_dir}/../k8s-utils.sh

# Load params and scale configuration (same mechanism as deploy-hpa.sh)
load_params_and_config() {
    print_message INFO "Loading parameters and configuration..."
    
    local PARAMS_FILE="${curr_dir}/../../etc/params.ini"
    if [ ! -f "${PARAMS_FILE}" ]; then
        print_message ERROR "params.ini not found at: etc/params.ini"
        exit 1
    fi
    
    print_message INFO "Loading parameters from: etc/params.ini"
    set -a
    source "${PARAMS_FILE}"
    set +a
    print_message INFO "Parameters loaded successfully from params.ini"
    
    # Use level_1 as default if SCALE_CONFIG_CONCERT is not defined in params.ini
    if [ -z "${SCALE_CONFIG_CONCERT}" ]; then
        print_message WARN "SCALE_CONFIG_CONCERT is not defined in params.ini, using default: level_1"
        SCALE_CONFIG_CONCERT="level_1"
    fi
    
    # Load scale configuration file using SCALE_CONFIG_CONCERT
    local sclcfg="${curr_dir}/../etc/${SCALE_CONFIG_CONCERT}.cfg"
    if [ ! -f "${sclcfg}" ]; then
        print_message ERROR "Scale config file not found: ${sclcfg}"
        print_message ERROR "Please ensure the scale config file exists for SCALE_CONFIG_CONCERT=${SCALE_CONFIG_CONCERT}"
        exit 1
    fi
    
    print_message INFO "Loading scale config from: ${sclcfg}"
    set -a
    source "${sclcfg}"
    set +a
}

# Load configuration at startup
load_params_and_config

# Default values
DRY_RUN="${DRY_RUN:-false}"
VERBOSE="${VERBOSE:-false}"
FORCE="${FORCE:-false}"

# Function to check prerequisites
check_prerequisites() {
    print_message INFO "Checking prerequisites..." 
    
    # Check namespace
    if ! kubectl get namespace "$NAMESPACE" &> /dev/null; then
        print_message ERROR "Namespace '$NAMESPACE' does not exist."
        exit 1
    fi
    
    print_message SUCCESS "Prerequisites check passed"
}

# Function to list current HPAs
list_current_hpas() {
    print_message INFO "Checking for existing HPAs..."
    
    local hpa_count=$(kubectl get hpa -n "$NAMESPACE" -l app.kubernetes.io/name=ibm-concert 2>/dev/null | grep -v NAME | wc -l | tr -d ' ')
    
    if [ "$hpa_count" -eq 0 ]; then
        print_message WARN "No HPAs found in namespace '$NAMESPACE'"
        return 1
    fi
    
    print_message INFO "Found $hpa_count HPA(s) in namespace '$NAMESPACE'"
    
    if [ "$VERBOSE" = "true" ]; then
        kubectl get hpa -n "$NAMESPACE" -l app.kubernetes.io/name=ibm-concert
    fi
    
    return 0
}

# Function to delete HPAs
delete_hpa() {
    print_message INFO "Deleting HPA resources..."
    
    local hpas=(
        "concert-solis-gw-hpa"
        "roja-compliance-hpa"
        "roja-g-fwk-hpa"
        "roja-ingestion-hpa"
        "roja-ingestion-common-hpa"
        "roja-mgmt-hpa"
        "roja-pipeline-hpa"
        "roja-portal-gw-hpa"
        "roja-py-utils-hpa"
        "roja-sra-hpa"
        "roja-ui-hpa"
        "rojacore-hpa"
    )
    
    local deleted=0
    local not_found=0
    
    for hpa in "${hpas[@]}"; do
        if [ "$DRY_RUN" = "true" ]; then
            if kubectl get hpa "$hpa" -n "$NAMESPACE" &> /dev/null; then
                print_message INFO "[DRY RUN] Would delete HPA: $hpa"
                deleted=$((deleted + 1))
            else
                if [ "$VERBOSE" = "true" ]; then
                    print_message INFO "[DRY RUN] HPA not found: $hpa"
                fi
                not_found=$((not_found + 1))
            fi
        else
            if kubectl get hpa "$hpa" -n "$NAMESPACE" &> /dev/null; then
                if kubectl delete hpa "$hpa" -n "$NAMESPACE" &> /dev/null; then
                    print_message SUCCESS "Deleted HPA: $hpa"
                    deleted=$((deleted + 1))
                else
                    print_message ERROR "Failed to delete HPA: $hpa"
                fi
            else
                if [ "$VERBOSE" = "true" ]; then
                    print_message INFO "HPA not found (may already be deleted): $hpa"
                fi
                not_found=$((not_found + 1))
            fi
        fi
    done
    
    if [ "$DRY_RUN" = "true" ]; then
        print_message INFO "[DRY RUN] Would delete $deleted HPA(s)"
    else
        print_message SUCCESS "Deleted $deleted HPA(s)"
    fi
    
    if [ "$VERBOSE" = "true" ] && [ $not_found -gt 0 ]; then
        print_message INFO "$not_found HPA(s) not found"
    fi
}

# Function to restore deployment replica counts
restore_replicas() {
    print_message INFO "Restoring deployment replica counts..."
    
    # Define deployments and their replica variables as parallel arrays
    local deployments=(
        "concert-solis-gw"
        "roja-compliance"
        "roja-g-fwk"
        "roja-ingestion"
        "roja-ingestion-common"
        "roja-mgmt"
        "roja-pipeline"
        "roja-portal-gw"
        "roja-py-utils"
        "roja-sra"
        "roja-ui"
        "rojacore"
    )
    
    local replica_vars=(
        "${SOLIS_GW_REPLICAS}"
        "${COMP_REPLICAS}"
        "${G_FWK_REPLICAS}"
        "${ING_REPLICAS}"
        "${ING_COMMON_SVC_REPLICAS}"
        "${MGMT_REPLICAS}"
        "${PIPEL_REPLICAS}"
        "${PORTAL_GW_REPLICAS}"
        "${PY_UTILS_REPLICAS}"
        "${SRA_REPLICAS}"
        "${ROJA_UI_REPLICAS}"
        "${ROJA_CORE_REPLICAS}"
    )
    
    local scaled=0
    local not_found=0
    
    for i in "${!deployments[@]}"; do
        local deployment="${deployments[$i]}"
        local replicas="${replica_vars[$i]}"
        
        if [ -z "$replicas" ]; then
            print_message WARN "Replica count not defined for $deployment, skipping"
            continue
        fi
        
        if [ "$DRY_RUN" = "true" ]; then
            if kubectl get deployment "$deployment" -n "$NAMESPACE" &> /dev/null; then
                print_message INFO "[DRY RUN] Would scale $deployment to $replicas replicas"
                scaled=$((scaled + 1))
            else
                if [ "$VERBOSE" = "true" ]; then
                    print_message INFO "[DRY RUN] Deployment not found: $deployment"
                fi
                not_found=$((not_found + 1))
            fi
        else
            if kubectl get deployment "$deployment" -n "$NAMESPACE" &> /dev/null; then
                if kubectl scale deployment "$deployment" --replicas="$replicas" -n "$NAMESPACE" &> /dev/null; then
                    print_message SUCCESS "Scaled $deployment to $replicas replicas"
                    scaled=$((scaled + 1))
                else
                    print_message ERROR "Failed to scale $deployment"
                fi
            else
                if [ "$VERBOSE" = "true" ]; then
                    print_message INFO "Deployment not found: $deployment"
                fi
                not_found=$((not_found + 1))
            fi
        fi
    done
    
    if [ "$DRY_RUN" = "true" ]; then
        print_message INFO "[DRY RUN] Would scale $scaled deployment(s)"
    else
        print_message SUCCESS "Scaled $scaled deployment(s) to original replica counts"
    fi
    
    if [ "$VERBOSE" = "true" ] && [ $not_found -gt 0 ]; then
        print_message INFO "$not_found deployment(s) not found"
    fi
}

# Function to verify rollback
verify_rollback() {
    print_message INFO "Verifying rollback..."
    
    local hpa_count=$(kubectl get hpa -n "$NAMESPACE" -l app.kubernetes.io/name=ibm-concert 2>/dev/null | grep -v NAME | wc -l | tr -d ' ')
    
    if [ "$hpa_count" -eq 0 ]; then
        print_message SUCCESS "No HPAs found in namespace (rollback successful)"
    else
        print_message WARN "Found $hpa_count HPA(s) still in namespace"
        [ "$VERBOSE" = "true" ] && kubectl get hpa -n "$NAMESPACE" -l app.kubernetes.io/name=ibm-concert
    fi
}

# Function to show HPA status
show_status() {
    print_message INFO "Current HPA Status:"
    
    local hpa_count=$(kubectl get hpa -n "$NAMESPACE" 2>/dev/null | grep -v NAME | wc -l | tr -d ' ')
    
    if [ "$hpa_count" -eq 0 ]; then
        print_message INFO "No HPAs found in namespace '$NAMESPACE'"
    else
        kubectl get hpa -n "$NAMESPACE"
    fi
}

# Function to show usage
usage() {
    cat << EOF
Usage: $0 [OPTIONS]

Rollback Horizontal Pod Autoscaler configurations for IBM Concert

This script will:
  1. Delete all HPA resources from the namespace
  2. Restore deployments to their original replica counts (from scale config)

OPTIONS:
    -n, --namespace NAMESPACE    Kubernetes namespace (default: concert)
    -d, --dry-run               Perform a dry run without making changes
    -v, --verbose               Enable verbose output
    -f, --force                 Skip confirmation prompt
    -s, --status-only           Only show HPA status, don't rollback
    -h, --help                  Show this help message

ENVIRONMENT VARIABLES:
    NAMESPACE                   Kubernetes namespace
    DRY_RUN                     Set to 'true' for dry run
    VERBOSE                     Set to 'true' for verbose output
    FORCE                       Set to 'true' to skip confirmation

EXAMPLES:
    # Rollback with confirmation
    $0

    # Rollback specific namespace
    $0 -n my-namespace

    # Dry run to preview changes
    $0 --dry-run

    # Force rollback without confirmation
    $0 --force

    # Show current HPA status
    $0 --status-only

    # Rollback with verbose output
    $0 --verbose

EOF
}

# Main function
main() {
    local status_only=false
    
    # Parse command line arguments
    while [[ $# -gt 0 ]]; do
        case $1 in
            -n|--namespace)
                NAMESPACE="$2"
                shift 2
                ;;
            -d|--dry-run)
                DRY_RUN=true
                shift
                ;;
            -v|--verbose)
                VERBOSE=true
                shift
                ;;
            -f|--force)
                FORCE=true
                shift
                ;;
            -s|--status-only)
                status_only=true
                shift
                ;;
            -h|--help)
                usage
                exit 0
                ;;
            *)
                print_message ERROR "Unknown option: $1"
                usage
                exit 1
                ;;
        esac
    done
    
    # Set namespace: command line input takes precedence, otherwise use CONCERT_NS from params.ini
    if [ -z "${NAMESPACE}" ]; then
        NAMESPACE="${CONCERT_NS}"
    fi
    
    echo "=========================================="
    echo "IBM Concert HPA Rollback"
    echo "=========================================="
    echo ""
    
    print_message INFO "Using namespace: ${NAMESPACE}"
    print_message INFO "Using scale config: ${SCALE_CONFIG_CONCERT}"
    
    if [ "$status_only" = "true" ]; then
        check_prerequisites
        show_status
        exit 0
    fi
    
    # Execute rollback steps
    check_prerequisites
    
    # Check if HPAs exist
    if ! list_current_hpas; then
        print_message INFO "Nothing to rollback"
        exit 0
    fi
    
    echo ""
    
    if [ "$DRY_RUN" = "true" ]; then
        print_message WARN "DRY RUN MODE - No changes will be made"
    else
        print_message WARN "This will delete all HPA resources and restore original replica counts"
    fi
    
    # Confirmation prompt (unless --force or --dry-run)
    if [ "$DRY_RUN" != "true" ] && [ "$FORCE" != "true" ]; then
        if [ -t 0 ]; then
            read -p "Proceed with rollback? (y/N): " -n 1 -r
            echo
            [[ ! $REPLY =~ ^[Yy]$ ]] && {
                print_message INFO "Rollback cancelled"
                exit 0
            }
        else
            print_message WARN "Non-interactive mode detected, use --force to skip confirmation"
            exit 1
        fi
    fi
    
    echo ""
    delete_hpa
    echo ""
    restore_replicas
    
    if [ "$DRY_RUN" != "true" ]; then
        echo ""
        verify_rollback
        echo ""
        show_status
    fi
    
    echo ""
    if [ "$DRY_RUN" = "true" ]; then
        print_message SUCCESS "Dry run completed. Use without --dry-run to execute rollback."
    else
        print_message SUCCESS "HPA rollback completed successfully!"
    fi
    echo ""
}

# Run main function
main "$@"
