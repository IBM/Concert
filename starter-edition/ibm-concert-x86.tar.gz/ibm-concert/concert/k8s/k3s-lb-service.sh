#!/usr/bin/env bash


set -e

curr_dir=`dirname $0`
cd $curr_dir
curr_dir=`pwd`

source ${curr_dir}/k8s-utils.sh

############### Main  ####################

NS=$1
if [ "X$NS" =  "X" ];
then
    echo "Usage:  $0 <namespace>"
    exit 1
fi
# Optional IP family ordering for the Service (IP_FAMILIES - comma-separated
# ordered list of IPv4/IPv6, e.g. "IPv6,IPv4"), rendered into the
# ${SVC_IP_FAMILIES} placeholder of the templates. When unset the placeholder
# renders empty; the policy itself is fixed to PreferDualStack in the templates.
export SVC_IP_FAMILIES=""
if [[ -n "${IP_FAMILIES:-}" ]]; then
    SVC_IP_FAMILIES="  ipFamilies:"
    for ip_family in ${IP_FAMILIES//,/ }; do
        SVC_IP_FAMILIES+=$'\n'"    - ${ip_family}"
    done
fi

sdir=${curr_dir}/app-in-k3s
update_params_yamls ${sdir}

kubectl kustomize ${sdir} | kubectl apply  --namespace=$NS -f -
