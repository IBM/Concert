#########################################
## IBM Confidential                    ##
## PID: 5900-BD6, 5900-BBE             ##
## Copyright IBM Corp. 2024            ##
#########################################

# Steps to install IBM Concert in a Linux x86 machine

The IBM Concert (ibm-concert-std.tgz) package is a set of containerized Services that are meant to run in a Linux machine.

The package includes scripts and utilities for you to setup and operate the Concert services on your Linux system.

## Before you begin

### Pre-requisites

Currently only Linux x86_64 is supported. 

For optimal security and stability, it is highly recommended to install as a non-root user. 

A Docker or Podman (v4) installation that is supported for your Linux distribution is a pre-requisite. The "root-less" configuration of Podman at version v4.3 or later is highly recommended for security reasons.

Docker installation instructions: https://docs.docker.com/engine/install/#server

Podman installation instructions:  https://podman.io/docs/installation#installing-on-linux

Note: for SUSE Linux, podman is only available with version SLES 15.4. Upgrade the system first (zypper dist-upgrade) before installing the dependencies that are not provided but are needed for the installation of docker or podman.

For Docker:
sysuser-shadow in SLES 12.5
catatonit in SLES 15.5

For Podman:
fuse-overlayfs in SLES 15.4

Note: Packages can be downloaded from the official SLES site: https://software.opensuse.org/package/ 


### Container Image Registry and access keys

Ensure that you have your key to access the IBM Container Registry. You will need to log in to the registry with the key and pull the runtime images to your local machine.

Note, you can also mirror the Concert images to your own private registry upfront and then, during Concert setup, pull from the private registry instead of the IBM Container Registry.

---


## Installation Procedure

1) Extract the .tgz package under a pre-selected directory with at least 512GB disk space.

for example: 

cd <install_root> 

tar xfz ibm-concert-std.tgz

2) Setup 

a) Authenticate with the source Image  registry 

You must run docker or podman login to authenticate with the container registry where the images are to be pulled from.

For example -

docker:

docker login ${IBM_ICR_IO} \
--username=${PROD_USER} \
--password=${IBM_ENTITLEMENT_KEY}

podman:

podman login ${IBM_ICR_IO} \
--username=${PROD_USER} \
--password=${IBM_ENTITLEMENT_KEY}


b) Run ibm-concert-std/bin/setup.sh to prepare your machine

This script will 

- pull all images

- create a subdirectory under localstorage/ for use as mounted volumes in the containers

- apply initial configuration.

For example: 

ibm-concert-std/bin/setup --license_acceptance=y --registry=${IBM_ICR_IO} --tag=${CONCERT_IMAGE_TAG} --runtime=podman --username=ibmconcert --password

(you will be prompted to select a password for the 'ibmconcert' user)

ibm-concert-std/bin/setup --help will describe all supported options

Note: the file ibm-concert-std/etc/local_config.env captures the configuration options

3) Start containers

ibm-concert-std/bin/start

4) To open the Concert console :

    Visit: https://localhost:<https_port> in your browser. Select the port number that you optionally entered during setup. 

    For remote access replace "localhost" with the machine hostname.

    for example - https://concert-host-01:12443/


5) Show status of all services

ibm-concert-std/bin/status 

6) Stop all services

ibm-concert-std/bin/stop 

7) Reset concert data (excluding the user credentials)

ibm-concert-std/bin/reset
