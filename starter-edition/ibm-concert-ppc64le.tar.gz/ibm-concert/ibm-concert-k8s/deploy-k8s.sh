#!/usr/bin/env bash


curr_dir=`dirname $0`
cd $curr_dir
curr_dir=`pwd`

source ${curr_dir}/k8s-utils.sh

set -e

trap 'catch $? $FUNCNAME $LINENO' EXIT
catch() {
  if [ "$1" != "0" ]; then
    echo "FAILED:  error num: $1 occurred at: $2 $3"
  fi
}

kc_kust()
{
    print_message INFO "kc_kust: $1"
    abdir=${curr_dir}/app-build-cfg
    cat ${abdir}/common.yaml >> ${curr_dir}/$1/kustomization.yaml
    if [ "X${ROJA_k8s_PREVIEW}" != "X" ];
    then
        print_message INFO "ROJA_k8s_PREVIEW: ${ROJA_k8s_PREVIEW}"
        kubectl kustomize ${curr_dir}/${1} >> ${ROJA_k8s_PREVIEW}
    else
        kubectl kustomize ${curr_dir}/${1} |  kubectl apply ${KC_ARGS} --namespace=$NS -f -
    fi
}

setid()
{
   if [[ "x${RUNASUSER}" == "x" ]]
   then
       ifocp=$(kubectl api-resources --api-group=route.openshift.io --no-headers)
       if [[ "x$ifocp" == "x" ]]
       then
           export RUNASUSER=1000
           export RUNASGROUP=1000
           export FS_GROUPID=1000
           export SUPP_GROUPID=1000
       else
           rangestr=`kubectl get namespace ${namespace} -o jsonpath='{.metadata.annotations.openshift\.io/sa\.scc\.uid-range}'`
           rangeid="${rangestr%/*}"
           export RUNASUSER=${rangeid}
           export RUNASGROUP=${rangeid}
           export FS_GROUPID=${rangeid}
           export SUPP_GROUPID=${rangeid}
       fi
   fi
}

check_and_handle_schema_jobs() {
    local namespace="${1}"

    print_message INFO "Checking for running schema-validation jobs in namespace '${namespace}'..."

    local jobs
    jobs=$(kubectl get jobs -n "${namespace}" -l component=schema-validation -o jsonpath='{.items[*].metadata.name}')

    local all_jobs=()
	for job_name in $jobs; do
		all_jobs+=("${job_name}")
	done

    if [[ ${#all_jobs[@]} -gt 0 ]]; then
        print_message WARN "The following schema-validation jobs are present in '${namespace}':"
        for job in "${all_jobs[@]}"; do
            echo "  - ${job}"
        done
		local delete_cmd="kubectl delete jobs -n ${namespace} -l component=schema-validation --ignore-not-found"
		print_message ERROR "Cannot proceed with the upgrade: schema-validation jobs are still present in the namespace: ${namespace}"
        print_message INFO "Running jobs will continue until completion."
		print_message INFO "Finished jobs (succeeded or failed) will be automatically removed by Kubernetes after 5 minutes (ttlSecondsAfterFinished=300)."
		print_message INFO "Manual deletion is optional, but deleting jobs now may result in incomplete validation and logs."
		print_message INFO "You can cleanup the jobs by running: ${delete_cmd}"
        exit 1
    else
        print_message INFO "No running schema-validation jobs found."
    fi
}

setup()
{
    print_message INFO "initiating setup for $NS.."

    first_time=true
    if [ -z ${ROJA_k8s_PREVIEW} ];
    then
        curr_status=$(kubectl get secret --ignore-not-found app-cfg-internal-tls -o name  -n $NS)
        if [ x"$curr_status" == x"secret/app-cfg-internal-tls" ];
        then
            first_time=false
        fi
    fi

	check_and_handle_schema_jobs "${NS}"

    if [ x"${FORCE_SETUP}" == x"true" ] || [ x"$first_time" == x"true" ];
    then
        ### first time setup - its not idempotent because we cannot change the oob secrets afterwards for the 'native' case.

        setup_namespace $NS

        setid
        update_params

        if [ x"${ROJA_k8s_cfg}" == x"sw_ent_native" ];
        then
            setup_pull_secrets $NS 
        fi

        ## this is for the cpfs case when, we want to pull from a dev-test registry instead of relying on Global Pull Secrets
        if [ x"${ROJA_k8s_dev}" != x ];
        then
            setup_pull_secrets $NS 
        fi


        print_message INFO "generating secrets"
        generate_roja_app_secrets ${curr_dir}/setup/roja-app.secrets
        rm -f ${curr_dir}/setup/roja-oob.secrets
        touch ${curr_dir}/setup/roja-oob.secrets
        rm -f ${curr_dir}/setup-cpfs/roja-edb.secrets
        touch ${curr_dir}/setup-cpfs/roja-edb.secrets
        generate_edb_secret ${curr_dir}/setup-cpfs/roja-edb.secrets ${NS}

        generate_oob_secrets ${curr_dir}/setup/roja-oob.secrets ${NS}
        
        if [ x"${ROJA_k8s_cfg}" == xsw_ent_cpfs ];
        then
           cat ${curr_dir}/setup-cpfs/initialize-sw-ent-cpfs.yaml >  ${curr_dir}/setup-cpfs/kustomization.yaml
           cat  ${curr_dir}/setup/initialize.yaml  ${curr_dir}/setup/setup.yaml > ${curr_dir}/setup/kustomization.yaml   
           kc_kust setup-cpfs
        
        else
            cat ${curr_dir}/setup/initialize.yaml ${curr_dir}/setup/setup.yaml > ${curr_dir}/setup/kustomization.yaml

        fi
        cat ${curr_dir}/setup/mgmt.yaml >> ${curr_dir}/setup/kustomization.yaml
        kc_kust setup

        wait_for_job "component=roja-mgmt-init-tls"
        print_message INFO "$FUNCNAME: $NS"
    else 

        setid
        update_params
        update_configmap_for_upgrade ${NS}

        if [ x"${ROJA_k8s_cfg}" == x"sw_ent_native" ];
        then
            setup_pull_secrets $NS
        fi

        if ([  x"${ROJA_k8s_cfg}" == xsw_ent_cpfs ] || [  x"${ROJA_k8s_cfg}" == xsw_ent_native ]) && [ $ROJA_UPGRADE == true ];
        then
            print_message INFO "Upgrading...mgmt "
            cp ${curr_dir}/setup/setup.yaml ${curr_dir}/setup/kustomization.yaml
            cat ${curr_dir}/setup/mgmt.yaml >> ${curr_dir}/setup/kustomization.yaml
            kc_kust setup
            generate_upgrade_required_secret ${NS}
            wait_for_job "component=roja-mgmt-init-tls"
            print_message INFO "$FUNCNAME: $NS"
        fi

        # Cleanup successful jobs in SaaS
        if [ x"${ROJA_k8s_cfg}" == xsaas_ent ];
        then
            job_name=$(kubectl get job --ignore-not-found roja-pre-job -o name  -n $NS)
            if [ x"$job_name" == x"job.batch/roja-pre-job" ];
            then
                job_success=$(kubectl get job --ignore-not-found roja-pre-job -o json  -n $NS | jq -r '.status.succeeded')
                if [ x"$job_success" == x"1" ];
                then
                    kubectl delete job --ignore-not-found roja-pre-job -n $NS 
                fi         
            fi
        fi
        print_message INFO "$NS was already setup."

    fi
}

update_params()
{
    $TRACE updating placeholder parameters, generating yamls..

    basedir=${curr_dir}/app-base
    abdir=${curr_dir}/app-build-cfg
    predir=${curr_dir}/pre-reqs

    export ROJA_DOMAIN="${NS}.svc"

    if [ x"$ROJA_SCALE_CONFIG" == x ];
    then
        export ROJA_SCALE_CONFIG=level_1
    fi

    sclcfg="${curr_dir}/etc/${ROJA_SCALE_CONFIG}.cfg"
    $TRACE scale_config file: ${sclcfg}
    set -a
    source ${sclcfg}
    set +a

    update_params_yamls  ${curr_dir}/setup
    update_params_yamls  ${curr_dir}/setup-cpfs
    update_params_yamls  ${curr_dir}/app-prep
    update_params_yamls  ${curr_dir}/dev-cfg
    update_params_yamls  ${basedir}
    update_params_yamls  ${abdir}
    update_params_yamls  ${predir}
    update_params_yamls  ${curr_dir}/app-post-cpfs
    update_params_yamls  ${curr_dir}/app-post-saas
    update_params_yamls  ${curr_dir}/schema-validation
    update_params_yamls  ${curr_dir}/app-metering-events
    if [ x"${ADD_MINIO}" != x ];
    then
        cat ${predir}/minio.yaml >> ${predir}/kustomization.yaml
    fi

    if [ x"${ADD_POSTGRES}" != x ];
    then
        cat ${predir}/postgres.yaml >> ${predir}/kustomization.yaml
    fi

    if [ x"${ADD_EDB}" != x ];
    then
        cat ${predir}/edb.yaml >> ${predir}/kustomization.yaml
    fi

    if [ x"${ADD_SA}" != x ];
    then
        cat ${predir}/serviceaccount.yaml >> ${predir}/kustomization.yaml
    fi

}


## self-contained .. mainly for dev/test - matches ibm-roja-dev
## includes minio, postgresql
cfg_sw_ent_native()
{
    if [ "$BYO_CONFIGDB" == "false" ] && [ "$BYO_APPDB" == "false" ];
    then
        export ADD_POSTGRES=true
        export DB_COMPONENT=roja-postgres
    fi
    if [ "$BYO_ELBUCKET" == "false" ] && [ "$BYO_LZBUCKET" == "false" ];
    then
        export ADD_MINIO=true
    fi
    export ROJA_CONTEXT=sw_ent
    export ADD_SA=true
    export ROJA_AUTH=native
}

#arg: key=value label condition
wait_for_job()
{
    if [ "X${ROJA_k8s_PREVIEW}" != "X" ];
    then
        return 0
    fi
    print_message INFO "$FUNCNAME: $NS -  $1"
    joblabel="-l $1"

    COUNT=0
    ATTEMPTS=20
    sc=""
    until [[ x"$sc"x != xx ]] || [[ $COUNT -eq $ATTEMPTS ]]; do
        sleep 6
        sc=$(kubectl get -n $NS job --ignore-not-found ${joblabel} -o jsonpath={.items[0].status})
        echo -e "$(( COUNT++ ))... \c"
    done
    echo
    [[ $COUNT -eq $ATTEMPTS ]] && print_message ERROR "failure with $FUNCNAME: $NS $1" && (return 1)

    COUNT=0
    ct=""
    until [[ x"$ct"x != xx ]] || [[ $COUNT -eq $ATTEMPTS ]]; do
        sleep 30
        ct=$(kubectl get -n $NS job --ignore-not-found ${joblabel} -o jsonpath={.items[0].status.completionTime}) 
        echo -e "$(( COUNT++ ))... \c"
    done
    echo

    [[ $COUNT -eq $ATTEMPTS ]] && print_message WARNING "failure with $FUNCNAME: $NS $1 - job did not complete " && (return 1)

    result=$(kubectl get -n $NS job --ignore-not-found ${joblabel} -o jsonpath={.items[0].status.succeeded}) 

    if [ x"$result"x == xx ];
    then
        result=$(kubectl get -n $NS job --ignore-not-found ${joblabel} -o jsonpath={.items[0].status.failed}) 
        print_message WARNING "$NS $1 failed: $result. Completion time: $ct"
    else
        print_message INFO "$NS $1 succeeded: $result. Completion time: $ct"
    fi
    return 0
}

wait_for_zen_extn()
{
    if [ "X${ROJA_k8s_PREVIEW}" != "X" ];
    then
        return 0
    fi
    print_message INFO "$FUNCNAME: $NS "
    print_message INFO "Waiting for zen extension to complete"
    COUNT=0
    ATTEMPTS=12
    until [[ x"$sc"x != xx ]] || [[ $COUNT -eq $ATTEMPTS ]]; do
        sleep 5m
        sc=$(kubectl get ZenExtension -n $NS --ignore-not-found -l component=roja-zen-extn -o jsonpath={.items[0].status.zenExtensionStatus})

        echo -e "$(( COUNT++ ))... \c"
    done
    echo
    [[ $COUNT -eq $ATTEMPTS ]] && print_message WARNING "failure with $FUNCNAME: $NS - setting up zen extension " && (return 1)
    echo 
    sc=$(kubectl get ZenExtension -n $NS --ignore-not-found -l component=roja-zen-extn -o jsonpath={.items[0].status.zenExtensionStatus})
    if [ x"$sc"x != x"Completed"x ];
    then
      print_message WARNING "failure with $FUNCNAME: $NS - zen extension " && (return 1)
    else
      print_message INFO "$NS zen extension succeeded"
    fi
    return 0
}

delete_zen_extensions(){
    if [ "X${ROJA_k8s_PREVIEW}" != "X" ];
    then
        return 0
    fi
    print_message INFO "$FUNCNAME: $NS "
    pn=$(kubectl get cm product-configmap -n $NS -o jsonpath={.data.IBM_PRODUCT_NAME})
    if [ x"$pn"x != x"IBM Concert"x ];
    then
      #patch the prod name with IBM Concert
      kubectl patch configmap product-configmap -n $NS -p '{"data":{"IBM_PRODUCT_NAME": "IBM Concert"}}'  
      pn=$(kubectl get cm product-configmap -n $NS -o jsonpath={.data.IBM_PRODUCT_NAME})
      if [ x"$pn"x != x"IBM Concert"x ];
      then
        print_message ERROR "faiure with $FUNCNAME: $NS - failed to update product name " && (return 1)
      fi
      kubectl rollout restart deployment usermgmt -n $NS
    fi
    # get zen secret
    zs=$(kubectl get secret zen-service-broker-secret -n $NS -o jsonpath='{.data.token}' | base64 -d)
    # get zen svc URL
    url=$(kubectl get cm product-configmap -n $NS -o jsonpath={.data.ZEN_CORE_API_URL})
    id_arr=$(curl -k -X GET -H "secret: ${zs}" ${url}/v1/extensions?extension_name=dap-header-service-catalog,zen_homepage_getting_started_internal_service_catalog,dap-support-community,dap-support-diagnostics,dap-support-share-an-idea,zen_homepage_resource_community,zen_homepage_resource_diagnostics,zen_homepage_resource_share_an_idea,dap-support-open-a-ticket,zen_homepage_resource_open_a_ticket,guided_tours,zen_lite_about_modal_info,dap-support-documentation,zen_homepage_resource_document,service_instance_details)
    extn_ids=`echo ${id_arr} | jq -r .data[].id`
    for id in ${extn_ids}; do
        curl -k -X DELETE -H "secret: ${zs}" ${url}/v1/extensions/${id}
    done
    return 0

}

sw_ent_native()
{
    print_message INFO "$FUNCNAME: $NS"
    kc_kust pre-reqs
    kc_kust app-prep
    wait_for_job "component=roja-prep"
    kc_kust app-base
    if [[ "${SCHEMA_VALIDATION_REQUIRED}" == "true" ]]; then
    kc_kust schema-validation
    fi
    kc_kust app-metering-events
}

saas_ent()
{
    print_message INFO "$FUNCNAME: $NS"
    kc_kust pre-reqs
    kc_kust app-prep
    wait_for_job "component=roja-prep"
    kc_kust app-base
    kc_kust app-post-saas
    if [[ "${SCHEMA_VALIDATION_REQUIRED}" == "true" ]]; then
    kc_kust schema-validation
    fi
}

## with cpfs pre-req
## includes minio, EDB (via CPFS)
cfg_sw_ent_cpfs()
{
    print_message INFO "$FUNCNAME: $NS"
    if [ "$BYO_CONFIGDB" == "false" ] && [ "$BYO_APPDB" == "false" ];
    then
        export ADD_EDB=true
        export DB_COMPONENT=roja-postgres-edb
    fi
    if [ "$BYO_ELBUCKET" == "false" ] && [ "$BYO_LZBUCKET" == "false" ];
    then
        export ADD_MINIO=true
    fi
    export ADD_SA=true
    export ROJA_CONTEXT=sw_ent
    export ROJA_AUTH=cpfs
    cp ${curr_dir}/app-base/rojacore-deployment.cpfs ${curr_dir}/app-base/305-rojacore-deployment.yaml.tmpl
}

check_upgrade_cpfs() {
   app_build_cm=app-build-cfg-cm 
   if kubectl get configmap  "$app_build_cm" -n "$NS" &> /dev/null; then
        print_message INFO "ConfigMap app-build-cfg-cm exists."

        CM_IMG_TAG=$(kubectl get configmap "$app_build_cm" -n "$NS" -o jsonpath="{.data.IMG_TAG}")
        if [ -n "$CM_IMG_TAG" ]; then
            print_message INFO "Current image tag is: $CM_IMG_TAG"
            print_message INFO "New image tag is: $IMG_TAG"

            # Compare the value with the expected value
            if [  "$CM_IMG_TAG" == "$IMG_TAG" ]; then
                print_message INFO "Not an upgrade."
            else
                print_message INFO "upgrade needed"
                SCHEMA_VALIDATION_REQUIRED="true"
                ROJA_UPGRADE=true
            fi
        else
            print_message INFO "image tag is missing in the config map $app_build_cm"
        fi
    else
        print_message INFO "ConfigMap $app_build_cm does not exist. Its a new deployment."
        SCHEMA_VALIDATION_REQUIRED="true"
    fi
}

sw_ent_cpfs()
{
    print_message INFO "$FUNCNAME: $NS"
    kc_kust pre-reqs
    kc_kust app-prep
    wait_for_job "component=roja-prep"
    kc_kust app-base
    kc_kust app-post-cpfs
    if [[ "${SCHEMA_VALIDATION_REQUIRED}" == "true" ]]; then
    kc_kust schema-validation
    fi
    kc_kust app-metering-events
    wait_for_zen_extn
    
    #delete_zen_extensions # no longer needed since we use ibm concert as the main page - and  just zen - not cpd_platform
}

## for saas
## out-of-the-box buckets, dbs must be present and secrets created

cfg_saas_ent()
{
    export ROJA_CONTEXT=saas
    export ROJA_AUTH=saas
    if [ x"${CLOUD_TYPE}" != x"AWS" ];
    then
        export ADD_SA=true
    fi

    print_message INFO "$FUNCNAME: $NS"
}

## no dependencies, repos
cfg_app_only()
{
    print_message INFO "$FUNCNAME: $NS"
    export ADD_SA=true
}

app_only()
{
    print_message INFO "$FUNCNAME: $NS"
    kc_kust pre-reqs
    kc_kust app-base
}


print_header()
{
    print_message INFO "deploy-k8s: $NS"
    print_message INFO "REGISTRY: $IMG_PREFIX"
    print_message INFO "IMAGE TAG: $IMG_TAG"
    print_message INFO "NAMESPACE: $NS "
    print_message INFO "ROJA_k8s_cfg: ${ROJA_k8s_cfg}"
}

pre_process_args()
{
    while [ $# -gt 0 ] ; do
      if [[ "$1" == --namespace=* ]]
      then
         NS=$(echo $1 | cut -d "=" -f 2) ;
      elif [[ "$1" == --cfg=* ]]
      then
         cfg=$(echo $1 | cut -d "=" -f 2) ;
      elif [[ "$1" == --preview=* ]]
      then
         preview=$(echo $1 | cut -d "=" -f 2) ;
      elif [[ "$1" == --storage_class=* ]]
      then
         storage_class=$(echo $1 | cut -d "=" -f 2) ;
      elif [[ "$1" == --scale_config=* ]]
      then
         scale_config=$(echo $1 | cut -d "=" -f 2) ;
      elif [[ "$1" == --external_host=* ]]
      then
         EXTERNAL_HOST=$(echo $1 | cut -d "=" -f 2) ;
      elif [[ "$1" == --hub_url=* ]]
      then
         hub_url=$(echo $1 | cut -d "=" -f 2) ;
         export HUB_URL_EXPORT_LINE="HUB_URL=${hub_url}"
      else
         NS=$1
         ### temporary default
      fi
      shift
    done


    if [ -z ${NS} ];
    then
        echo "Usage:  $0 <namespace>"
        exit 2
    fi

    if [ -z ${cfg} ];
    then
        ### temporary default
        cfg="sw_ent_native"
    fi


    if [ -z ${IMG_PREFIX} ];
    then
        echo "IMG_PREFIX env variable is unset"
        exit 1
    fi


    if [ x"${cfg}" == x"sw_ent_native" ];
    then
        if [ -z ${REG_USER} ];
        then
            echo "REG_USER env variable is unset"
            exit 1
        fi

        if [ -z ${REG_PASS} ];
        then
            echo "REG_PASS env variable is unset"
            exit 1
        fi
    fi

    if [ x"${cfg}" == x"saas_ent" ];
    then
        if [ -z ${CLOUD_TYPE} ];
        then
            ### default to IBM
            CLOUD_TYPE="IBM"
        fi
        export CLOUD_TYPE
    fi

    if [ x"${cfg}" == x"saas_ent" ]; then
        export ROJA_METERING_COLLECT_SCHEDULE="30 * * * *"
    else
        export ROJA_METERING_COLLECT_SCHEDULE="30 0 * * *"
    fi

    ROJA_k8s_cfg=${ROJA_k8s_cfg:-$cfg}
    ROJA_k8s_PREVIEW=${ROJA_k8s_PREVIEW:-$preview}
    ROJA_STORAGE_CLASS=${ROJA_STORAGE_CLASS:-$storage_class}
    ROJA_SCALE_CONFIG=${ROJA_SCALE_CONFIG:-$scale_config}
    export NS ROJA_k8s_cfg ROJA_k8s_PREVIEW ROJA_STORAGE_CLASS ROJA_SCALE_CONFIG

    # Allow user to override the secret used by the
    # ServiceAccounts when pulling images.
    export ROJA_IMG_REG_SECRET=${ROJA_IMG_REG_SECRET:-regcred}
    export MGMT_ROLE_YAML=${CUSTOM_MGMT_ROLE_YAML:-"./110-mgmt-role.yaml"}

    if [ "X${ROJA_k8s_PREVIEW}" != "X" ];
    then
        rm -f ${ROJA_k8s_PREVIEW}
    fi

    if [ x"${ROJA_k8s_cfg}" == x"sw_ent_native" ] || [ x"${ROJA_k8s_cfg}" == x"sw_ent_cpfs" ];
    then
        validate_storage_secrets $NS 
    fi

    cfg_${ROJA_k8s_cfg}
}

function chat_config() {
    export chat_target_product_id='set $target_product_id "concert";'
    export chat_target_product_url='set $target_product_url "";'
    export chat_new_uri='set $new_uri "";'
    export chat_new_host_header='set $new_host_header "";'
    export chat_proxy_set_header_host='proxy_set_header Host $new_host_header;'
    export chat_X_ForwardedFor='proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;'
    export chat_proxy_pass='proxy_pass $new_uri;'
    export chat_X_Final_URL='add_header X-Final-URL $new_uri;'
    export chat_X_Real_IP='proxy_set_header X-Real-IP $remote_addr;'
    export chat_X_Forwarded_Proto='proxy_set_header X-Forwarded-Proto $scheme;'
}

############### Main  ####################

export RUN_ID=$(date +"%s")

chat_config

pre_process_args "$@"

export SCHEMA_VALIDATION_REQUIRED="false"

export ROJA_UPGRADE=false

check_upgrade_cpfs

#update_params

print_header

setup

echo Using config ${ROJA_k8s_cfg}
${ROJA_k8s_cfg}

# Check status unless we are doing a dry run
if [ "X${ROJA_k8s_PREVIEW}" == "X" ];
then
   kubectl -n $NS rollout status Deployments,sts -l ibmsupport/app=roja --timeout=10m
fi

print_message INFO " ROJA_k8s_cfg $NS : completed."
