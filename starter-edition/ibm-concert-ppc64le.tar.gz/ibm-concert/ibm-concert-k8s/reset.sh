#!/usr/bin/env bash

#########################################
## IBM Confidential                    ##
## PID: 5900-BD6, 5900-BBE             ##
## Copyright IBM Corp. 2024            ##
#########################################

set -e

UTILS_BIN_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${UTILS_BIN_DIR}/k8s-utils.sh"

motd() {
	cat <<EOM
###########################################################
#        Script for reseting the data in concert          #
###########################################################
EOM
}

usage() {
	exitCode=${1:-0}
	cat <<EOM
Usage: ${0##*/} [-n --namespace] [-U --username] [-P --password] [-r --registry] [-t --image_tag] [-u --registry_user] [-u --registry_user] [-p --registry_password][-c  --storage_class] [-d --cfg] [-e --scale_config] [-w --wipe] [-s --setup] [-h --help] [-v --verbose]

Flags:
  -n    --namespace         Namespace were concert is deployed.
  -c    --storage_class     Name of the storageclass.
  -U    --username          Username for the concert instance
  -r    --registry          Identifies the registry to pull the IBM Concert images from.
  -t 	--image_tag 		Image tag to pull the IBM Concert images from.
  -u    --registry_user     Registry username
  -p    --registry_password Registry password
  -P    --password          Password for the concert instance
  -d    --cfg               Configuration (sw_ent_native)
  -e    --scale_config      Scale configuration. 
  -w    --wipe              To wipe out the data of the concert.
  -s    --setup             To setup the concert.
  -h    --help              Show this message
  -v    --verbose           Log verbosely

EOM
	exit "${exitCode}"
}

for arg in "$@"; do
	case "$arg" in
	--namespace=*) set -- "$@" "-n" "${arg#*=}" ;;
	--username=*) set -- "$@" "-U" "${arg#*=}" ;;
	--password=*) set -- "$@" "-P" "${arg#*=}" ;;
	--registry=*) set -- "$@" "-r" "${arg#*=}" ;;
	--image_tag=*) set -- "$@" "-t" "${arg#*=}" ;;
	--registry_user=*) set -- "$@" "-u" "${arg#*=}" ;;
	--registry_password=*) set -- "$@" "-p" "${arg#*=}" ;;
	--storage_class=*) set -- "$@" "-c" "${arg#*=}" ;;
	--cfg=*) set -- "$@" "-d" "${arg#*=}" ;;
	--scale_config=*) set -- "$@" "-e" "${arg#*=}" ;;
	--wipe) set -- "$@" "-w" ;;
	--setup) set -- "$@" "-s" ;;
	--help) set -- "$@" "-h" ;;
	--verbose) set -- "$@" "-v" ;;
	*) set -- "$@" "$arg" ;;
	esac
	shift
done

while getopts ":hvwsn:c:d:e:U:P:r:t:u:p:" opt; do
	case "${opt}" in
	h)
		motd
		usage
		;;
	n)
		NAMESPACE="${OPTARG}"
		;;
	U)
		USERNAME="${OPTARG}"
		;;
	P)
		PASSWORD="${OPTARG}"
		;;
	r)
		REGISTRY="${OPTARG}"
		;;
	t)
		IMG_TAG="${OPTARG}"
		;;
	u)
		REGISTRY_USERNAME="${OPTARG}"
		;;
	p)
		REGISTRY_PASSWORD="${OPTARG}"
		;;
	c)
		STORAGE_CLASS="${OPTARG}"
		;;
	d)
		CONFIG="${OPTARG}"
		;;
	e)
		SCALE_CONFIG="${OPTARG}"
		;;
	w)
		WIPE="true"
		;;
	s)
		SETUP="true"
		;;
	v)
		VERBOSE=1
		;;
	\?)
		echo "Error: invalid option: -${OPTARG}"
		usage 1
		;;
	:)
		echo "Error: option -${OPTARG} requires an argument"
		usage 1
		;;
	*)
		echo "Error: invalid option"
		usage 1
		;;
	esac
done
# Variables
export IMG_PREFIX=${REGISTRY}
export IMG_TAG=${IMG_TAG}
export REG_USER=${REGISTRY_USERNAME}
export REG_PASS=${REGISTRY_PASSWORD}
export ROJA_STORAGE_CLASS=${STORAGE_CLASS}
export ROJA_ADM_USERNAME=${USERNAME}
export ROJA_ADM_PASSWORD=${PASSWORD}
SCALE_CONFIG=${SCALE_CONFIG:-"level_1"}

# Functions
debug() {
	set -x
}

check() {
	if [[ -z ${WIPE} ]] && [[ -z ${SETUP} ]]; then
		print_message ERROR "--wipe or --setup must be set."
		exit 1
	fi

	if [[ -z ${REGISTRY} ]] || [[ -z ${REGISTRY_USERNAME} ]] || [[ -z ${REGISTRY_PASSWORD} ]]; then
		print_message ERROR "--registry ,--registry_user and --registry_password must be set."
		exit 1
	fi

	if [[ -z ${NAMESPACE} ]] || [[ -z ${STORAGE_CLASS} ]] || [[ -z ${CONFIG} ]] || [[ -z ${ROJA_ADM_USERNAME} ]] || [[ -z ${ROJA_ADM_PASSWORD} ]]; then
		print_message ERROR "--namespace ,--storage_class ,--cfg , --username  and --password must be set."
		exit 1
	fi
}

print_header() {
	print_message INFO "NAMESPACE: ${NAMESPACE}"
	print_message INFO "ROJA_K8S_CFG: ${CONFIG}"
	print_message INFO "STORAGE_CLASS: ${STORAGE_CLASS}"
	print_message INFO "SCALE_CONFIG: ${SCALE_CONFIG}"
}

wipe() {
	print_message INFO "Cleaning up the concert data..."
	local predir
	local add_postgres
	local abdir
	predir="${UTILS_BIN_DIR}/pre-reqs"
	abdir="${UTILS_BIN_DIR}/app-build-cfg"
	set -a
	source "${UTILS_BIN_DIR}/etc/${SCALE_CONFIG}.cfg"
	source "${UTILS_BIN_DIR}/etc/level_0.cfg"
	set +a
	if [[ ${CONFIG} == "sw_ent_native" ]]; then
		export DB_COMPONENT=roja-postgres
		add_postgres="true"
	fi
	update_params_yamls "${abdir}"
	update_params_yamls "${predir}"
	cat "${predir}/minio.yaml" >>"${predir}/kustomization.yaml"
	cat "${predir}/serviceaccount.yaml" >>"${predir}/kustomization.yaml"
	if [[ -n "${add_postgres}" ]]; then
		cat "${predir}/postgres.yaml" >>"${predir}/kustomization.yaml"
	fi
	cat "${abdir}/common.yaml" >>"${predir}/kustomization.yaml"
	if [[ ${OSTYPE} == "darwin"* ]]; then
		sed -i '' '/pvc/d' "${predir}/kustomization.yaml"
	else
		sed -i '/pvc/d' "${predir}/kustomization.yaml"
	fi
	print_message INFO "Scaling down the pods of minio ,appdb, cfgdb..."
	kubectl kustomize "${predir}" | kubectl apply ${KC_ARGS} --namespace="${NAMESPACE}" -f -
	print_message INFO "Successfully scale down the pods of minio ,appdb, cfgdb."
	print_message INFO "Deleting the pvc's of minio ,appdb, cfgdb..."
	kubectl delete pvc data-roja-minio-{0..2} roja-appdb-pvc roja-configdb-pvc --ignore-not-found --namespace="${NAMESPACE}"
	print_message INFO "Successfully deleted the pvc's of minio ,appdb, cfgdb."
	print_message INFO "Successfully cleaned up the concert data."
}

setup() {
	print_message INFO "Setting up the concert ..."
	unset MINIO_REPLICAS CFGDB_REPLICAS APPDB_REPLICAS
	"${UTILS_BIN_DIR}/deploy-k8s.sh" --namespace="${NAMESPACE}" --storage_class="${STORAGE_CLASS}" --cfg="${CONFIG}" --scale_config="${SCALE_CONFIG}"
	print_message INFO "Successfully completed the concert setup."
}

#################
#     Logic     #
#################

if [[ -n ${VERBOSE} ]]; then
	debug
fi
check
print_header
if [[ -n ${WIPE} ]]; then
	wipe
fi
if [[ -n ${SETUP} ]]; then
	setup
fi
