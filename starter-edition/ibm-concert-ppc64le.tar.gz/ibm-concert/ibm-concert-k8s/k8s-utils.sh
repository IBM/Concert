#!/only/source/this


if [ -z $curr_dir ];
then
    curr_dir=`dirname $0`
    cd $curr_dir
    curr_dir=`pwd`
fi

if [[ -n "${IMG_TAG}" ]]; then
    echo "Build version is overridden as ${IMG_TAG}"
else
    bld_version_file=${curr_dir}/etc/build_version
    if [ -f ${bld_version_file} ];
    then
    bld_version=$(cat $bld_version_file)
    fi

    if [ "X$bld_version" != X ];
    then
        export IMG_TAG=${bld_version}
    fi
fi

set -e

if [ X"${kc}" = X ];
then
    export kc=kubectl
fi

if [ X"${INT_TLS_DIR}" == X ];
then
  export INT_TLS_DIR=${curr_dir}/setup/tmp 
fi

TRACE=${TRACE:- true}

#arg1: level
#arg2,arg3 etc.: messages
print_message()
{
    shift
    echo "$(date -u) RUNID:$RUN_ID $@"
}


setup_namespace()
{
    $TRACE "entering $FUNCNAME"

    if [ -z ${ROJA_k8s_PREVIEW} ];
    then
        ns_exists=$(${kc} get sa -o name --namespace ${1} default || true)
        if [ X${ns_exists}X == XX ];
        then
            print_message INFO "creating namespace $1"
    	    ${kc} create namespace $1 --dry-run=client -o yaml | ${kc} apply ${KC_ARGS} --namespace=$1 -f -
        else
            print_message INFO "using existing namespace: ${1}"
        fi    
	fi

    $TRACE "exiting $FUNCNAME"
}

setup_pull_secrets()
{
    $TRACE "entering $FUNCNAME"

    print_message INFO "setting up registry pull secrets for ${IMG_PREFIX} "
    if [ X"${IMG_PREFIX}" = X ];
    then
        echo "WARNING: - not creating kube registry pull secret"
        return
    fi

    if [ -z ${ROJA_k8s_PREVIEW} ];
    then
    	${kc} create secret --namespace=$1 docker-registry regcred \
    	--docker-server=$IMG_PREFIX --docker-username=$REG_USER --docker-password=$REG_PASS \
    	--dry-run=client -o yaml | ${kc} apply ${KC_ARGS} --namespace=$1 -f -
	fi

    $TRACE "exiting $FUNCNAME"
}


gen_random()
{
 echo -n $(openssl rand -hex 12 )
}

generate_roja_app_secrets()
{
	ROJA_INTERNAL_SECRET=$(gen_random)
    echo "ROJA_INTERNAL_SECRET=$ROJA_INTERNAL_SECRET " >> ${1}

	CONCERT_HUB_KEY=$(gen_random)
    echo "CONCERT_HUB_KEY=$CONCERT_HUB_KEY " >> ${1}

    if [ -z ${ROJA_ADM_USERNAME} ];
    then
        ROJA_AUTH_USERNAME=$(gen_random)
    else
        ROJA_AUTH_USERNAME=${ROJA_ADM_USERNAME}
    fi
    echo "ROJA_AUTH_USERNAME=$ROJA_AUTH_USERNAME" >> ${1}

    if [ -z ${ROJA_ADM_PASSWORD} ];
    then
        ROJA_AUTH_PASSWORD=$(gen_random)
    else
        ROJA_AUTH_PASSWORD=${ROJA_ADM_PASSWORD}
    fi
    echo "ROJA_AUTH_PASSWORD=$ROJA_AUTH_PASSWORD" >> ${1}
}

generate_oob_secrets()
{
    NS=${2}
    if [ x"${ADD_MINIO}" != x ];
	then
		OOB_MINIO_ACCESS_KEY=$(gen_random)
		OOB_MINIO_SECRET_KEY=$(gen_random)
		LZ_ACCESS_KEY=${OOB_MINIO_ACCESS_KEY}
		LZ_SECRET_KEY=${OOB_MINIO_SECRET_KEY}
		EL_ACCESS_KEY=${OOB_MINIO_ACCESS_KEY}
		EL_SECRET_KEY=${OOB_MINIO_SECRET_KEY}

cat << EOS >> ${1} 
        OOB_MINIO_HOST=ibm-roja-minio-svc.${NS}.svc
        OOB_MINIO_PORT=9000
    	OOB_MINIO_ACCESS_KEY=$OOB_MINIO_ACCESS_KEY
    	OOB_MINIO_SECRET_KEY=$OOB_MINIO_SECRET_KEY
        LZ_HOST=ibm-roja-minio-svc.${NS}.svc
        LZ_PORT=9000
        LZ_SECURE=True
        LZ_BUCKET=roja-lz
    	LZ_ACCESS_KEY=$LZ_ACCESS_KEY
    	LZ_SECRET_KEY=$LZ_SECRET_KEY
        EL_HOST=ibm-roja-minio-svc.${NS}.svc
        EL_PORT=9000
        EL_SECURE=True
        EL_BUCKET=roja-el
    	EL_ACCESS_KEY=$EL_ACCESS_KEY
    	EL_SECRET_KEY=$EL_SECRET_KEY
EOS

	fi

	if [ x"${ADD_POSTGRES}" != x ] || [ x"${ADD_EDB}" != x ];
	then
        if [ x"${ADD_EDB}" != x ];
        then
          OOB_POSTGRES_USER=${POSTGRES_EDB_USER}
          OOB_POSTGRES_PASSWORD=${POSTGRES_EDB_PASSWORD}
          CONFIGDB_HOST=roja-postgres-configdb-rw.${NS}.svc
          APPDB_HOST=roja-postgres-appdb-rw.${NS}.svc
        else 
          OOB_POSTGRES_USER=$(gen_random)
          OOB_POSTGRES_PASSWORD=$(gen_random)
          CONFIGDB_HOST=ibm-roja-configdb-svc.${NS}.svc
          APPDB_HOST=ibm-roja-appdb-svc.${NS}.svc
        fi
		CONFIGDB_USER=${OOB_POSTGRES_USER}
		CONFIGDB_PASSWORD=${OOB_POSTGRES_PASSWORD}
		APPDB_USER=${OOB_POSTGRES_USER}
		APPDB_PASSWORD=${OOB_POSTGRES_PASSWORD}

cat << EOP >> ${1} 
    	OOB_POSTGRES_USER=$OOB_POSTGRES_USER
    	OOB_POSTGRES_PASSWORD=$OOB_POSTGRES_PASSWORD
        CONFIGDB_HOST=$CONFIGDB_HOST
        CONFIGDB_PORT=5432
        CONFIGDB_DBNAME=cfgdb
    	CONFIGDB_USER=$CONFIGDB_USER
    	CONFIGDB_PASSWORD=$CONFIGDB_PASSWORD
        APPDB_HOST=$APPDB_HOST
        APPDB_PORT=5432
        APPDB_DBNAME=appdb
    	APPDB_USER=$APPDB_USER
    	APPDB_PASSWORD=$APPDB_PASSWORD
EOP
	fi

}
generate_upgrade_required_secret()
{
    NS=${1}
    TARGET_SEC=app-cfg-secret 
    # List for additional keys required after upgrade
    declare -a keys=("CONCERT_HUB_KEY")

    for k in "${keys[@]}"
    do
        if ! kubectl get secret $TARGET_SEC -n ${NS} -o json | jq -e ".data | has(\"${k}\")"; then
            echo "$k not found in existing secret file. Generating..."
            v=$(gen_random)
            encodev=$(echo -n "$v" | base64)
            kubectl patch secret $TARGET_SEC -n ${NS} --type='merge' -p="{\"data\":{\"${k}\":\"${encodev}\"}}"
        fi
    done
}


generate_edb_secret()
{   NS=${2}
    POSTGRES_EDB_USER="postgres"
    POSTGRES_EDB_PASSWORD=$(gen_random)
    # s=${POSTGRES_EDB_PASSWORD}

cat << EOP >> ${1} 
    	username=${POSTGRES_EDB_USER}
    	password=${POSTGRES_EDB_PASSWORD}
EOP
}
k8s_create_tls_secret()
{
    $TRACE "entering $FUNCNAME"

 ns=$1
 tls_secret_name=$2
 ssltmpdir=$3

 ${kc} create -n ${1} secret generic ${tls_secret_name} \
   --from-file=tls.key=${ssltmpdir}/tls.key \
   --from-file=tls.crt=${ssltmpdir}/tls.crt \
   --dry-run=client -o yaml | ${kc} apply ${KC_ARGS} --namespace=$1 -f -

    $TRACE "exiting $FUNCNAME"
}

update_params_yamls()
{
    $TRACE "entering $FUNCNAME"
    template_dir=$1
    for i in $(ls ${template_dir}/*.tmpl)
    do
        $TRACE "========== applying $i ====== "
        $TRACE

        out_file=$(echo $i | sed -e 's/.tmpl//')

        envsubst < $i > $out_file
    done
    
}

apply_yamls()
{
    $TRACE "entering $FUNCNAME"

    ns=$1
    template_dir=$2
    for i in $(ls ${curr_dir}/${template_dir}/*.yaml.tmpl)
    do
        $TRACE "========== applying $i ====== "
        $TRACE

        tmpl_name=$(basename $i)

        temp_out_file="/tmp/${1}-${template_dir}-${tmpl_name}"
        envsubst < $i > $temp_out_file

        ${kc} apply ${KC_ARGS} --namespace=${ns} -f ${temp_out_file}
        
        if [ x"${CLEANUP}" == "false" ];
        then
            echo ${temp_out_file}
        else
            rm -f ${temp_out_file}
        fi

        $TRACE
        $TRACE "==================="
    done

    $TRACE "exiting $FUNCNAME"
}

# Validate secrets for bring your own storage
validate_storage_secrets()
{
    namespace=${1}
    BYO_CONFIGDB="false"
    BYO_APPDB="false"
    BYO_ELBUCKET="false"
    BYO_LZBUCKET="false"
    
    ## DB Secrets
    secret_ref=$(kubectl get secret --ignore-not-found concert-configdb-creds -o name -n $namespace)
    if [ x"$secret_ref" == x"secret/concert-configdb-creds" ];
    then
        BYO_CONFIGDB="true"    
    fi

    secret_ref=$(kubectl get secret --ignore-not-found concert-appdb-creds -o name -n $namespace)
    if [ x"$secret_ref" == x"secret/concert-appdb-creds" ];
    then
        BYO_APPDB="true"    
    fi

    ### Both or neither should be true
    if [ $BYO_CONFIGDB != $BYO_APPDB ]
    then
        print_message ERROR "Need both configdb and appdb credentials for $namespace.."
        return 1
    fi

    ## Bucket secrets
    secret_ref=$(kubectl get secret --ignore-not-found concert-lzbucket-creds -o name -n $namespace)
    if [ x"$secret_ref" == x"secret/concert-lzbucket-creds" ];
    then
        BYO_LZBUCKET="true"    
    fi

    secret_ref=$(kubectl get secret --ignore-not-found concert-elbucket-creds -o name -n $namespace)
    if [ x"$secret_ref" == x"secret/concert-elbucket-creds" ];
    then
        BYO_ELBUCKET="true"    
    fi

    ### Both or neither should be true
    if [ $BYO_LZBUCKET != $BYO_ELBUCKET ]
    then
        print_message ERROR "Need both landing zone and evidence locker bucket credentials for $namespace.."
        return 1
    fi

    export $BYO_CONFIGDB $BYO_APPDB $BYO_ELBUCKET $BYO_LZBUCKET
    return 0
}

update_configmap_for_upgrade()
{
    NS=${1}
    TARGET_CM=app-cfg-cm

    # Check if ConfigMap exists
    if kubectl get configmap $TARGET_CM -n ${NS} &> /dev/null; then
        print_message INFO "Checking ConfigMap $TARGET_CM for upgrade variables"

        # Array of variables to check and add if missing
        declare -a vars=("RUNASUSER" "RUNASGROUP" "FS_GROUPID" "SUPP_GROUPID")

        for var in "${vars[@]}"
        do
            # Check if variable exists in ConfigMap
            if ! kubectl get configmap $TARGET_CM -n ${NS} -o json | jq -e ".data | has(\"${var}\")"; then
                print_message INFO "$var not found in ConfigMap. Adding..."

                # Get the value from environment variable with the same name
                value=${!var}

                # Patch the ConfigMap to add the missing variable
                kubectl patch configmap $TARGET_CM -n ${NS} --type=merge -p "{\"data\":{\"${var}\":\"${value}\"}}"
            fi
        done
    fi
}
