#!/usr/bin/env bash


set -e

curr_dir=`dirname $0`
cd $curr_dir
curr_dir=`pwd`

source ${curr_dir}/k8s-utils.sh

print_usage()
{
cat << EOM
    activate-license-cron.sh
    -----
    This procedure creates the necessary secrets and configmaps in the Concert namespace. \\
    This should be executed after installing the licensing service and adding operandrequest CRD

    Syntax
    ------
    ${CMD_PREFIX} namespace
   
EOM
}
############### Main  ####################

NS=$1
if [ "X$NS" =  "X" ];
then
    echo "Usage:  $0 <namespace>"
    exit 1
fi
sdir=${curr_dir}/app-license-or

update_params_yamls ${sdir}

kubectl kustomize ${sdir} | kubectl apply  --namespace=$NS -f -
