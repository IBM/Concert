#!/usr/bin/env bash

set -e

this_dir=$(dirname "${0}")
cd "${this_dir}"
export this_dir=$(pwd)

export SOLIS_PRODUCT="car-rental"
export HUB_NS="hub-10"
export SOLIS_PRODUCT_NS="product-10"

export SOLIS_PRODUCT_DIRECT_SVC="car-rental-svc"
export SOLIS_PRODUCT_PORT=10443

export HUB_ACCESS_KEY=$(${this_dir}/../bin/access-key --namespace=hub-10 --generate )
export HUB_URL=https://ibm-solis-hub-gw-svc.${HUB_NS}.svc.cluster.local:11443

export IMAGE_TAG="may10"
export IMAGE_REGISTRY=na.artifactory.swg-devops.com/hyc-zen-dev-test-team-zen-dev-test-lakehouse-docker-local/dev-solis
#export ART_USER="..."
#export ART_PASS="..."

export K8s_TEMPLATE_DIR="${this_dir}"
export K8s_STATUS_LBL="component=ibm-${SOLIS_PRODUCT}-gw"

#mkdir -p /tmp/pvw

${this_dir}/../bin/deploy-k8s.sh --registry=${IMAGE_REGISTRY} --registry-user=${ART_USER} --registry-user-pass=${ART_PASS} --tag=${IMAGE_TAG} --namespace=${SOLIS_PRODUCT_NS} 

#--preview-dir=/tmp/pvw
