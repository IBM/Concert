IBM Concert Workflows 2.0.0
====================================

IBM Concert Workflows is an API-driven tool that automates, integrates and connects
across the network and business. It facilitates and secures communication between platforms, 
services and applications.


© Copyright IBM Corp. 2023, 2025
