# Supported-Architectures: ppc64le, X86_64
{{- define "existingSecret.data" }}
  {{- $secretName := .name }}
  {{- $key := .key }}
  {{- $secretFullName := printf "%s-%s" .Dot.Release.Name $secretName }}
  {{- $secretObj := (lookup "v1" "Secret" .Dot.Release.Namespace $secretFullName) | default dict }}
  {{- $secretData := (get $secretObj "data") | default dict }}
  {{- $value := get $secretData $key }}
  {{- $value }}
{{- end }}

{{- define "pliantAiReplicas" -}}
{{- /*
     This helper returns 1 if:
       (1) installation_type is aws-saas or ibm-saas
       (2) OR watsonx_auth_type from values is set and not "disabled"
       (3) OR watsonx_auth_type from configmap is set and not "disabled"
     Otherwise, returns 0.
*/ -}}

{{- $installationType := .Values.rna.instance.installation_type | default "" | trim | lower -}}
{{- $watsonxAuthTypeFromValues := .Values.rna.instance.ai.watsonx_auth_type | default "" | trim | lower -}}
{{- $watsonxAuthTypeFromConfigmap := "" -}}

{{- $configMapObj := lookup "v1" "ConfigMap" .Release.Namespace (printf "%s-pliant-ai-configmap" .Release.Name) | default dict -}}
{{- if and $configMapObj.data (index $configMapObj.data "watsonx-auth-type") }}
  {{- $watsonxAuthTypeFromConfigmap = (index $configMapObj.data "watsonx-auth-type") | trim | lower -}}
{{- end }}

{{- $isValEnabled := and (ne $watsonxAuthTypeFromValues "") (ne $watsonxAuthTypeFromValues "disabled") -}}
{{- $isCfgEnabled := and (ne $watsonxAuthTypeFromConfigmap "") (ne $watsonxAuthTypeFromConfigmap "disabled") -}}
{{- $isSaas := or (eq $installationType "aws-saas") (eq $installationType "ibm-saas") -}}
{{- if or $isValEnabled $isCfgEnabled $isSaas -}}
1
{{- else -}}
0
{{- end }}
{{- end }}

{{- define "existingConfigMap.data" }}
  {{- $configMapName := .name }}
  {{- $key := .key }}
  {{- $configMapFullName := printf "%s-%s" .Dot.Release.Name $configMapName }}
  {{- $configMapObj := (lookup "v1" "ConfigMap" .Dot.Release.Namespace $configMapFullName) | default dict }}
  {{- $configMapData := (get $configMapObj "data") | default dict }}
  {{- $value := get $configMapData $key }}
  {{- $value }}
{{- end }}

{{- define "decodePem" }}
  {{- $certPem := . }}
  {{- if $certPem }}
    {{- if not (hasPrefix "-----" $certPem) }}
      {{- $certPem = $certPem | b64dec }}
      {{- if hasPrefix "illegal" $certPem }}
        {{- fail $certPem }}
      {{- end }}
    {{- end }}
  {{- end }}
  {{- $certPem }}
{{- end }}

{{ define "IBM.annotations" }}
productID: "b4cd7f76c9034bdfbc7dcc6421afff65"
productName: "IBM Concert Software Enterprise"
productMetric: "RESOURCE_UNIT"
productChargedContainers: "All"
{{- end}}

{{ define "IBM.annotations.legacy" }}
productID: "20a1779444b84225a1659b5c4f292499"
productName: "IBM Rapid Network Automation"
productMetric: "PROCESS"
productChargedContainers: "All"
{{- end}}

{{- define "pliant.name" -}}
{{- default .Release.Name | trunc 53 | trimSuffix "-" }}-pliant.io
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "pliant.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "pliant.labels" -}}
helm.sh/chart: {{ include "pliant.chart" . }}
{{ include "pliant.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "pliant.selectorLabels" -}}
app.kubernetes.io/name: {{ include "pliant.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{- define "concert.prefix" -}}
{{- if .Values.rna.instance.cpfs -}}
/ibm/concert/cw
{{- else -}}
/cw
{{- end -}}
{{- end }}

{{/*
Istio Setup
*/}}

{{/*
Check if istio is enabled
*/}}
{{- define "istio.enabled" -}}
{{- if and .Values.rna .Values.rna.instance .Values.rna.instance.istio (eq .Values.rna.instance.istio.enabled true) }}
true
{{- end -}}
{{- end -}}

{{/*
Istio to namespace injection
*/}}
{{- define "istio.ns.injection" -}}
{{- if and .Values.rna .Values.rna.instance .Values.rna.instance.istio (eq .Values.rna.instance.istio.enabled true) }}
istio-injection: enabled
{{- end }}
{{- end }}

{{/*
Istio to pod injection
*/}}
{{- define "istio.app.injection" -}}
{{- if and .Values.rna .Values.rna.instance .Values.rna.instance.istio (eq .Values.rna.instance.istio.enabled true) }}
sidecar.istio.io/inject: "true"
{{- end }}
{{- end }}

{{/*
Wait for proxy before main container starts
*/}}
{{- define "istio.proxy.holdApplication" -}}
{{- if and .Values.rna .Values.rna.instance .Values.rna.instance.istio (eq .Values.rna.instance.istio.enabled true) }}
proxy.istio.io/config: '{ "holdApplicationUntilProxyStarts": true }'
{{- end }}
{{- end }}

{{/*
Send signal to shutdown proxy
*/}}
{{- define "istio.shutdown.command" -}}
echo "Job completed, shutting down proxy..."
curl -X POST http://localhost:15000/quitquitquit || echo "Curl to proxy failed"
sleep 2
{{- end -}}

{{- define "ext.mysql.secretIsComplete" -}}
  {{- $secret := lookup "v1" "Secret" .Release.Namespace "cw-secrets" -}}
  {{- if and $secret $secret.data -}}
    {{- $host := (get $secret.data "MYSQLDB_HOST") | default "" | b64dec | trim -}}
    {{- $port := (get $secret.data "MYSQLDB_PORT") | default "" | b64dec | trim -}}
    {{- $user := (get $secret.data "MYSQLDB_USER") | default "" | b64dec | trim -}}
    {{- $password := (get $secret.data "MYSQLDB_PASSWORD") | default "" | b64dec | trim -}}
    {{- $dbname := (get $secret.data "MYSQLDB_DBNAME") | default "" | b64dec | trim -}}
    {{- if and (ne $host "") (ne $port "") (ne $user "") (ne $password "") (ne $dbname "") -}}
      true
    {{- else -}}
      false
    {{- end -}}
  {{- else -}}
    false
  {{- end -}}
{{- end -}}

{{- define "ext.postgres.secretIsComplete" -}}
  {{- $secret := lookup "v1" "Secret" .Release.Namespace "cw-secrets" -}}
  {{- if and $secret $secret.data -}}
    {{- $host := (get $secret.data "POSTGRESQL_HOST") | default "" | b64dec | trim -}}
    {{- $port := (get $secret.data "POSTGRESQL_PORT") | default "" | b64dec | trim -}}
    {{- $user := (get $secret.data "POSTGRESQL_USER") | default "" | b64dec | trim -}}
    {{- $password := (get $secret.data "POSTGRESQL_PASSWORD") | default "" | b64dec | trim -}}
    {{- $dbname := (get $secret.data "POSTGRESQL_DBNAME") | default "" | b64dec | trim -}}
    {{- if and (ne $host "") (ne $port "") (ne $user "") (ne $password "") (ne $dbname "") -}}
      true
    {{- else -}}
      false
    {{- end -}}
  {{- else -}}
    false
  {{- end -}}
{{- end -}}

{{- define "s3.secretIsComplete" -}}
  {{- $secret := lookup "v1" "Secret" .Release.Namespace "cw-secrets" -}}
  {{- if and $secret $secret.data -}}
    {{- $secret_key := (get $secret.data "CW_SECRET_KEY") | default "" | b64dec | trim -}}
    {{- $access_key := (get $secret.data "CW_ACCESS_KEY") | default "" | b64dec | trim -}}
    {{- $auth_type := (get $secret.data "CW_AUTH_TYPE") | default "" | b64dec | trim -}}
    {{- $bucket := (get $secret.data "CW_BUCKET") | default "" | b64dec | trim -}}
    {{- $host := (get $secret.data "CW_HOST") | default "" | b64dec | trim -}}
    {{- $region := (get $secret.data "CW_REGION") | default "" | b64dec | trim -}}
    {{- $port := (get $secret.data "CW_PORT") | default "" | b64dec | trim -}}
    {{- if and (ne $secret_key "") (ne $access_key "") (ne $auth_type "") (ne $bucket "") (ne $host "") (ne $region "") (ne $port "")  -}}
      true
    {{- else -}}
      false
    {{- end -}}
  {{- else -}}
    false
  {{- end -}}
{{- end -}}

{{/* Pod SecurityContext shared by all addons */}}
{{- define "pliant.podSecurityContext" -}}
{{- if not (.Capabilities.APIVersions.Has "security.openshift.io/v1/SecurityContextConstraints") }}
securityContext:
  fsGroup: 1000
  supplementalGroups:
    - 1000
  runAsUser: 1000
  runAsGroup: 1000
  runAsNonRoot: true
  seccompProfile:
    type: RuntimeDefault
  # appArmorProfile:
  #   type: RuntimeDefault
{{- end }}
{{- end }}

{{/* Container SecurityContext shared by all addons */}}
{{- define "pliant.containerSecurityContext" -}}
{{- if not (.Capabilities.APIVersions.Has "security.openshift.io/v1/SecurityContextConstraints") }}
securityContext:
  allowPrivilegeEscalation: false
  privileged: false
  readOnlyRootFilesystem: true
  capabilities:
    drop:
      - ALL
  runAsUser: 1000
  runAsGroup: 1000
  runAsNonRoot: true
{{- end }}
{{- end }}
