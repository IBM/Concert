# Supported-Architectures: ppc64le, X86_64
{{- define "existingSecret.data" }}
  {{- $secretName := .name }}
  {{- $key := .key }}
  {{- $secretFullName := printf "%s-%s" .Dot.Release.Name $secretName }}
  {{- $secretObj := (lookup "v1" "Secret" .Dot.Release.Namespace $secretFullName) | default dict }}
  {{- $secretData := (get $secretObj "data") | default dict }}
  {{- $value := get $secretData $key }}
  {{- $value }}
{{- end }}

{{- define "existingConfigMap.data" }}
  {{- $configMapName := .name }}
  {{- $key := .key }}
  {{- $configMapFullName := printf "%s-%s" .Dot.Release.Name $configMapName }}
  {{- $configMapObj := (lookup "v1" "ConfigMap" .Dot.Release.Namespace $configMapFullName) | default dict }}
  {{- $configMapData := (get $configMapObj "data") | default dict }}
  {{- $value := get $configMapData $key }}
  {{- $value }}
{{- end }}

{{- define "decodePem" }}
  {{- $certPem := . }}
  {{- if $certPem }}
    {{- if not (hasPrefix "-----" $certPem) }}
      {{- $certPem = $certPem | b64dec }}
      {{- if hasPrefix "illegal" $certPem }}
        {{- fail $certPem }}
      {{- end }}
    {{- end }}
  {{- end }}
  {{- $certPem }}
{{- end }}

{{ define "IBM.annotations" }}
productID: "20a1779444b84225a1659b5c4f292499"
productName: "IBM Rapid Network Automation"
productMetric: "PROCESS"
productChargedContainers: "All"
{{- end}}

{{- define "pliant.name" -}}
{{- default .Release.Name | trunc 53 | trimSuffix "-" }}-pliant.io
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "pliant.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "pliant.labels" -}}
helm.sh/chart: {{ include "pliant.chart" . }}
{{ include "pliant.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "pliant.selectorLabels" -}}
app.kubernetes.io/name: {{ include "pliant.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/* Pod SecurityContext shared by all addons */}}
{{- define "pliant.podSecurityContext" -}}
{{- if not (.Capabilities.APIVersions.Has "security.openshift.io/v1/SecurityContextConstraints") }}
securityContext:
  fsGroup: 1000
  supplementalGroups:
    - 1000
  runAsUser: 1000
  runAsGroup: 1000
  runAsNonRoot: true
{{- end }}
{{- end }}

{{/* Container SecurityContext shared by all addons */}}
{{- define "pliant.containerSecurityContext" -}}
{{- if not (.Capabilities.APIVersions.Has "security.openshift.io/v1/SecurityContextConstraints") }}
securityContext:
  allowPrivilegeEscalation: false
  privileged: false
  readOnlyRootFilesystem: true
  capabilities:
    drop:
      - ALL
  runAsUser: 1000
  runAsGroup: 1000
  runAsNonRoot: true
  seccompProfile:
    type: RuntimeDefault
  # appArmorProfile:
  #   type: RuntimeDefault
{{- end }}
{{- end }}