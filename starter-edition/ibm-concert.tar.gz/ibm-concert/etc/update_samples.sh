i#!/bin/bash
# ################################################################################
# #
# # Licensed Materials - Property of IBM
# #
# # "Restricted Materials of IBM"
# #
# # (C) COPYRIGHT IBM Corp. 2024 All Rights Reserved.
# #
# # US Government Users Restricted Rights - Use, duplication or
# # disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
# #
# ################################################################################

# Script to replace all occurrences of "stg.icr.io" with "icr.io" in a folder of files
# Usage: ./replace_registry.sh <directory>
# Example: ./replace_registry.sh /path/to/params/folder

set -e

# Function to log with color
log_info() {
    echo -e "\033[1;34m[INFO]\033[0m $1"
}

log_success() {
    echo -e "\033[1;32m[SUCCESS]\033[0m $1"
}

log_error() {
    echo -e "\033[1;31m[ERROR]\033[0m $1"
}

log_warning() {
    echo -e "\033[1;33m[WARNING]\033[0m $1"
}

# Check if directory is provided
if [ -z "$1" ]; then
    log_error "Directory path is required."
    echo "Usage: ./replace_registry.sh <directory>"
    exit 1
fi

DIRECTORY="$1"

# Check if directory exists
if [ ! -d "$DIRECTORY" ]; then
    log_error "Directory '$DIRECTORY' does not exist."
    exit 1
fi

log_info "Searching for files in directory: $DIRECTORY"

# Find all files in the directory
FILES=$(find "$DIRECTORY" -type f | sort)
FILE_COUNT=$(echo "$FILES" | wc -l)

if [ "$FILE_COUNT" -eq 0 ]; then
    log_warning "No files found in directory: $DIRECTORY"
    exit 0
fi

log_info "Found $FILE_COUNT files to process."

# Counter for modified files
MODIFIED_COUNT=0

# Process each file
for FILE in $FILES; do
    # Check if file contains "stg.icr.io"
    if grep -q "stg.icr.io" "$FILE"; then
        log_info "Processing file: $FILE"
        
        # Create a backup of the original file
        cp "$FILE" "${FILE}.bak"
        
        # Replace "stg.icr.io" with "icr.io"
        sed -i 's/stg\.icr\.io/icr.io/g' "$FILE"
        
        # Also handle the case where it might be "cp.stg.icr.io"
        sed -i 's/cp\.icr\.io/cp.icr.io/g' "$FILE"
        
        # Check if file was modified
        if diff -q "$FILE" "${FILE}.bak" > /dev/null; then
            log_warning "No changes made to file: $FILE"
            rm "${FILE}.bak"
        else
            log_success "Successfully updated file: $FILE"
            MODIFIED_COUNT=$((MODIFIED_COUNT + 1))
            
            # Show diff of changes
            echo "Changes made to $FILE:"
            diff -u "${FILE}.bak" "$FILE" | grep -E "^(\+|\-)" | grep -v "^--- " | grep -v "^+++ "
            echo ""
        fi
    fi
done

# Summary
log_info "Processing complete."
log_success "Modified $MODIFIED_COUNT out of $FILE_COUNT files."

if [ "$MODIFIED_COUNT" -gt 0 ]; then
    log_info "Backup files with .bak extension were created for modified files."
    log_info "You can remove them with: find \"$DIRECTORY\" -name \"*.bak\" -delete"
fi

exit 0

# Made with Bob

