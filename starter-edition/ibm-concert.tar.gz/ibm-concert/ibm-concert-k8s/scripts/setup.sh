#!/usr/bin/env bash

### sets up swagger and upx for use within a Docker build

set -e

bld_dir=${BLD_DIR:-${HOME}/app-bld}
mkdir -p ${bld_dir}/bin
cd $bld_dir

wget --inet4-only -O "${bld_dir}/bin/swagger" https://github.com/go-swagger/go-swagger/releases/download/v0.30.5/swagger_linux_amd64
wget --inet4-only https://github.com/upx/upx/releases/download/v3.95/upx-3.95-amd64_linux.tar.xz

tar -C ${bld_dir} -xf ${bld_dir}/upx-3.95-amd64_linux.tar.xz

mv ${bld_dir}/upx-3.95-amd64_linux/upx ${bld_dir}/bin/upx

chmod -R 755 ${bld_dir}/bin
