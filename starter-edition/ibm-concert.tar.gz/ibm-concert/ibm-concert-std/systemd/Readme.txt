#########################################
## IBM Confidential                    ##
## PID: 5900-BD6, 5900-BBE             ##
## Copyright IBM Corp. 2024            ##
#########################################

IBM Concert Systemd Service Setup Guide
-------------------------------

Using a systemd service file for the IBM Concert Service provides a robust way to manage the service lifecycle, ensuring it runs efficiently and reliably.
This guide includes commands for managing the service using systemctl. 

Steps to Install IBM Concert Service
------------------------------------

Customers can set `--systemd_enable=` - set to y to enable systemd configuration.


If `--systemd_enable=y`, ibm-concert service will be installed during the setup.

If you need to stop the ibm-concert service, run the stop_service script:

```./ibm-concert-std/systemd/stop_service```

stop_service script stops the ibm-concert timer and ibm-concert service and removes all the containers. 

-------------------------------------------------------------------------------------------------------

If you need to uninstall the ibm-concert service, run the uninstall_service script:

```./ibm-concert-std/systemd/uninstall_service```

uninstall_service  stop and disable the ibm-concert service and timer.

-------------------------------------------------------------------------------------------------------

If you had chosen not to use --systemd_enable=y as part of setup, you can still use the systemd utility scripts at a later date, without needing to re-run setup

-------------------------------------------------------------------------------------------------------
If you need to install the ibm-concert service, run the install_service script:

```./ibm-concert-std/systemd/install_service```

install_service start and enable the ibm-concert service and timer.

-------------------------------------------------------------------------------------------------------

If you need to check the status of ibm-concert service and timer, run the status_service script:

```./ibm-concert-std/systemd/status_service```

status_service displays the current status of ibm-concert service and timer.


Making Changes to the Service File
----------------------------------

If you make any changes to the service file, re-run the install_service script to apply those changes:

```./ibm-concert-std/systemd/install_service```

Run the following commands to activate systemd service and timer:

```systemctl --user restart ibm-concert.service```

```systemctl --user restart ibm-concert.timer```

**IMPORTANT:**  For Non-root User, enable lingering ``` loginctl enable-linger $USER``` to ensure that user services continue running even after you log out:

As root user run -  `loginctl enable-linger $USER` - where $USER refers to the user who installs and manages concert.
