#!/usr/bin/env bash

set -e

curr_dir=`dirname $0`
cd $curr_dir
curr_dir=`pwd`

source ${curr_dir}/k8s-utils.sh

############### Main  ####################

NS=$1
if [ "X$NS" =  "X" ];
then
    echo "Usage:  $0 <namespace>"
    exit 1
fi
if [ "X$NGINX_CLASSNAME" = "X" ];
then
  export NGINX_CLASSNAME="nginx"
fi

sdir=${curr_dir}/app-nginx-ingress
update_params_yamls ${sdir}

cat ${sdir}/annotations.yaml >> ${sdir}/kustomization.yaml

kubectl kustomize ${sdir} | kubectl apply  --namespace=$NS -f -
