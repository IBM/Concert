#!/only/source/this

if [ -z $curr_dir ];
then
    curr_dir=`dirname $0`
    cd $curr_dir
    curr_dir=`pwd`
fi

bld_version_file=${curr_dir}/etc/build_version
if [ -f ${bld_version_file} ];
then
   bld_version=$(cat $bld_version_file)
fi

if [ "X$bld_version" != X ];
then
    export IMG_TAG=${bld_version}
fi

set -e

if [ X"${kc}" = X ];
then
    export kc=kubectl
fi

if [ X"${INT_TLS_DIR}" == X ];
then
  export INT_TLS_DIR=${curr_dir}/setup/tmp 
fi

TRACE=${TRACE:- true}

#arg1: level
#arg2,arg3 etc.: messages
print_message()
{
    shift
    echo "$(date -u) $@"
}

setup_namespace()
{
    $TRACE "entering $FUNCNAME"

    if [ -z ${DATAAPPS_k8s_PREVIEW} ];
    then
        ns_exists=$(${kc} get sa -o name --namespace ${1} default || true)
        if [ X${ns_exists}X == XX ];
        then
            print_message INFO "creating namespace $1"
    	    ${kc} create namespace $1 --dry-run=client -o yaml | ${kc} apply ${KC_ARGS} --namespace=$1 -f -
        else
            print_message INFO "using existing namespace: ${1}"
        fi    
	fi

    $TRACE "exiting $FUNCNAME"
}

setup_pull_secrets()
{
    $TRACE "entering $FUNCNAME"

    print_message INFO "setting up registry pull secrets for ${IMG_PREFIX} "
    if [ X"${IMG_PREFIX}" = X ];
    then
        echo "WARNING: - not creating kube registry pull secret"
        return
    fi

    if [ -z ${DATAAPPS_k8s_PREVIEW} ];
    then
    	${kc} create secret --namespace=$1 docker-registry regcred \
    	--docker-server=$IMG_PREFIX --docker-username=$REG_USER --docker-password=$REG_PASS \
    	--dry-run=client -o yaml | ${kc} apply ${KC_ARGS} --namespace=$1 -f -
	fi

    $TRACE "exiting $FUNCNAME"
}

gen_random()
{
    echo -n $(openssl rand -hex 12 )
}

generate_dataapps_app_secrets()
{
    DA_INTERNAL_SECRET=$(gen_random)
    echo "DA_INTERNAL_SECRET=$DA_INTERNAL_SECRET" >> ${1}

    if [ -z ${DATAAPPS_ADM_USERNAME} ];
    then
        DATAAPPS_AUTH_USERNAME=$(gen_random)
    else
        DATAAPPS_AUTH_USERNAME=${DATAAPPS_ADM_USERNAME}
    fi
    echo "DATAAPPS_AUTH_USERNAME=$DATAAPPS_AUTH_USERNAME" >> ${1}

    if [ -z ${DATAAPPS_ADM_PASSWORD} ];
    then
        DATAAPPS_AUTH_PASSWORD=$(gen_random)
    else
        DATAAPPS_AUTH_PASSWORD=${DATAAPPS_ADM_PASSWORD}
    fi
    echo "DATAAPPS_AUTH_PASSWORD=$DATAAPPS_AUTH_PASSWORD" >> ${1}
}

# TODO: Move non-secret environment variables to dataapps-app.env.tmpl
generate_oob_secrets()
{
    NS=${2}

    if [ x"${ADD_MINIO}" != x ];
	then
		OOB_MINIO_ACCESS_KEY=$(gen_random)
		OOB_MINIO_SECRET_KEY=$(gen_random)
		LZ_ACCESS_KEY=${OOB_MINIO_ACCESS_KEY}
		LZ_SECRET_KEY=${OOB_MINIO_SECRET_KEY}

cat << EOS >> ${1}
        DA_BUCKET_ACCESS_KEY=$OOB_MINIO_ACCESS_KEY
        DA_BUCKET_BUCKET=dataapps
        DA_BUCKET_HOST=dataapps-minio-svc.${NS}.svc
        DA_BUCKET_PORT=9000
        DA_BUCKET_SECRET_KEY=$OOB_MINIO_SECRET_KEY
        DA_BUCKET_SECURE=true
        DA_BUCKET_TLS_CA_FILE=/app/tmp/self-signed-ssl/tls-ca-bundle.pem
        OOB_MINIO_ACCESS_KEY=$OOB_MINIO_ACCESS_KEY
        OOB_MINIO_HOST=dataapps-minio-svc.${NS}.svc
        OOB_MINIO_PORT=9000
        OOB_MINIO_SECRET_KEY=$OOB_MINIO_SECRET_KEY
EOS
	fi

    if [ x"${ADD_REDIS}" != x ];
	then
        OOB_REDIS_DEFAULT_PASSWORD=$(gen_random)
        OOB_REDIS_PASSWORD=$(gen_random)
        OOB_REDIS_USER=$(gen_random)

cat << EOP >> ${1}
        DA_REDIS_HOST=dataapps-redis-svc.${NS}.svc
        DA_REDIS_PASSWORD=$OOB_REDIS_PASSWORD
        DA_REDIS_PORT=6379
        DA_REDIS_TLS_AUTH_CLIENTS=no
        DA_REDIS_TLS_CA_FILE=/app/tmp/self-signed-ssl/tls-ca-bundle.pem
        DA_REDIS_TLS_CERT_FILE=/app/tmp/self-signed-ssl/tls.crt
        DA_REDIS_TLS_ENABLED=yes
        DA_REDIS_TLS_KEY_FILE=/app/tmp/self-signed-ssl/tls.key
        DA_REDIS_USER=$OOB_REDIS_USER
        OOB_REDIS_DEFAULT_PASSWORD=$OOB_REDIS_DEFAULT_PASSWORD
        OOB_REDIS_HOST=dataapps-redis-svc.${NS}.svc
        OOB_REDIS_PASSWORD=$OOB_REDIS_PASSWORD
        OOB_REDIS_PORT=6379
        OOB_REDIS_USER=$OOB_REDIS_USER
EOP
	fi

    if [ x"${ADD_POSTGRES}" != x ];
	then
        OOB_POSTGRES_HOST=dataapps-postgres-svc.${NS}.svc
        OOB_POSTGRES_PASSWORD=$(gen_random)
        OOB_POSTGRES_PORT=5432
        OOB_POSTGRES_USER=$(gen_random)

cat << EOP >> ${1} 
        DATABASE_URL=postgresql://${OOB_POSTGRES_USER}:${OOB_POSTGRES_PASSWORD}@${OOB_POSTGRES_HOST}:${OOB_POSTGRES_PORT}/dataappsdb
        OOB_POSTGRES_HOST=$OOB_POSTGRES_HOST
        OOB_POSTGRES_PASSWORD=$OOB_POSTGRES_PASSWORD
        OOB_POSTGRES_PORT=$OOB_POSTGRES_PORT
        OOB_POSTGRES_USER=$OOB_POSTGRES_USER
EOP
	fi

    if [ x"${SEED_DATABASE}" != x ];
	then

cat << EOP >> ${1} 
        DA_SEED_DEFAULT_ORGANIZATION=true
EOP
	fi
}

k8s_create_tls_secret()
{
    $TRACE "entering $FUNCNAME"

 ns=$1
 tls_secret_name=$2
 ssltmpdir=$3

 ${kc} create -n ${1} secret generic ${tls_secret_name} \
   --from-file=tls.key=${ssltmpdir}/tls.key \
   --from-file=tls.crt=${ssltmpdir}/tls.crt \
   --dry-run=client -o yaml | ${kc} apply ${KC_ARGS} --namespace=$1 -f -

    $TRACE "exiting $FUNCNAME"
}

update_params_yamls()
{
    $TRACE "entering $FUNCNAME"
    template_dir=$1
    for i in $(ls ${template_dir}/*.tmpl)
    do
        $TRACE "========== applying $i ====== "
        $TRACE

        out_file=$(echo $i | sed -e 's/.tmpl//')

        envsubst < $i > $out_file
    done
}

apply_yamls()
{
    $TRACE "entering $FUNCNAME"

    ns=$1
    template_dir=$2
    for i in $(ls ${curr_dir}/${template_dir}/*.yaml.tmpl)
    do
        $TRACE "========== applying $i ====== "
        $TRACE

        tmpl_name=$(basename $i)

        temp_out_file="/tmp/${1}-${template_dir}-${tmpl_name}"
        envsubst < $i > $temp_out_file

        ${kc} apply ${KC_ARGS} --namespace=${ns} -f ${temp_out_file}
        
        if [ x"${CLEANUP}" == "false" ];
        then
            echo ${temp_out_file}
        else
            rm -f ${temp_out_file}
        fi

        $TRACE
        $TRACE "==================="
    done

    $TRACE "exiting $FUNCNAME"
}

# Validate secrets for bring your own storage
validate_storage_secrets()
{
    namespace=${1}
    BYO_BUCKET="false"
    BYO_DATABASE="false"
    
    ## Bucket secrets
    secret_ref=$(kubectl get secret --ignore-not-found dataapps-bucket-creds -o name -n $namespace)
    if [ x"$secret_ref" == x"secret/dataapps-bucket-creds" ];
    then
        BYO_BUCKET="true"    
    fi

    ## Database secrets
    secret_ref=$(kubectl get secret --ignore-not-found dataapps-database-creds -o name -n $namespace)
    if [ x"$secret_ref" == x"secret/dataapps-database-creds" ];
    then
        BYO_DATABASE="true"    
    fi

    export $BYO_BUCKET $BYO_DATABASE

    return 0
}
