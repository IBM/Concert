Discover & Rotate IBM power Certificates.
Rotation Happens only self-signed eligible IBM Data Power certificates.