This flow discovered the certificates in IBM Secrets Manager 

