This flow take  service_auth of IBM secret manager connection and certificate data.
It will find the certificate  by using its secret id and generate new certificate with the data available.